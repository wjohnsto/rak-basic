"""Redis Agent Kit REST API."""

from redis_agent_kit.api.app import create_app

__all__ = ["create_app"]
