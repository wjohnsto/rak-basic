"""Optional API key authentication for Redis Agent Kit.

Provides simple API key authentication via:
- Header: X-API-Key
- Header: Authorization: Bearer <key>

Usage:
    from redis_agent_kit.api.auth import create_api_key_dependency

    # Create dependency with allowed keys
    verify_api_key = create_api_key_dependency(["key1", "key2"])

    # Use in router
    @router.post("/protected", dependencies=[Depends(verify_api_key)])
    async def protected_endpoint():
        ...

    # Or apply to entire app
    app = create_app(api_keys=["key1", "key2"])
"""

from collections.abc import Awaitable, Callable

from fastapi import HTTPException, Request, Security, status
from fastapi.security import APIKeyHeader, HTTPAuthorizationCredentials, HTTPBearer

# Security schemes
api_key_header = APIKeyHeader(name="X-API-Key", auto_error=False)
bearer_scheme = HTTPBearer(auto_error=False)


def create_api_key_dependency(
    api_keys: list[str],
) -> Callable[..., Awaitable[str]]:
    """Create an API key verification dependency.

    Args:
        api_keys: List of valid API keys.

    Returns:
        A FastAPI dependency that verifies API keys.
    """
    valid_keys = set(api_keys)

    async def verify_api_key(
        request: Request,
        x_api_key: str | None = Security(api_key_header),
        bearer: HTTPAuthorizationCredentials | None = Security(bearer_scheme),
    ) -> str:
        """Verify API key from header or bearer token.

        Args:
            request: The FastAPI request.
            x_api_key: API key from X-API-Key header.
            bearer: Bearer token from Authorization header.

        Returns:
            The verified API key.

        Raises:
            HTTPException: If no valid API key is provided.
        """
        # Check X-API-Key header first
        if x_api_key and x_api_key in valid_keys:
            return x_api_key

        # Check Bearer token
        if bearer and bearer.credentials in valid_keys:
            return bearer.credentials

        # No valid key found
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or missing API key",
            headers={"WWW-Authenticate": "Bearer"},
        )

    return verify_api_key


def create_optional_api_key_dependency(
    api_keys: list[str] | None,
) -> Callable[..., Awaitable[str]] | None:
    """Create an optional API key dependency.

    If api_keys is None or empty, returns None (no auth required).
    Otherwise, returns a verification dependency.

    Args:
        api_keys: List of valid API keys, or None for no auth.

    Returns:
        A FastAPI dependency or None.
    """
    if not api_keys:
        return None
    return create_api_key_dependency(api_keys)
