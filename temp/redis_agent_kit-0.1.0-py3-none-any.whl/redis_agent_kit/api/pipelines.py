"""REST API pipeline endpoints."""

from pathlib import Path
from typing import Any

import redis.asyncio as redis_lib
from docket import Docket
from fastapi import APIRouter, Request
from pydantic import BaseModel

from redis_agent_kit.pipelines import (
    Document,
    DocumentProcessor,
    ProcessorConfig,
    VectorStore,
)
from redis_agent_kit.pipelines.artifact_storage import ArtifactStorage
from redis_agent_kit.pipelines.models import PipelineConfig
from redis_agent_kit.pipelines.orchestrator import PipelineOrchestrator

router = APIRouter()


def get_vector_store(request: Request) -> VectorStore:
    """Get VectorStore from app state."""
    redis_url = request.app.state.redis_url
    prefix = request.app.state.prefix
    client: Any = redis_lib.from_url(redis_url)  # type: ignore[no-untyped-call]
    return VectorStore(client, prefix=prefix)


def get_artifact_storage(request: Request) -> ArtifactStorage:
    """Get ArtifactStorage from app state."""
    artifacts_dir = getattr(request.app.state, "artifacts_dir", Path("artifacts"))
    return ArtifactStorage(artifacts_dir)


def get_orchestrator(
    request: Request,
    source_path: Path | None = None,
    docket: Docket | None = None,
) -> PipelineOrchestrator:
    """Get PipelineOrchestrator from app state.

    Args:
        request: The FastAPI request.
        source_path: Optional source path for documents. If not provided,
            uses the artifacts_dir from app state.
    """
    artifacts_dir = getattr(request.app.state, "artifacts_dir", Path("artifacts"))
    base_path = source_path if source_path is not None else artifacts_dir
    config = PipelineConfig(sources=[], artifacts_dir=artifacts_dir)
    return PipelineOrchestrator(config=config, base_path=base_path, docket=docket)


class DocumentInput(BaseModel):
    """Input document for pipeline."""

    title: str
    content: str
    source: str


class RunPipelineRequest(BaseModel):
    """Request body for running pipeline."""

    documents: list[DocumentInput]
    chunk_size: int = 1000
    chunk_overlap: int = 200


class PrepareRequest(BaseModel):
    """Request body for prepare stage."""

    source_path: str


class IngestRequest(BaseModel):
    """Request body for ingest stage."""

    batch_id: str


class FullPipelineRequest(BaseModel):
    """Request body for full pipeline run."""

    source_path: str


class AddDocumentRequest(BaseModel):
    """Request body for adding a document."""

    content: str
    filename: str


async def run_pipeline_on_documents(
    request: Request,
    documents: list[DocumentInput],
    chunk_size: int,
    chunk_overlap: int,
) -> dict[str, Any]:
    """Run pipeline on provided documents."""
    redis_url = request.app.state.redis_url
    prefix = request.app.state.prefix
    client: Any = redis_lib.from_url(redis_url)  # type: ignore[no-untyped-call]

    processor = DocumentProcessor(
        ProcessorConfig(chunk_size=chunk_size, chunk_overlap=chunk_overlap)
    )
    VectorStore(client, prefix=prefix)

    chunks_created = 0
    errors: list[str] = []

    for doc_input in documents:
        try:
            doc = Document(
                title=doc_input.title,
                content=doc_input.content,
                source=doc_input.source,
            )
            chunks = processor.chunk_document(doc)
            # Store chunks without embeddings (embeddings would require API call)
            for chunk in chunks:
                # Store chunk data directly without embedding
                key = f"{prefix}:chunk:{chunk.chunk_id}"
                await client.hset(
                    key,
                    mapping={
                        "chunk_id": chunk.chunk_id,
                        "doc_id": chunk.doc_id,
                        "content": chunk.content,
                        "chunk_index": str(chunk.chunk_index),
                    },
                )
                await client.sadd(f"{prefix}:all_chunks", chunk.chunk_id)
            chunks_created += len(chunks)
        except Exception as e:
            errors.append(f"Error processing {doc_input.title}: {e}")

    return {
        "status": "completed",
        "documents_processed": len(documents),
        "chunks_created": chunks_created,
        "errors": errors,
    }


@router.get("/status")
async def get_status(request: Request) -> dict[str, Any]:
    """Get pipeline status."""
    vs = get_vector_store(request)
    count = await vs.count()
    return {"chunks": count}


@router.delete("")
async def clear_pipeline(request: Request) -> dict[str, Any]:
    """Clear all pipeline data."""
    vs = get_vector_store(request)
    await vs.clear()
    return {"cleared": True}


@router.post("/run")
async def run_pipeline(request: Request, body: RunPipelineRequest) -> dict[str, Any]:
    """Run pipeline on provided documents."""
    result = await run_pipeline_on_documents(
        request, body.documents, body.chunk_size, body.chunk_overlap
    )
    return result


@router.post("/prepare")
async def prepare_pipeline(request: Request, body: PrepareRequest) -> dict[str, Any]:
    """Submit prepare stage task."""
    redis_url = request.app.state.redis_url
    queue_name = request.app.state.queue_name
    async with Docket(url=redis_url, name=queue_name) as docket:
        orchestrator = get_orchestrator(
            request,
            source_path=Path(body.source_path),
            docket=docket,
        )
        task_id = await orchestrator.submit_prepare()
    return {"task_id": task_id}


@router.post("/ingest")
async def ingest_pipeline(request: Request, body: IngestRequest) -> dict[str, Any]:
    """Submit ingest stage task."""
    redis_url = request.app.state.redis_url
    queue_name = request.app.state.queue_name
    async with Docket(url=redis_url, name=queue_name) as docket:
        orchestrator = get_orchestrator(request, docket=docket)
        task_id = await orchestrator.submit_ingest(body.batch_id)
    return {"task_id": task_id}


@router.post("/full")
async def full_pipeline(request: Request, body: FullPipelineRequest) -> dict[str, Any]:
    """Submit full pipeline task (prepare + ingest)."""
    redis_url = request.app.state.redis_url
    queue_name = request.app.state.queue_name
    async with Docket(url=redis_url, name=queue_name) as docket:
        orchestrator = get_orchestrator(
            request,
            source_path=Path(body.source_path),
            docket=docket,
        )
        task_id = await orchestrator.submit_full()
    return {"task_id": task_id}


@router.post("/documents")
async def add_document(request: Request, body: AddDocumentRequest) -> dict[str, Any]:
    """Submit document ingestion task."""
    redis_url = request.app.state.redis_url
    queue_name = request.app.state.queue_name
    async with Docket(url=redis_url, name=queue_name) as docket:
        orchestrator = get_orchestrator(request, docket=docket)
        task_id = await orchestrator.submit_document(body.content, body.filename)
    return {"task_id": task_id}


@router.get("/batches")
async def list_batches(request: Request) -> dict[str, Any]:
    """List available batches."""
    storage = get_artifact_storage(request)
    batches = storage.list_batches()
    return {"batches": batches}


@router.delete("/batches/{batch_id}")
async def delete_batch(request: Request, batch_id: str) -> dict[str, Any]:
    """Delete a batch."""
    storage = get_artifact_storage(request)
    storage.delete_batch(batch_id)
    return {"deleted": True}
