"""REST API task endpoints."""

from __future__ import annotations

import json
from collections.abc import AsyncGenerator
from typing import Any

import redis.asyncio as redis_lib
from fastapi import APIRouter, Header, HTTPException, Query, Request
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field

from redis_agent_kit.keys import RedisKeys
from redis_agent_kit.models import Caller, CallerType, TaskStatus
from redis_agent_kit.streaming import StreamConfig
from redis_agent_kit.task_manager import TaskManager

# Terminal statuses that signal the SSE stream should close
_TERMINAL_STATUSES = {
    TaskStatus.DONE.value,
    TaskStatus.FAILED.value,
    TaskStatus.CANCELLED.value,
}

router = APIRouter()


class CallerInfo(BaseModel):
    """Caller identity for task creation."""

    type: str = Field(default="human", description="Caller type: 'human' or 'agent'")
    id: str | None = Field(default=None, description="Caller ID (user ID, agent name)")
    name: str | None = Field(default=None, description="Human-readable name")
    metadata: dict[str, Any] = Field(default_factory=dict)


class CreateTaskRequest(BaseModel):
    """Request to create a new task."""

    message: str = Field(..., description="The message/query for the agent")
    session_id: str | None = Field(default=None, description="Optional existing session ID")
    context: dict[str, Any] = Field(default_factory=dict, description="Optional context data")
    caller: CallerInfo | None = Field(default=None, description="Optional caller identity")


def get_task_manager(request: Request) -> TaskManager:
    """Get TaskManager from app state."""
    redis_url = request.app.state.redis_url
    prefix = getattr(request.app.state, "prefix", None)
    stream_config: StreamConfig | None = getattr(request.app.state, "stream_config", None)
    client: Any = redis_lib.from_url(redis_url)  # type: ignore[no-untyped-call]
    return TaskManager(client, prefix=prefix, stream_config=stream_config)


@router.post("")
async def create_task(
    request: Request,
    body: CreateTaskRequest,
    x_caller_type: str | None = Header(default=None, alias="X-Caller-Type"),
    x_caller_id: str | None = Header(default=None, alias="X-Caller-ID"),
    x_caller_name: str | None = Header(default=None, alias="X-Caller-Name"),
) -> dict[str, Any]:
    """Create a task and submit it for processing.

    This creates a thread (if not provided), adds the message, creates a task,
    and submits it to the background worker for processing.

    Caller identity can be provided via:
    - Request body: `caller` object with type, id, name, metadata
    - Headers: X-Caller-Type, X-Caller-ID, X-Caller-Name (body takes precedence)
    """
    kit = getattr(request.app.state, "kit", None)
    if kit is None:
        raise HTTPException(
            status_code=500,
            detail="AgentKit not configured. Pass kit to create_app().",
        )

    # Build caller from body or headers
    caller = None
    if body.caller:
        caller = Caller(
            type=CallerType(body.caller.type),
            id=body.caller.id,
            name=body.caller.name,
            metadata=body.caller.metadata,
        )
    elif x_caller_type or x_caller_id or x_caller_name:
        caller = Caller(
            type=CallerType(x_caller_type) if x_caller_type else CallerType.HUMAN,
            id=x_caller_id,
            name=x_caller_name,
        )

    try:
        result: dict[str, Any] = await kit.create_and_submit_task(
            message=body.message,
            context=body.context,
            session_id=body.session_id,
            caller=caller,
        )
        return result
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.get("")
async def list_tasks(
    request: Request,
    status: str | None = None,
    session_id: str | None = None,
    limit: int = 50,
) -> dict[str, Any]:
    """List all tasks."""
    tm = get_task_manager(request)
    status_filter = TaskStatus(status) if status else None
    tasks = await tm.list_tasks(status=status_filter, session_id=session_id)
    # Apply limit after fetching
    tasks = tasks[:limit]

    return {
        "tasks": [task.model_dump() for task in tasks],
        "total": len(tasks),
    }


@router.get("/{task_id}")
async def get_task(request: Request, task_id: str) -> dict[str, Any]:
    """Get task details."""
    tm = get_task_manager(request)
    task = await tm.get_task(task_id)

    if not task:
        raise HTTPException(status_code=404, detail=f"Task {task_id} not found")

    return task.model_dump()


@router.post("/{task_id}/cancel")
async def cancel_task(request: Request, task_id: str) -> dict[str, Any]:
    """Cancel a task.

    This transitions the task to CANCELLED status, preventing it from being
    processed by workers. Cancelled tasks can be restarted by changing their
    status back to QUEUED.
    """
    tm = get_task_manager(request)
    task = await tm.get_task(task_id)

    if not task:
        raise HTTPException(status_code=404, detail=f"Task {task_id} not found")

    await tm.update_status(task_id, TaskStatus.CANCELLED)
    return {"cancelled": True, "task_id": task_id}


@router.post("/{task_id}/restart")
async def restart_task(request: Request, task_id: str) -> dict[str, Any]:
    """Restart a cancelled task.

    This transitions a CANCELLED task back to QUEUED status so it can be
    processed by workers again.
    """
    tm = get_task_manager(request)
    task = await tm.get_task(task_id)

    if not task:
        raise HTTPException(status_code=404, detail=f"Task {task_id} not found")

    if task.status != TaskStatus.CANCELLED:
        raise HTTPException(
            status_code=400,
            detail=f"Task {task_id} is not cancelled (status: {task.status.value})",
        )

    await tm.update_status(task_id, TaskStatus.QUEUED)
    return {"restarted": True, "task_id": task_id}


@router.delete("/{task_id}")
async def delete_task(request: Request, task_id: str) -> dict[str, Any]:
    """Delete a task."""
    tm = get_task_manager(request)
    task = await tm.get_task(task_id)

    if not task:
        raise HTTPException(status_code=404, detail=f"Task {task_id} not found")

    await tm.delete_task(task_id)
    return {"deleted": True, "task_id": task_id}


class SubmitInputRequest(BaseModel):
    """Request to submit input to a task awaiting input."""

    response: dict[str, Any] = Field(..., description="The input response data")


@router.post("/{task_id}/input")
async def submit_input(request: Request, task_id: str, body: SubmitInputRequest) -> dict[str, Any]:
    """Submit input to a task that is awaiting input.

    This stores the user's response and re-queues the task for processing.
    The task handler will receive the input in the task's input_response field.
    """
    kit = getattr(request.app.state, "kit", None)
    if kit is None:
        raise HTTPException(
            status_code=500,
            detail="AgentKit not configured. Pass kit to create_app().",
        )

    success = await kit.submit_input(task_id, body.response)
    if not success:
        raise HTTPException(
            status_code=400,
            detail=f"Task {task_id} not found or not in AWAITING_INPUT status",
        )

    return {"success": True, "task_id": task_id}


async def _sse_event_generator(
    request: Request,
    channel: str,
    redis_url: str,
    prefix: str | None,
    replay: bool,
    replay_task_id: str | None = None,
    event_filter: set[str] | None = None,
) -> AsyncGenerator[str, None]:
    """Generate SSE events from a Redis Pub/Sub channel.

    1. Optionally replays existing updates from a task's state.
    2. Subscribes to the given Pub/Sub channel for new events.
    3. Yields SSE-formatted strings until a terminal status is received
       or the client disconnects.

    Args:
        request: The incoming HTTP request (used for disconnect detection).
        channel: The Redis Pub/Sub channel to subscribe to.
        redis_url: Redis connection URL.
        prefix: Redis key prefix.
        replay: Whether to replay existing task updates on connect.
        replay_task_id: Task ID whose updates to replay (only used when replay=True).
        event_filter: If set, only yield events whose type is in this set.
    """
    client: Any = redis_lib.from_url(  # type: ignore[no-untyped-call]
        redis_url, decode_responses=True
    )
    pubsub = client.pubsub()

    try:
        # Subscribe before replay to avoid missing events between replay and listen
        await pubsub.subscribe(channel)

        # Replay existing updates so the client gets full history
        if replay and replay_task_id:
            tm = TaskManager(client, prefix=prefix)
            task = await tm.get_task(replay_task_id)
            if task:
                for update in task.updates:
                    if event_filter and "update" not in event_filter:
                        continue
                    event_data = {
                        "task_id": replay_task_id,
                        "message": update.message,
                        "update_type": update.update_type,
                        "metadata": update.metadata,
                        "updated_at": update.timestamp.isoformat(),
                    }
                    yield f"event: update\ndata: {json.dumps(event_data, default=str)}\n\n"

                # If task is already terminal, send status and close
                if task.status.value in _TERMINAL_STATUSES:
                    done_data: dict[str, Any] = {
                        "task_id": replay_task_id,
                        "status": task.status.value,
                    }
                    if task.result is not None:
                        done_data["result"] = task.result
                    if task.error_message is not None:
                        done_data["error"] = task.error_message
                    if event_filter is None or task.status.value in event_filter:
                        yield f"event: {task.status.value}\ndata: {json.dumps(done_data, default=str)}\n\n"
                    return

        # Stream live events from Pub/Sub
        while True:
            # Check if client disconnected
            if await request.is_disconnected():
                break

            message = await pubsub.get_message(ignore_subscribe_messages=True, timeout=1.0)
            if message is None:
                # Send SSE comment as keepalive
                yield ": keepalive\n\n"  # noqa: RUF001
                continue

            try:
                event_data = json.loads(message["data"])
            except (json.JSONDecodeError, TypeError):
                continue

            status = event_data.get("status")

            # Determine SSE event type: terminal status wins, then
            # explicit event_type (e.g. "token"), fallback to "update"
            if status in _TERMINAL_STATUSES:
                event_type = status
            else:
                event_type = event_data.get("event_type", "update")

            # Apply event filter
            if event_filter and event_type not in event_filter:
                # Still close on terminal status even if filtered
                if status in _TERMINAL_STATUSES:
                    break
                continue

            yield f"event: {event_type}\ndata: {json.dumps(event_data, default=str)}\n\n"

            # Close stream on terminal status
            if status in _TERMINAL_STATUSES:
                break
    finally:
        await pubsub.unsubscribe(channel)
        await pubsub.aclose()
        await client.aclose()


def _parse_events_param(events: str | None) -> set[str] | None:
    """Parse a comma-separated events query parameter into a set.

    Returns None if no filter was provided (meaning: all events).
    """
    if not events:
        return None
    return {e.strip() for e in events.split(",") if e.strip()}


@router.get("/{task_id}/stream")
async def stream_task(
    request: Request,
    task_id: str,
    replay: bool = True,
    events: str | None = Query(
        default=None,
        description="Comma-separated event types to include (e.g. 'token,done,failed'). Default: all.",
    ),
) -> StreamingResponse:
    """Stream task updates via Server-Sent Events (SSE).

    Subscribes to the task's Redis Pub/Sub channel and pushes
    TaskUpdate events to the client in real time. Existing updates
    are replayed on connect (unless replay=false).

    SSE event types:
    - ``update``: A progress update (message, metadata)
    - ``token``: A single LLM token (ephemeral, not persisted)
    - ``done``: Task completed successfully (includes result)
    - ``failed``: Task failed (includes error)
    - ``cancelled``: Task was cancelled

    Args:
        task_id: The task ID to stream updates for.
        replay: Whether to replay existing updates on connect (default: true).
        events: Comma-separated event type filter (default: all events).

    Example (curl):
        ``curl -N http://localhost:8000/tasks/{task_id}/stream``
        ``curl -N 'http://localhost:8000/tasks/{task_id}/stream?events=token,done'``

    Example (JavaScript):
        ```js
        const es = new EventSource('/tasks/{task_id}/stream');
        es.addEventListener('update', (e) => console.log(JSON.parse(e.data)));
        es.addEventListener('done', (e) => { console.log(JSON.parse(e.data)); es.close(); });
        ```
    """
    stream_config: StreamConfig = getattr(request.app.state, "stream_config", StreamConfig())
    if not stream_config.enabled:
        raise HTTPException(
            status_code=404,
            detail="SSE streaming is not enabled. Pass stream_config=StreamConfig(enabled=True) to create_app().",
        )

    tm = get_task_manager(request)
    task = await tm.get_task(task_id)
    if not task:
        raise HTTPException(status_code=404, detail=f"Task {task_id} not found")

    redis_url = request.app.state.redis_url
    prefix = getattr(request.app.state, "prefix", None)
    channel = RedisKeys.task_updates_channel(task_id, prefix)
    event_filter = _parse_events_param(events)

    return StreamingResponse(
        _sse_event_generator(
            request,
            channel,
            redis_url,
            prefix,
            replay,
            replay_task_id=task_id,
            event_filter=event_filter,
        ),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )


@router.get("/sessions/{session_id}/stream")
async def stream_session(
    request: Request,
    session_id: str,
    events: str | None = Query(
        default=None,
        description="Comma-separated event types to include. Default: all.",
    ),
) -> StreamingResponse:
    """Stream updates for all tasks in a session via SSE.

    Subscribes to the session-level Pub/Sub channel. Requires
    ``ChannelScope.SESSION`` in the ``StreamConfig.channels``.

    Args:
        session_id: The session ID to stream updates for.
        events: Comma-separated event type filter (default: all events).
    """
    stream_config: StreamConfig = getattr(request.app.state, "stream_config", StreamConfig())
    if not stream_config.enabled:
        raise HTTPException(
            status_code=404,
            detail="SSE streaming is not enabled.",
        )

    redis_url = request.app.state.redis_url
    prefix = getattr(request.app.state, "prefix", None)
    channel = RedisKeys.session_updates_channel(session_id, prefix)
    event_filter = _parse_events_param(events)

    return StreamingResponse(
        _sse_event_generator(
            request,
            channel,
            redis_url,
            prefix,
            replay=False,
            event_filter=event_filter,
        ),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )


@router.get("/stream/global")
async def stream_global(
    request: Request,
    events: str | None = Query(
        default=None,
        description="Comma-separated event types to include. Default: all.",
    ),
) -> StreamingResponse:
    """Stream updates for all tasks globally via SSE.

    Subscribes to the global Pub/Sub channel. Requires
    ``ChannelScope.GLOBAL`` in the ``StreamConfig.channels``.

    Useful for dashboards and multi-agent monitoring.

    Args:
        events: Comma-separated event type filter (default: all events).
    """
    stream_config: StreamConfig = getattr(request.app.state, "stream_config", StreamConfig())
    if not stream_config.enabled:
        raise HTTPException(
            status_code=404,
            detail="SSE streaming is not enabled.",
        )

    redis_url = request.app.state.redis_url
    prefix = getattr(request.app.state, "prefix", None)
    channel = RedisKeys.global_updates_channel(prefix)
    event_filter = _parse_events_param(events)

    return StreamingResponse(
        _sse_event_generator(
            request,
            channel,
            redis_url,
            prefix,
            replay=False,
            event_filter=event_filter,
        ),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )
