"""Versioned API surface for unified CLI compatibility."""

from __future__ import annotations

from datetime import UTC
from typing import Any
from uuid import uuid4

import redis.asyncio as redis_lib
from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel, Field

from redis_agent_kit.models import Caller, CallerType, TaskStatus
from redis_agent_kit.task_manager import TaskManager

router = APIRouter(prefix="/v1")


def _request_id() -> str:
    return f"req_{uuid4().hex}"


def _meta(request: Request) -> dict[str, Any]:
    return {
        "requestId": _request_id(),
        "serverType": "rak_oss",
        "version": request.app.version,
    }


def _ok(request: Request, data: dict[str, Any]) -> dict[str, Any]:
    return {"ok": True, "data": data, "meta": _meta(request)}


def _runtime_only_error(request: Request) -> HTTPException:
    return HTTPException(
        status_code=501,
        detail={
            "ok": False,
            "error": {
                "code": "runtime_only_feature",
                "message": "This command requires Redis Agent Runtime.",
                "details": {"requiredFeature": "deploy.up"},
            },
            "meta": _meta(request),
        },
    )


def _task_manager(request: Request) -> TaskManager:
    redis_url = request.app.state.redis_url
    prefix = getattr(request.app.state, "prefix", None)
    client: Any = redis_lib.from_url(redis_url)  # type: ignore[no-untyped-call]
    return TaskManager(client, prefix=prefix)


def _default_agent_id(request: Request) -> str:
    value = getattr(request.app.state, "default_agent_id", "default")
    return str(value)


def _default_agent_record(request: Request) -> dict[str, Any]:
    return {
        "agentId": _default_agent_id(request),
        "displayName": "Default Agent",
        "ready": True,
        "workerCount": 1,
        "lastHeartbeatAt": None,
        "executionMode": "self_hosted_worker",
    }


def _require_agent(request: Request, agent_id: str) -> None:
    if agent_id != _default_agent_id(request):
        raise HTTPException(status_code=404, detail=f"Agent {agent_id} not found")


class UnifiedTaskRequest(BaseModel):
    """Unified create-task payload."""

    threadId: str | None = None
    request: dict[str, Any] = Field(default_factory=dict)
    context: dict[str, Any] = Field(default_factory=dict)
    caller: dict[str, Any] | None = None


class TaskInputRequest(BaseModel):
    """Input submission payload."""

    response: dict[str, Any]


def _extract_message(payload: UnifiedTaskRequest) -> str:
    request_payload = payload.request
    if not isinstance(request_payload, dict):
        return ""
    raw_input = request_payload.get("input", {})
    if isinstance(raw_input, dict):
        message = raw_input.get("message")
        if isinstance(message, str) and message.strip():
            return message.strip()
        text = raw_input.get("text")
        if isinstance(text, str) and text.strip():
            return text.strip()
    return "Task request"


def _build_caller(raw_caller: dict[str, Any] | None) -> Caller | None:
    if raw_caller is None:
        return None
    raw_type = raw_caller.get("type", "human")
    caller_type = CallerType(raw_type)
    caller_id = raw_caller.get("id")
    caller_name = raw_caller.get("name")
    metadata = raw_caller.get("metadata", {})
    if not isinstance(metadata, dict):
        metadata = {}
    return Caller(
        type=caller_type,
        id=caller_id if isinstance(caller_id, str) else None,
        name=caller_name if isinstance(caller_name, str) else None,
        metadata=metadata,
    )


def _task_to_unified(task: Any) -> dict[str, Any]:
    return {
        "taskId": task.task_id,
        "threadId": task.session_id,
        "status": task.status.value,
        "updates": [
            {
                "timestamp": update.timestamp.astimezone(UTC).isoformat(),
                "message": update.message,
                "type": update.update_type,
                "metadata": update.metadata,
            }
            for update in task.updates
        ],
        "result": task.result,
        "errorMessage": task.error_message,
        "createdAt": task.created_at.astimezone(UTC).isoformat(),
        "updatedAt": task.updated_at.astimezone(UTC).isoformat(),
    }


@router.get("/healthz")
async def healthz(request: Request) -> dict[str, Any]:
    return _ok(request, {"status": "healthy"})


@router.get("/capabilities")
async def capabilities(request: Request) -> dict[str, Any]:
    protocols = ["rest"]
    if getattr(request.app.state, "enable_a2a", False):
        protocols.append("a2a")
    if getattr(request.app.state, "enable_acp", False):
        protocols.append("acp")
    if getattr(request.app.state, "enable_mcp", False):
        protocols.append("mcp")
    return _ok(
        request,
        {
            "serverType": "rak_oss",
            "protocols": protocols,
            "features": {
                "health.read": True,
                "agents.read": True,
                "tasks.run": True,
                "tasks.list": True,
                "tasks.get": True,
                "tasks.result": True,
                "tasks.logs": True,
                "tasks.cancel": True,
                "tasks.input": True,
                "deploy.up": False,
            },
        },
    )


@router.get("/projects/{project_id}/agents")
async def list_agents(request: Request, project_id: str) -> dict[str, Any]:
    return _ok(request, {"projectId": project_id, "agents": [_default_agent_record(request)]})


@router.get("/projects/{project_id}/agents/{agent_id}")
async def get_agent(request: Request, project_id: str, agent_id: str) -> dict[str, Any]:
    _require_agent(request, agent_id)
    return _ok(request, {"projectId": project_id, "agent": _default_agent_record(request)})


@router.post("/projects/{project_id}/agents/{agent_id}/tasks")
async def create_task(
    request: Request,
    project_id: str,
    agent_id: str,
    body: UnifiedTaskRequest,
) -> dict[str, Any]:
    _require_agent(request, agent_id)
    kit = getattr(request.app.state, "kit", None)
    if kit is None:
        raise HTTPException(status_code=500, detail="AgentKit not configured.")
    caller = _build_caller(body.caller)
    message = _extract_message(body)
    result = await kit.create_and_submit_task(
        message=message,
        context=body.context,
        session_id=body.threadId,
        caller=caller,
    )
    payload = {
        "projectId": project_id,
        "agentId": agent_id,
        "taskId": result.get("task_id"),
        "threadId": result.get("session_id"),
        "status": result.get("status", "queued"),
        "message": result.get("message", ""),
    }
    return _ok(request, payload)


@router.get("/projects/{project_id}/agents/{agent_id}/tasks")
async def list_tasks(
    request: Request,
    project_id: str,
    agent_id: str,
    status: str | None = None,
    limit: int = 50,
) -> dict[str, Any]:
    _require_agent(request, agent_id)
    manager = _task_manager(request)
    status_filter = TaskStatus(status) if status else None
    tasks = await manager.list_tasks(status=status_filter)
    entries = [_task_to_unified(task) for task in tasks[: max(1, limit)]]
    return _ok(
        request,
        {
            "projectId": project_id,
            "agentId": agent_id,
            "tasks": entries,
            "total": len(entries),
        },
    )


@router.get("/projects/{project_id}/agents/{agent_id}/tasks/{task_id}")
async def get_task(
    request: Request,
    project_id: str,
    agent_id: str,
    task_id: str,
) -> dict[str, Any]:
    _require_agent(request, agent_id)
    manager = _task_manager(request)
    task = await manager.get_task(task_id)
    if task is None:
        raise HTTPException(status_code=404, detail=f"Task {task_id} not found")
    return _ok(
        request,
        {
            "projectId": project_id,
            "agentId": agent_id,
            "task": _task_to_unified(task),
        },
    )


@router.get("/projects/{project_id}/agents/{agent_id}/tasks/{task_id}/result")
async def get_task_result(
    request: Request,
    project_id: str,
    agent_id: str,
    task_id: str,
) -> dict[str, Any]:
    _require_agent(request, agent_id)
    manager = _task_manager(request)
    task = await manager.get_task(task_id)
    if task is None:
        raise HTTPException(status_code=404, detail=f"Task {task_id} not found")
    return _ok(
        request,
        {
            "projectId": project_id,
            "agentId": agent_id,
            "taskId": task.task_id,
            "status": task.status.value,
            "result": task.result,
            "errorMessage": task.error_message,
        },
    )


@router.get("/projects/{project_id}/agents/{agent_id}/tasks/{task_id}/logs")
async def get_task_logs(
    request: Request,
    project_id: str,
    agent_id: str,
    task_id: str,
    limit: int = 200,
) -> dict[str, Any]:
    _require_agent(request, agent_id)
    manager = _task_manager(request)
    task = await manager.get_task(task_id)
    if task is None:
        raise HTTPException(status_code=404, detail=f"Task {task_id} not found")
    updates = task.updates[-max(1, limit) :]
    logs = [
        {
            "timestamp": update.timestamp.astimezone(UTC).isoformat(),
            "message": update.message,
            "level": update.update_type,
            "source": "updates",
            "metadata": update.metadata,
        }
        for update in updates
    ]
    return _ok(
        request,
        {
            "projectId": project_id,
            "agentId": agent_id,
            "taskId": task_id,
            "logs": logs,
            "total": len(logs),
        },
    )


@router.post("/projects/{project_id}/agents/{agent_id}/tasks/{task_id}/cancel")
async def cancel_task(
    request: Request,
    project_id: str,
    agent_id: str,
    task_id: str,
) -> dict[str, Any]:
    _require_agent(request, agent_id)
    manager = _task_manager(request)
    task = await manager.get_task(task_id)
    if task is None:
        raise HTTPException(status_code=404, detail=f"Task {task_id} not found")
    await manager.update_status(task_id, TaskStatus.CANCELLED)
    return _ok(
        request,
        {
            "projectId": project_id,
            "agentId": agent_id,
            "taskId": task_id,
            "status": "cancelled",
        },
    )


@router.post("/projects/{project_id}/agents/{agent_id}/tasks/{task_id}/input")
async def submit_task_input(
    request: Request,
    project_id: str,
    agent_id: str,
    task_id: str,
    body: TaskInputRequest,
) -> dict[str, Any]:
    _require_agent(request, agent_id)
    kit = getattr(request.app.state, "kit", None)
    if kit is None:
        raise HTTPException(status_code=500, detail="AgentKit not configured.")
    success = await kit.submit_input(task_id, body.response)
    if not success:
        raise HTTPException(
            status_code=400,
            detail=f"Task {task_id} not found or not awaiting input",
        )
    return _ok(
        request,
        {
            "projectId": project_id,
            "agentId": agent_id,
            "taskId": task_id,
            "submitted": True,
        },
    )


@router.post("/projects/{project_id}/agents/{agent_id}/up")
async def up_not_supported(request: Request, project_id: str, agent_id: str) -> dict[str, Any]:
    del project_id, agent_id
    raise _runtime_only_error(request)
