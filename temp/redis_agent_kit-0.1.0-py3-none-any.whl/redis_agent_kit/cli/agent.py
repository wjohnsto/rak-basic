"""CLI agent commands."""

from __future__ import annotations

import click

from redis_agent_kit.cli.api_common import (
    call_api,
    echo_json,
    maybe_project,
    require_api_base,
)


@click.group("agent")
def agent_group() -> None:
    """Agent discovery commands."""


@agent_group.command("list")
@click.option("--project", default=None, help="Project ID override")
@click.pass_context
def list_agents(ctx: click.Context, project: str | None) -> None:
    """List available agents."""
    base = require_api_base(ctx.obj.api_base)
    project_id = maybe_project(project, ctx.obj.project)
    if not project_id:
        raise click.ClickException("Project ID is required. Set --project or default project.")
    payload = call_api(
        api_base=base,
        token=ctx.obj.token,
        method="GET",
        path=f"/v1/projects/{project_id}/agents",
    )
    echo_json(payload)


@agent_group.command("get")
@click.argument("agent_id")
@click.option("--project", default=None, help="Project ID override")
@click.pass_context
def get_agent(ctx: click.Context, agent_id: str, project: str | None) -> None:
    """Get one agent by ID."""
    base = require_api_base(ctx.obj.api_base)
    project_id = maybe_project(project, ctx.obj.project)
    if not project_id:
        raise click.ClickException("Project ID is required. Set --project or default project.")
    payload = call_api(
        api_base=base,
        token=ctx.obj.token,
        method="GET",
        path=f"/v1/projects/{project_id}/agents/{agent_id}",
    )
    echo_json(payload)
