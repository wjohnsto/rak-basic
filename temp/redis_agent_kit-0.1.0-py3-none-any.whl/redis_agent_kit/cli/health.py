"""CLI health command."""

from __future__ import annotations

import click

from redis_agent_kit.cli.api_common import call_api, echo_json, require_api_base


@click.command("health")
@click.pass_context
def health_cmd(ctx: click.Context) -> None:
    """Check API health."""
    base = require_api_base(ctx.obj.api_base)
    payload = call_api(
        api_base=base,
        token=ctx.obj.token,
        method="GET",
        path="/v1/healthz",
    )
    echo_json(payload)
