"""CLI task commands (API-backed)."""

from __future__ import annotations

from typing import Any

import click

from redis_agent_kit.cli.api_common import (
    call_api,
    echo_json,
    maybe_project,
    parse_json_file,
    parse_json_object,
    require_agent,
    require_api_base,
)


@click.group("task")
def task_group() -> None:
    """Task lifecycle commands."""


def _resolve_scope(
    ctx: click.Context,
    *,
    project: str | None,
    agent: str | None,
) -> tuple[str, str, str]:
    base = require_api_base(ctx.obj.api_base)
    project_id = maybe_project(project, ctx.obj.project)
    if not project_id:
        raise click.ClickException("Project ID is required. Set --project or default project.")
    agent_id = require_agent(agent, ctx.obj.agent)
    return base, project_id, agent_id


def _extract_request_payload(
    *,
    protocol: str,
    input_json: str | None,
    input_file: str | None,
    request_file: str | None,
) -> dict[str, Any]:
    if request_file:
        return parse_json_file(request_file)
    if input_json and input_file:
        raise click.ClickException("Use only one of --input-json or --input-file.")
    input_payload: dict[str, Any] = {}
    if input_json:
        input_payload = parse_json_object(input_json)
    elif input_file:
        input_payload = parse_json_file(input_file)
    return {"protocol": protocol, "input": input_payload}


def _extract_agent_output_from_logs(
    logs: list[dict[str, Any]],
) -> dict[str, Any] | None:
    """Best-effort extraction of agent output from task log entries."""
    for entry in reversed(logs):
        if not isinstance(entry, dict):
            continue

        metadata = entry.get("metadata")
        if isinstance(metadata, dict):
            output = metadata.get("output")
            if isinstance(output, dict):
                return output
            if isinstance(output, str) and output.strip():
                return {"reply": output.strip()}

            reply = metadata.get("reply")
            if isinstance(reply, str) and reply.strip():
                return {"reply": reply.strip()}

        message = entry.get("message")
        if not isinstance(message, str) or not message.strip():
            continue

        level = str(entry.get("level") or entry.get("update_type") or "").lower()
        if level in {"tool_call", "reflection"}:
            continue

        return {"reply": message.strip()}

    return None


@task_group.command("run")
@click.option("--project", default=None, help="Project ID override")
@click.option("--agent", "agent_id", default=None, help="Agent ID override")
@click.option("--thread-id", default=None, help="Optional thread/session ID")
@click.option("--protocol", default="rest", show_default=True, help="Request protocol")
@click.option("--input-json", default=None, help="Inline request input JSON object")
@click.option("--input-file", default=None, help="Path to request input JSON object")
@click.option("--request-file", default=None, help="Path to full request JSON object")
@click.option("--context-json", default=None, help="Inline task context JSON object")
@click.pass_context
def run_task(
    ctx: click.Context,
    project: str | None,
    agent_id: str | None,
    thread_id: str | None,
    protocol: str,
    input_json: str | None,
    input_file: str | None,
    request_file: str | None,
    context_json: str | None,
) -> None:
    """Create and queue a task."""
    base, project_id, resolved_agent = _resolve_scope(ctx, project=project, agent=agent_id)
    request_payload = _extract_request_payload(
        protocol=protocol,
        input_json=input_json,
        input_file=input_file,
        request_file=request_file,
    )
    context_payload: dict[str, Any] = {}
    if context_json:
        context_payload = parse_json_object(context_json)

    payload = {
        "threadId": thread_id,
        "request": request_payload,
        "context": context_payload,
    }
    result = call_api(
        api_base=base,
        token=ctx.obj.token,
        method="POST",
        path=f"/v1/projects/{project_id}/agents/{resolved_agent}/tasks",
        payload=payload,
    )
    echo_json(result)


@task_group.command("list")
@click.option("--project", default=None, help="Project ID override")
@click.option("--agent", "agent_id", default=None, help="Agent ID override")
@click.option("--status", default=None, help="Optional task status filter")
@click.option("--limit", default=50, show_default=True, help="Maximum tasks to return")
@click.pass_context
def list_tasks(
    ctx: click.Context,
    project: str | None,
    agent_id: str | None,
    status: str | None,
    limit: int,
) -> None:
    """List tasks."""
    base, project_id, resolved_agent = _resolve_scope(ctx, project=project, agent=agent_id)
    params: dict[str, Any] = {"limit": limit}
    if status:
        params["status"] = status
    result = call_api(
        api_base=base,
        token=ctx.obj.token,
        method="GET",
        path=f"/v1/projects/{project_id}/agents/{resolved_agent}/tasks",
        params=params,
    )
    echo_json(result)


@task_group.command("get")
@click.argument("task_id")
@click.option("--project", default=None, help="Project ID override")
@click.option("--agent", "agent_id", default=None, help="Agent ID override")
@click.pass_context
def get_task(ctx: click.Context, task_id: str, project: str | None, agent_id: str | None) -> None:
    """Get task details."""
    base, project_id, resolved_agent = _resolve_scope(ctx, project=project, agent=agent_id)
    result = call_api(
        api_base=base,
        token=ctx.obj.token,
        method="GET",
        path=f"/v1/projects/{project_id}/agents/{resolved_agent}/tasks/{task_id}",
    )
    echo_json(result)


@task_group.command("status")
@click.argument("task_id")
@click.option("--project", default=None, help="Project ID override")
@click.option("--agent", "agent_id", default=None, help="Agent ID override")
@click.pass_context
def task_status(
    ctx: click.Context,
    task_id: str,
    project: str | None,
    agent_id: str | None,
) -> None:
    """Get current task status."""
    base, project_id, resolved_agent = _resolve_scope(ctx, project=project, agent=agent_id)
    result = call_api(
        api_base=base,
        token=ctx.obj.token,
        method="GET",
        path=f"/v1/projects/{project_id}/agents/{resolved_agent}/tasks/{task_id}",
    )
    echo_json(result)


@task_group.command("result")
@click.argument("task_id")
@click.option("--project", default=None, help="Project ID override")
@click.option("--agent", "agent_id", default=None, help="Agent ID override")
@click.pass_context
def task_result(
    ctx: click.Context,
    task_id: str,
    project: str | None,
    agent_id: str | None,
) -> None:
    """Get task result payload."""
    base, project_id, resolved_agent = _resolve_scope(ctx, project=project, agent=agent_id)
    result = call_api(
        api_base=base,
        token=ctx.obj.token,
        method="GET",
        path=f"/v1/projects/{project_id}/agents/{resolved_agent}/tasks/{task_id}/result",
    )
    echo_json(result)


@task_group.command("logs")
@click.argument("task_id")
@click.option("--project", default=None, help="Project ID override")
@click.option("--agent", "agent_id", default=None, help="Agent ID override")
@click.option("--limit", default=200, show_default=True, help="Max log lines")
@click.pass_context
def task_logs(
    ctx: click.Context,
    task_id: str,
    project: str | None,
    agent_id: str | None,
    limit: int,
) -> None:
    """Get task logs."""
    base, project_id, resolved_agent = _resolve_scope(ctx, project=project, agent=agent_id)
    result = call_api(
        api_base=base,
        token=ctx.obj.token,
        method="GET",
        path=f"/v1/projects/{project_id}/agents/{resolved_agent}/tasks/{task_id}/logs",
        params={"limit": limit},
    )
    echo_json(result)


@task_group.command("cancel")
@click.argument("task_id")
@click.option("--project", default=None, help="Project ID override")
@click.option("--agent", "agent_id", default=None, help="Agent ID override")
@click.pass_context
def cancel_task(
    ctx: click.Context,
    task_id: str,
    project: str | None,
    agent_id: str | None,
) -> None:
    """Cancel a task."""
    base, project_id, resolved_agent = _resolve_scope(ctx, project=project, agent=agent_id)
    result = call_api(
        api_base=base,
        token=ctx.obj.token,
        method="POST",
        path=f"/v1/projects/{project_id}/agents/{resolved_agent}/tasks/{task_id}/cancel",
    )
    echo_json(result)


@task_group.command("input")
@click.argument("task_id")
@click.option("--project", default=None, help="Project ID override")
@click.option("--agent", "agent_id", default=None, help="Agent ID override")
@click.option("--response-json", required=True, help="Input response JSON object")
@click.pass_context
def submit_task_input(
    ctx: click.Context,
    task_id: str,
    project: str | None,
    agent_id: str | None,
    response_json: str,
) -> None:
    """Submit user input to an awaiting task."""
    base, project_id, resolved_agent = _resolve_scope(ctx, project=project, agent=agent_id)
    response_payload = parse_json_object(response_json)
    result = call_api(
        api_base=base,
        token=ctx.obj.token,
        method="POST",
        path=f"/v1/projects/{project_id}/agents/{resolved_agent}/tasks/{task_id}/input",
        payload={"response": response_payload},
    )
    echo_json(result)
