"""CLI up command."""

from __future__ import annotations

from typing import Any

import click

from redis_agent_kit.cli.api_common import (
    call_api,
    echo_json,
    maybe_project,
    parse_json_file,
    require_agent,
    require_api_base,
)


@click.command("up")
@click.option("--project", default=None, help="Project ID override")
@click.option("--agent", "agent_id", default=None, help="Agent ID override")
@click.option("--source", default=".", show_default=True, help="Source directory")
@click.option("--entrypoint", required=True, help="Agent entrypoint reference")
@click.option("--build", "build_id", default=None, help="Optional build ID override")
@click.option("--deployment", default=None, help="Optional deployment ID override")
@click.option("--version", default=None, help="Optional version ID override")
@click.option("--team-manifest", default=None, help="Optional team manifest JSON file")
@click.pass_context
def up_cmd(
    ctx: click.Context,
    project: str | None,
    agent_id: str | None,
    source: str,
    entrypoint: str,
    build_id: str | None,
    deployment: str | None,
    version: str | None,
    team_manifest: str | None,
) -> None:
    """Deploy agent source through Redis Agent Runtime."""
    base = require_api_base(ctx.obj.api_base)
    project_id = maybe_project(project, ctx.obj.project)
    if not project_id:
        raise click.ClickException("Project ID is required. Set --project or default project.")
    resolved_agent = require_agent(agent_id, ctx.obj.agent)

    payload: dict[str, Any] = {
        "source": source,
        "entrypoint": entrypoint,
    }
    if build_id:
        payload["buildId"] = build_id
    if deployment:
        payload["deploymentId"] = deployment
    if version:
        payload["versionId"] = version
    if team_manifest:
        payload["teamManifest"] = parse_json_file(team_manifest)

    result = call_api(
        api_base=base,
        token=ctx.obj.token,
        method="POST",
        path=f"/v1/projects/{project_id}/agents/{resolved_agent}/up",
        payload=payload,
    )
    echo_json(result)
