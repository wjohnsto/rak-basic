"""Worker CLI command for running background workers."""

import asyncio
import importlib
from datetime import timedelta

import click
from docket import Worker

from redis_agent_kit.config import get_settings


@click.command()
@click.option(
    "--concurrency",
    "-c",
    default=4,
    help="Number of concurrent tasks to process.",
)
@click.option(
    "--redis-url",
    default=None,
    envvar=["REDIS_URL", "RAK_REDIS_URL"],
    help="Redis connection URL (defaults to settings).",
)
@click.option(
    "--name",
    default=None,
    envvar=["RAK_TASK__QUEUE_NAME", "RAK_TASK_QUEUE_NAME"],
    help="Worker queue name (defaults to settings).",
)
@click.option(
    "--tasks",
    "tasks_module",
    default=None,
    help="Python module path containing tasks (e.g., 'myapp.tasks:TASK_LIST').",
)
def worker(
    concurrency: int,
    redis_url: str | None,
    name: str | None,
    tasks_module: str | None,
) -> None:
    """Start a background worker to process tasks.

    The worker will process tasks from the specified queue.
    Tasks must be registered before the worker can process them.

    Examples:

        # Start worker with default settings
        rak worker

        # Start with custom concurrency
        rak worker --concurrency 8

        # Start with custom Redis URL
        rak worker --redis-url redis://myhost:6379

        # Start with tasks from a module
        rak worker --tasks myapp.tasks:TASK_LIST
    """

    settings = get_settings()
    resolved_redis_url = redis_url or settings.redis_url
    resolved_queue_name = name or settings.task.queue_name

    async def _run_worker() -> None:
        click.echo(f"Starting worker (concurrency={concurrency}, queue={resolved_queue_name})")
        click.echo(f"Connecting to Redis: {resolved_redis_url}")

        # Validate tasks module path if provided
        if tasks_module:
            try:
                module_path, attr_name = tasks_module.rsplit(":", 1)
                module = importlib.import_module(module_path)
                task_obj = getattr(module, attr_name)
                if callable(task_obj):
                    click.echo(f"Loaded task: {tasks_module}")
                else:
                    click.echo(f"Loaded {len(task_obj)} tasks from {tasks_module}")
            except Exception as e:
                click.echo(f"Error loading tasks: {e}", err=True)
                raise click.Abort()

        try:
            click.echo("Worker started. Press Ctrl+C to stop.")
            worker_tasks = [tasks_module] if tasks_module else []
            await Worker.run(
                docket_name=resolved_queue_name,
                url=resolved_redis_url,
                concurrency=concurrency,
                redelivery_timeout=timedelta(minutes=5),
                tasks=worker_tasks,
            )
        except Exception as e:
            click.echo(f"Worker error: {e}", err=True)
            raise

    try:
        asyncio.run(_run_worker())
    except KeyboardInterrupt:
        click.echo("\nWorker stopped.")
