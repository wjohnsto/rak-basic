"""
Redis Agent Kit configuration.

Configuration is loaded from (in order of precedence):
1. Defaults defined in Settings class
2. YAML/JSON config file (via RAK_CONFIG env var)
3. Environment variables (RAK_* prefix)
4. Programmatic override via Settings constructor

Environment variable examples:
    RAK_REDIS_URL=redis://localhost:6379
    RAK_MEMORY__ENABLED=true
    RAK_TASK__QUEUE_NAME=my-agents

Config file example (config.yaml):
    redis_url: "redis://localhost:6379"
    memory:
      enabled: true
      forgetting_enabled: false
    task:
      queue_name: "my-agents"
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

import yaml  # type: ignore[import-untyped]
from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class MemorySettings(BaseSettings):
    """Memory configuration.

    Controls working memory (conversations) and long-term memory (persistent facts).
    Implementation uses agent-memory-server internally, but users don't need to
    know or configure that directly.
    """

    model_config = SettingsConfigDict(env_prefix="RAK_MEMORY_")

    # Core toggles
    enabled: bool = True
    long_term_enabled: bool = True

    # Working memory
    auto_summarization: bool = True
    summarization_threshold: float = 0.7  # Fraction of context triggering summarization
    session_ttl_seconds: int | None = None  # None = no expiry

    # Long-term memory extraction
    enable_extraction: bool = True
    extraction_strategy: str = "discrete"  # discrete, summary, preferences

    # Deduplication
    deduplication_threshold: float = 0.35  # Semantic similarity threshold

    # Forgetting (memory cleanup)
    forgetting_enabled: bool = False
    forgetting_max_age_days: float | None = None
    forgetting_max_inactive_days: float | None = None


class TaskSettings(BaseSettings):
    """Task and queue configuration.

    Controls how tasks are queued and processed.
    Implementation uses Docket internally, but users don't need to
    know or configure that directly.
    """

    model_config = SettingsConfigDict(env_prefix="RAK_TASK_")

    queue_name: str = "redis-agent-kit"
    default_timeout_seconds: int = 300
    max_retries: int = 3


class ModelSettings(BaseSettings):
    """LLM configuration."""

    model_config = SettingsConfigDict(env_prefix="RAK_MODEL_")

    default_model: str = "gpt-4o"
    fast_model: str = "gpt-4o-mini"  # For quick tasks
    embedding_model: str = "text-embedding-3-small"

    # API keys (optional - can use provider env vars directly)
    openai_api_key: str | None = None
    anthropic_api_key: str | None = None


class SideEffectSettings(BaseSettings):
    """Configuration for side effect caching (reentrant tasks).

    Side effects allow expensive operations to be cached across task re-runs,
    essential for handlers that pause and resume via request_input/submit_input.
    """

    model_config = SettingsConfigDict(env_prefix="RAK_SIDE_EFFECT_")

    # Default TTL for side effects (None = persist until manually cleared)
    default_ttl_hours: float | None = 1.0

    # Pattern to trigger clearing (e.g., "all", "function_name", "prefix:*")
    clear_pattern: str | None = None

    # Redis key prefix
    key_prefix: str = "rak:side_effect"


class Settings(BaseSettings):
    """
    Redis Agent Kit configuration.

    Example usage:
        from redis_agent_kit import Settings, AgentKit

        # Use defaults
        kit = AgentKit()

        # Use config file
        # export RAK_CONFIG=/path/to/config.yaml
        kit = AgentKit()

        # Programmatic
        settings = Settings(redis_url="redis://prod:6379")
        kit = AgentKit(settings=settings)
    """

    model_config = SettingsConfigDict(
        env_prefix="RAK_",
        env_nested_delimiter="__",
        env_file=".env",
        extra="ignore",
    )

    # Core
    redis_url: str = "redis://localhost:6379"
    namespace: str | None = None  # Optional namespace for all keys

    # Nested settings
    memory: MemorySettings = Field(default_factory=MemorySettings)
    task: TaskSettings = Field(default_factory=TaskSettings)
    model: ModelSettings = Field(default_factory=ModelSettings)
    side_effect: SideEffectSettings = Field(default_factory=SideEffectSettings)

    # Logging
    log_level: str = "INFO"


# Global settings instance (lazy loaded)
_settings: Settings | None = None


def get_settings() -> Settings:
    """Get the global settings instance, loading from config if needed."""
    global _settings
    if _settings is None:
        _settings = load_settings()
    return _settings


def load_settings(config_path: str | Path | None = None) -> Settings:
    """
    Load settings from file and environment.

    Args:
        config_path: Path to YAML or JSON config file.
                    If None, checks RAK_CONFIG env var.

    Returns:
        Settings instance.
    """
    config_path = config_path or os.getenv("RAK_CONFIG")

    if config_path:
        config_data = _load_config_file(Path(config_path))
        return Settings(**config_data)

    return Settings()


def _load_config_file(path: Path) -> dict[str, Any]:
    """Load configuration from YAML or JSON file."""
    if not path.exists():
        raise FileNotFoundError(f"Config file not found: {path}")

    with open(path) as f:
        if path.suffix in (".yaml", ".yml"):
            return yaml.safe_load(f) or {}
        else:
            return json.load(f) or {}


def set_settings(settings: Settings) -> None:
    """Set the global settings instance."""
    global _settings
    _settings = settings


def reset_settings() -> None:
    """Reset the global settings to force reload."""
    global _settings
    _settings = None
