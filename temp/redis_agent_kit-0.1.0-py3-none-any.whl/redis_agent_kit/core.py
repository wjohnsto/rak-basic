"""Core module for Redis Agent Kit."""

from __future__ import annotations

import inspect
import logging
from collections.abc import Callable, Coroutine
from dataclasses import dataclass
from datetime import timedelta
from typing import Any, cast

import httpx
import redis.asyncio as redis_lib
from docket import Docket

from redis_agent_kit.config import Settings, get_settings
from redis_agent_kit.emitter import TaskEmitter
from redis_agent_kit.memory import Memory, NoOpMemory
from redis_agent_kit.middleware import MiddlewareChain, TaskContext, TaskMiddleware
from redis_agent_kit.models import Caller, TaskState
from redis_agent_kit.streaming import StreamConfig
from redis_agent_kit.task_manager import TaskManager

logger = logging.getLogger(__name__)


# Agent callable types
# Simple signature: (task_id, session_id, message, context) -> dict
AgentCallable = Callable[
    [str, str, str, dict[str, Any]],
    Coroutine[Any, Any, dict[str, Any]],
]

# Context-based signature: (ctx: TaskContext) -> dict (for middleware)
ContextAgentCallable = Callable[
    [TaskContext],
    Coroutine[Any, Any, dict[str, Any]],
]


@dataclass
class RetryConfig:
    """Configuration for task retry behavior."""

    attempts: int = 3
    delay: timedelta = timedelta(seconds=5)


@dataclass
class ConcurrencyConfig:
    """Configuration for task concurrency limits."""

    key: str
    max_concurrent: int = 1
    scope: str = "default"


async def create_task_with_session(
    task_manager: TaskManager,
    memory: Memory,
    message: str,
    context: dict[str, Any] | None = None,
    session_id: str | None = None,
    user_id: str | None = None,
) -> tuple[TaskState, str]:
    """Create a new task with a memory session.

    This is the primary entry point for starting a new conversation.
    It creates a memory session (if needed), adds the initial message, and creates a task.

    Args:
        task_manager: The TaskManager instance
        memory: The Memory instance
        message: The initial user message
        context: Optional context data (user info, instance IDs, etc.)
        session_id: Optional existing session ID
        user_id: Optional user ID for memory isolation

    Returns:
        Tuple of (TaskState, session_id)
    """
    # Bind memory to session
    bound_memory = memory.with_session(session_id, user_id)

    # Add initial message (creates session if needed)
    await bound_memory.add_message(role="user", content=message)

    # Create task
    task = await task_manager.create_task(
        session_id=bound_memory.session_id,
        message=message,
        context=context,
    )

    # session_id is guaranteed non-None after with_session()
    return task, cast(str, bound_memory.session_id)


class AgentKit:
    """Convenience class that bundles TaskManager, Memory, and helpers.

    This is the main entry point for using Redis Agent Kit in your application.
    Docket integration is internal - users only interact with tasks and memory.

    Example:
        async def my_agent(ctx: TaskContext) -> dict:
            # ctx.memory is always available
            await ctx.memory.add_message("assistant", "Processing...")
            return {"response": f"Processed: {ctx.message}"}

        kit = AgentKit("redis://localhost:6379", agent_callable=my_agent)

    Example (with middleware):
        from redis_agent_kit.middleware import RAGMiddleware, MemoryMiddleware

        async def my_agent(ctx: TaskContext) -> dict:
            # ctx.rag_context is injected by RAGMiddleware
            return {"response": f"Based on context: {ctx.rag_context}"}

        kit = AgentKit(
            "redis://localhost:6379",
            agent_callable=my_agent,
            middleware=[RAGMiddleware(), MemoryMiddleware()],
        )
    """

    def __init__(
        self,
        redis_url: str | None = None,
        *,
        redis_client: redis_lib.Redis | None = None,
        prefix: str | None = None,
        agent_callable: AgentCallable | ContextAgentCallable | None = None,
        middleware: list[TaskMiddleware] | None = None,
        queue_name: str | None = None,
        settings: Settings | None = None,
        auto_result_middleware: bool = True,
        enable_sse: bool = False,
        enable_streaming: bool = False,
        stream_config: StreamConfig | None = None,
    ):
        """Initialize AgentKit.

        Args:
            redis_url: Redis URL (e.g., "redis://localhost:6379"). Preferred.
            redis_client: Optional pre-created async Redis client. If provided,
                redis_url is still needed for background workers.
            prefix: Optional custom key prefix (default: 'rak')
            agent_callable: Your agent function. Can be either:
                - (task_id, session_id, message, context) -> dict
                - (ctx: TaskContext) -> dict (use with middleware)
            middleware: List of TaskMiddleware to apply (in order)
            queue_name: Background worker queue name (default from settings)
            settings: Optional Settings instance (uses global settings if not provided)
            auto_result_middleware: Automatically include ResultMiddleware (default: True).
                Set to False if you want full control over middleware.
            enable_sse: Enable Pub/Sub publishing for SSE streaming (default: False).
                Deprecated – use ``stream_config`` instead.
            enable_streaming: Enable lightweight Pub/Sub publishing for
                token-by-token streaming (default: False).
                Deprecated – use ``stream_config`` instead.
            stream_config: Structured streaming configuration. When provided,
                ``enable_sse`` and ``enable_streaming`` are ignored.

        Example:
            # Simple - just URL
            kit = AgentKit("redis://localhost:6379", agent_callable=my_agent)

            # With existing client
            client = redis.from_url("redis://localhost:6379")
            kit = AgentKit("redis://localhost:6379", redis_client=client, ...)

            # With StreamConfig
            kit = AgentKit(
                "redis://localhost:6379",
                stream_config=StreamConfig(enabled=True, channels={ChannelScope.TASK, ChannelScope.SESSION}),
            )
        """
        from redis_agent_kit.middleware import ResultMiddleware

        self._settings = settings or get_settings()

        # Resolve Redis URL
        self._redis_url = redis_url or self._settings.redis_url
        if not self._redis_url:
            raise ValueError(
                "Redis URL required. Pass redis_url or set RAK_REDIS_URL environment variable."
            )

        # Create or use provided client
        if redis_client is not None:
            self._redis = redis_client
        else:
            self._redis = redis_lib.from_url(self._redis_url)  # type: ignore[no-untyped-call]

        self._prefix = prefix or self._settings.namespace
        self._agent_callable = agent_callable
        self._queue_name = queue_name or self._settings.task.queue_name

        # Resolve StreamConfig
        if stream_config is not None:
            self._stream_config = stream_config
        else:
            self._stream_config = StreamConfig.from_booleans(enable_sse, enable_streaming)

        # Legacy accessors for backward compat
        self._enable_sse = self._stream_config.enabled
        self._enable_streaming = self._stream_config.enabled

        self._task_manager = TaskManager(
            self._redis,
            prefix=self._prefix,
            stream_config=self._stream_config,
        )

        # Build middleware list
        user_middleware = middleware or []

        # Auto-include ResultMiddleware unless user opts out or already has it
        if auto_result_middleware:
            has_result_middleware = any(isinstance(m, ResultMiddleware) for m in user_middleware)
            if not has_result_middleware:
                # ResultMiddleware should be outermost (first in list)
                self._middleware = [ResultMiddleware(), *user_middleware]
            else:
                self._middleware = user_middleware
        else:
            self._middleware = user_middleware

        # Initialize memory (always available, may be no-op if disabled)
        if self._settings.memory.enabled:
            self._memory = Memory(self._redis, namespace=self._settings.namespace)
        else:
            self._memory = NoOpMemory()

    @property
    def task_manager(self) -> TaskManager:
        """Get the TaskManager."""
        return self._task_manager

    @property
    def memory(self) -> Memory:
        """Get the Memory instance."""
        return self._memory

    @property
    def queue_name(self) -> str:
        """Get the background worker queue name."""
        return self._queue_name

    @property
    def redis_url(self) -> str:
        """Get the Redis URL for background workers."""
        return self._redis_url

    @property
    def worker_task(
        self,
    ) -> Callable[[str, str, str, dict[str, Any]], Coroutine[Any, Any, dict[str, Any]]]:
        """Get the worker task handler for use with Docket.

        This is the public API for getting a handler suitable for background workers.
        Use this instead of _create_wrapped_handler().

        Example:
            kit = AgentKit(client, agent_callable=my_agent, redis_url="redis://...")

            # For Docket workers:
            tasks = [kit.worker_task]

        Returns:
            Wrapped async function suitable for Docket workers

        Raises:
            ValueError: If no agent_callable is configured
        """
        return self._create_wrapped_handler()

    async def create_task(
        self,
        message: str,
        context: dict[str, Any] | None = None,
        session_id: str | None = None,
        user_id: str | None = None,
    ) -> tuple[TaskState, str]:
        """Create a new task with a memory session.

        Args:
            message: The initial user message
            context: Optional context data
            session_id: Optional existing session ID
            user_id: Optional user ID for memory isolation

        Returns:
            Tuple of (TaskState, session_id)
        """
        return await create_task_with_session(
            task_manager=self._task_manager,
            memory=self._memory,
            message=message,
            context=context,
            session_id=session_id,
            user_id=user_id,
        )

    async def create_and_submit_task(
        self,
        message: str,
        context: dict[str, Any] | None = None,
        session_id: str | None = None,
        caller: Caller | None = None,
        user_id: str | None = None,
        attachments: list[Any] | None = None,
    ) -> dict[str, Any]:
        """Create a task and submit for background processing via Docket.

        This is the primary method for creating tasks that will be processed
        asynchronously. Docket handles the background execution - users only
        see tasks and memory.

        Args:
            message: The user message/query
            context: Optional context data (user_id, instance_id, etc.)
            session_id: Optional existing session ID
            caller: Optional caller identity (who is creating this task)
            user_id: Optional user ID for memory isolation
            attachments: Optional list of Attachment objects for multi-modal input

        Returns:
            Dict with task_id, session_id, and status

        Raises:
            ValueError: If no agent_callable is configured
        """
        if self._agent_callable is None:
            raise ValueError(
                "No agent_callable configured. Pass agent_callable to AgentKit() "
                "to use create_and_submit_task()."
            )

        # Bind memory to session
        bound_memory = self._memory.with_session(session_id, user_id)

        # Add message to memory (creates session if needed)
        await bound_memory.add_message(role="user", content=message)

        # Create task
        task = await self._task_manager.create_task(
            session_id=bound_memory.session_id,
            message=message,
            context=context,
            caller=caller,
        )

        # Create wrapped handler with middleware
        handler = self._create_wrapped_handler()

        # Prepare context with attachments
        task_context = context.copy() if context else {}
        if attachments:
            # Serialize attachments for Docket (they're Pydantic models)
            task_context["_attachments"] = [
                a.model_dump() if hasattr(a, "model_dump") else a for a in attachments
            ]

        # Submit to background worker queue for processing
        async with Docket(url=self._redis_url, name=self._queue_name) as docket:
            # Use task_id as the Docket key (enables cancellation by task_id)
            queued_func: Any = docket.add(handler, key=task.task_id)
            await queued_func(
                task_id=task.task_id,
                session_id=bound_memory.session_id,
                message=message,
                context=task_context,
            )

        return {
            "task_id": task.task_id,
            "session_id": bound_memory.session_id,
            "status": "queued",
            "message": "Task created and queued for processing",
        }

    def get_emitter(self, task_id: str) -> TaskEmitter:
        """Get a TaskEmitter for a task.

        Args:
            task_id: The task ID

        Returns:
            TaskEmitter for emitting progress updates
        """
        return TaskEmitter(self._task_manager, task_id)

    def _create_wrapped_handler(
        self,
    ) -> Callable[[str, str, str, dict[str, Any]], Coroutine[Any, Any, dict[str, Any]]]:
        """Create a wrapped handler that applies middleware.

        Returns a handler compatible with Docket that:
        1. Creates a TaskContext
        2. Applies middleware chain
        3. Calls the user's handler

        Returns:
            Wrapped async function suitable for Docket
        """
        if self._agent_callable is None:
            raise ValueError("No agent_callable configured")

        # Check if handler takes TaskContext (new style) or 4 args (legacy)
        sig = inspect.signature(self._agent_callable)
        params = list(sig.parameters.values())
        is_context_handler = len(params) == 1

        user_handler: Any = self._agent_callable
        middleware = self._middleware
        kit = self
        handler_name = getattr(user_handler, "__name__", "wrapped_handler")
        handler_module = getattr(user_handler, "__module__", __name__)

        async def wrapped_handler(
            task_id: str, session_id: str, message: str, context: dict[str, Any]
        ) -> dict[str, Any]:
            from redis_agent_kit.models import Attachment

            # Create TaskContext with memory bound to session
            emitter = kit.get_emitter(task_id)
            user_id = context.get("user_id")
            bound_memory = kit._memory.with_session(session_id, user_id)

            # Extract attachments from context (serialized by create_and_submit_task)
            attachments_data = context.pop("_attachments", [])
            attachments = [Attachment(**a) if isinstance(a, dict) else a for a in attachments_data]

            ctx = TaskContext(
                task_id=task_id,
                session_id=session_id,
                message=message,
                context=context,
                kit=kit,
                emitter=emitter,
                memory=bound_memory,
                attachments=attachments,
            )

            result: dict[str, Any] = {}
            error: str | None = None

            try:
                if middleware:
                    # Use middleware chain
                    if is_context_handler:
                        chain = MiddlewareChain(user_handler, middleware)
                    else:
                        # Wrap legacy handler to accept TaskContext
                        async def legacy_wrapper(ctx: TaskContext) -> dict[str, Any]:
                            result: dict[str, Any] = await user_handler(
                                ctx.task_id, ctx.session_id, ctx.message, ctx.context
                            )
                            return result

                        chain = MiddlewareChain(legacy_wrapper, middleware)

                    result = await chain(ctx)
                else:
                    # No middleware - call handler directly
                    if is_context_handler:
                        result = await user_handler(ctx)
                    else:
                        result = await user_handler(task_id, session_id, message, context)
            except Exception as e:
                error = str(e)
                raise
            finally:
                # Send webhook callback if configured
                callback_url = context.get("callback_url")
                if callback_url:
                    await kit._send_webhook_callback(
                        callback_url=callback_url,
                        task_id=task_id,
                        session_id=session_id,
                        result=result,
                        error=error,
                    )

            return result

        # Copy function metadata so Docket uses the original name
        wrapped_handler.__name__ = handler_name
        wrapped_handler.__module__ = handler_module
        wrapped_handler.__qualname__ = handler_name

        return wrapped_handler

    async def _send_webhook_callback(
        self,
        callback_url: str,
        task_id: str,
        session_id: str,
        result: dict[str, Any],
        error: str | None = None,
    ) -> None:
        """Send a webhook callback to notify task completion.

        Args:
            callback_url: The URL to POST the callback to
            task_id: The task ID
            session_id: The session ID
            result: The task result (empty if error)
            error: Optional error message if task failed
        """
        payload = {
            "task_id": task_id,
            "session_id": session_id,
            "status": "failed" if error else "completed",
            "result": result,
            "error": error,
        }

        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                response = await client.post(callback_url, json=payload)
                if response.status_code >= 400:
                    logger.warning(
                        f"Webhook callback failed: {response.status_code} - {response.text[:200]}"
                    )
        except Exception as e:
            # Don't fail the task if callback fails
            logger.warning(f"Webhook callback error for {callback_url}: {e}")

    async def submit_input(self, task_id: str, response: dict[str, Any]) -> bool:
        """Submit user input to a task that is awaiting input.

        This stores the user's response and re-queues the task for processing.
        The task handler will receive the input in the task's input_response field.

        Args:
            task_id: The task ID
            response: Dictionary mapping field names to values.
                      For simple prompts without fields, use {"response": "..."}

        Returns:
            True if input was submitted successfully, False if task not found
            or not in AWAITING_INPUT status.

        Example:
            # Simple text response
            await kit.submit_input(task_id, {"response": "Yes, proceed"})

            # Structured response matching schema
            await kit.submit_input(task_id, {
                "database": "Redis",
                "confirm": True,
            })
        """
        # Update task status and store response
        success = await self._task_manager.submit_input(task_id, response)
        if not success:
            return False

        # Re-queue the task to Docket for processing
        task = await self._task_manager.get_task(task_id)
        if task:
            handler = self._create_wrapped_handler()
            async with Docket(url=self._redis_url, name=self._queue_name) as docket:
                queued_func: Any = docket.add(handler, key=task.task_id)
                await queued_func(
                    task_id=task.task_id,
                    session_id=task.session_id,
                    message=task.metadata.get("message", ""),
                    context=task.metadata.get("context", {}),
                )

        return True
