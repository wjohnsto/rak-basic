"""Task emitter for Redis Agent Kit."""

from __future__ import annotations

import asyncio
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from redis_agent_kit.task_manager import TaskManager


class TaskEmitter:
    """Emits progress updates during task execution.

    This is the primary interface for agent code to send real-time
    updates about what it's doing. Updates are stored on the task
    and can be polled by clients.

    Example:
        async def my_agent(query: str, emitter: TaskEmitter):
            emitter.emit("Searching knowledge base...")
            results = await search(query)
            emitter.emit(f"Found {len(results)} results", update_type="info")
            return {"answer": synthesize(results)}
    """

    def __init__(self, task_manager: TaskManager, task_id: str):
        """Initialize TaskEmitter.

        Args:
            task_manager: The TaskManager for storing updates
            task_id: The task ID to emit updates for
        """
        self._task_manager = task_manager
        self._task_id = task_id

    @property
    def task_id(self) -> str:
        """Get the task ID."""
        return self._task_id

    @property
    def task_manager(self) -> TaskManager:
        """Get the task manager."""
        return self._task_manager

    async def emit(
        self,
        message: str,
        update_type: str = "info",
        metadata: dict[str, Any] | None = None,
    ) -> None:
        """Emit a progress update.

        Args:
            message: The update message
            update_type: Type of update (info, tool_call, reflection, error)
            metadata: Optional additional metadata
        """
        await self._task_manager.add_update(
            self._task_id,
            message,
            update_type=update_type,
            metadata=metadata,
        )

    # Alias for backwards compatibility
    emit_async = emit

    def emit_nowait(
        self,
        message: str,
        update_type: str = "info",
        metadata: dict[str, Any] | None = None,
    ) -> None:
        """Emit a progress update without waiting (fire-and-forget).

        This schedules the update to be stored without blocking.
        Useful when you don't need to await the storage operation.

        Args:
            message: The update message
            update_type: Type of update (info, tool_call, reflection, error)
            metadata: Optional additional metadata
        """
        # Schedule the async operation without waiting
        asyncio.create_task(self.emit(message, update_type=update_type, metadata=metadata))

    async def emit_token(
        self,
        token: str,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        """Emit a single token via Pub/Sub without persisting to task state.

        This is a lightweight, publish-only path for token-by-token streaming.
        Unlike emit(), it does NOT read or write the task object in Redis —
        it only publishes to the Pub/Sub channel. Requires
        ``enable_streaming=True`` on the TaskManager.

        Args:
            token: The token string to publish
            metadata: Optional metadata dict
        """
        await self._task_manager.publish(
            self._task_id,
            token,
            event_type="token",
            metadata=metadata,
        )

    def emit_token_nowait(
        self,
        token: str,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        """Emit a single token without waiting (fire-and-forget).

        Non-blocking variant of emit_token(). Schedules the publish
        without awaiting it.

        Args:
            token: The token string to publish
            metadata: Optional metadata dict
        """
        asyncio.create_task(self.emit_token(token, metadata=metadata))
