"""Redis key patterns for Redis Agent Kit."""


class RedisKeys:
    """Helper class for generating Redis key patterns.

    All keys follow the pattern: {prefix}:{type}:{id}
    Default prefix is 'rak' (redis-agent-kit).
    """

    PREFIX = "rak"

    @staticmethod
    def task(task_id: str, prefix: str | None = None) -> str:
        """Get the key for a task's state."""
        p = prefix or RedisKeys.PREFIX
        return f"{p}:task:{task_id}"

    @staticmethod
    def thread(thread_id: str, prefix: str | None = None) -> str:
        """Get the key for a thread's state."""
        p = prefix or RedisKeys.PREFIX
        return f"{p}:thread:{thread_id}"

    @staticmethod
    def thread_tasks(thread_id: str, prefix: str | None = None) -> str:
        """Get the key for a thread's task set (sorted by timestamp).

        DEPRECATED: Use session_tasks() instead.
        """
        p = prefix or RedisKeys.PREFIX
        return f"{p}:thread:{thread_id}:tasks"

    @staticmethod
    def session_tasks(session_id: str, prefix: str | None = None) -> str:
        """Get the key for a session's task set (sorted by timestamp)."""
        p = prefix or RedisKeys.PREFIX
        return f"{p}:session:{session_id}:tasks"

    @staticmethod
    def thread_messages(thread_id: str, prefix: str | None = None) -> str:
        """Get the key for a thread's message list."""
        p = prefix or RedisKeys.PREFIX
        return f"{p}:thread:{thread_id}:messages"

    @staticmethod
    def tasks_by_status(status: str, prefix: str | None = None) -> str:
        """Get the key for the set of tasks with a given status."""
        p = prefix or RedisKeys.PREFIX
        return f"{p}:tasks:status:{status}"

    @staticmethod
    def all_threads(prefix: str | None = None) -> str:
        """Get the key for the set of all thread IDs."""
        p = prefix or RedisKeys.PREFIX
        return f"{p}:threads"

    @staticmethod
    def all_tasks(prefix: str | None = None) -> str:
        """Get the key for the set of all task IDs."""
        p = prefix or RedisKeys.PREFIX
        return f"{p}:tasks"

    @staticmethod
    def task_updates_channel(task_id: str, prefix: str | None = None) -> str:
        """Get the Pub/Sub channel for task update events."""
        p = prefix or RedisKeys.PREFIX
        return f"{p}:task:{task_id}:updates"

    @staticmethod
    def session_updates_channel(session_id: str, prefix: str | None = None) -> str:
        """Get the Pub/Sub channel for session-level update events.

        All tasks within the same session publish to this channel,
        allowing a single SSE connection to monitor an entire chat session.
        """
        p = prefix or RedisKeys.PREFIX
        return f"{p}:session:{session_id}:updates"

    @staticmethod
    def global_updates_channel(prefix: str | None = None) -> str:
        """Get the Pub/Sub channel for global update events.

        Every task publishes to this channel, useful for dashboards
        and multi-agent monitoring.
        """
        p = prefix or RedisKeys.PREFIX
        return f"{p}:updates"

    @staticmethod
    def parse_task_id(key: str, prefix: str | None = None) -> str:
        """Extract task_id from a task key.

        Raises:
            ValueError: If key doesn't match expected pattern.
        """
        p = prefix or RedisKeys.PREFIX
        expected_prefix = f"{p}:task:"
        if not key.startswith(expected_prefix):
            raise ValueError(f"Key '{key}' does not match task pattern '{expected_prefix}*'")
        return key[len(expected_prefix) :]

    @staticmethod
    def parse_thread_id(key: str, prefix: str | None = None) -> str:
        """Extract thread_id from a thread key.

        Raises:
            ValueError: If key doesn't match expected pattern.
        """
        p = prefix or RedisKeys.PREFIX
        expected_prefix = f"{p}:thread:"
        if not key.startswith(expected_prefix):
            raise ValueError(f"Key '{key}' does not match thread pattern '{expected_prefix}*'")
        # Handle both "rak:thread:id" and "rak:thread:id:messages"
        remaining = key[len(expected_prefix) :]
        # Return just the thread ID (before any additional colon)
        if ":" in remaining:
            return remaining.split(":")[0]
        return remaining
