"""High-level knowledge store for RAG applications."""

from __future__ import annotations

import hashlib
import logging
from dataclasses import dataclass
from typing import Any

import redis.asyncio as redis

from redis_agent_kit.pipelines import SearchResult, VectorStore
from redis_agent_kit.vectorizer import Vectorizer

logger = logging.getLogger(__name__)


@dataclass
class KnowledgeDocument:
    """A document stored in the knowledge base."""

    doc_id: str
    title: str
    content: str
    metadata: dict[str, Any]


class KnowledgeStore:
    """High-level knowledge store combining vectorization and search.

    Example:
        from redis_agent_kit import KnowledgeStore

        ks = KnowledgeStore.from_url("redis://localhost:6379")

        # Ingest content
        await ks.ingest("Redis uses RDB for persistence...", title="Redis Persistence")

        # Search
        results = await ks.search("How does Redis save data?")
        for r in results:
            print(f"{r.content[:100]}... (score: {r.score:.2f})")
    """

    def __init__(
        self,
        client: redis.Redis,
        vectorizer: Vectorizer | None = None,
        prefix: str = "rak",
        embedding_model: str = "text-embedding-3-small",
        dimensions: int | None = None,
    ):
        """Initialize knowledge store.

        Args:
            client: Async Redis client.
            vectorizer: Custom vectorizer (created with model if None).
            prefix: Key prefix for storage.
            embedding_model: Model name for embeddings (used if no vectorizer).
            dimensions: Vector dimensions (auto-detected if None).
        """
        self._client = client
        self._vectorizer = vectorizer or Vectorizer(model=embedding_model)
        self._vector_store = VectorStore(client, prefix=prefix, dimensions=dimensions)
        self._prefix = prefix

    @classmethod
    def from_url(
        cls,
        redis_url: str = "redis://localhost:6379",
        embedding_model: str = "text-embedding-3-small",
        prefix: str = "rak",
        **kwargs: Any,
    ) -> KnowledgeStore:
        """Create KnowledgeStore from Redis URL.

        Args:
            redis_url: Redis connection URL.
            embedding_model: Model for generating embeddings.
            prefix: Key prefix for storage.
            **kwargs: Additional arguments for KnowledgeStore.

        Returns:
            Configured KnowledgeStore instance.
        """
        client: Any = redis.from_url(  # type: ignore[no-untyped-call]
            redis_url, decode_responses=True
        )
        return cls(client, embedding_model=embedding_model, prefix=prefix, **kwargs)

    async def search(
        self,
        query: str,
        limit: int = 10,
        distance_threshold: float | None = None,
    ) -> list[SearchResult]:
        """Search for relevant content using semantic similarity.

        Args:
            query: Search query text.
            limit: Maximum number of results.
            distance_threshold: Optional max distance filter.

        Returns:
            List of SearchResult objects sorted by relevance.
        """
        embedding = await self._vectorizer.embed(query)
        return await self._vector_store.search(
            embedding, limit=limit, distance_threshold=distance_threshold
        )

    async def ingest(
        self,
        content: str,
        title: str | None = None,
        doc_id: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> str:
        """Ingest a single piece of content.

        Args:
            content: The text content to ingest.
            title: Optional title for the content.
            doc_id: Optional document ID (auto-generated if None).
            metadata: Optional metadata dict.

        Returns:
            The document ID.
        """
        # Generate doc_id from content hash if not provided
        if doc_id is None:
            doc_id = hashlib.sha256(content.encode()).hexdigest()[:16]

        # Generate embedding
        embedding = await self._vectorizer.embed(content)

        # Prepare metadata
        meta = metadata or {}
        if title:
            meta["title"] = title

        # Store
        await self._vector_store.store_chunk(
            chunk_id=f"{doc_id}_0",  # Single chunk
            doc_id=doc_id,
            content=content,
            embedding=embedding,
            metadata=meta,
        )

        return doc_id

    async def ingest_many(
        self,
        documents: list[tuple[str, str | None, dict[str, Any] | None]],
    ) -> list[str]:
        """Ingest multiple documents.

        Args:
            documents: List of (content, title, metadata) tuples.

        Returns:
            List of document IDs.
        """
        doc_ids = []
        for content, title, metadata in documents:
            doc_id = await self.ingest(content, title=title, metadata=metadata)
            doc_ids.append(doc_id)
        return doc_ids

    async def delete(self, doc_id: str) -> int:
        """Delete a document from the knowledge base.

        Args:
            doc_id: Document ID to delete.

        Returns:
            Number of chunks deleted.
        """
        return await self._vector_store.delete_by_doc_id(doc_id)

    async def count(self) -> int:
        """Count total documents/chunks in the knowledge base."""
        return await self._vector_store.count()

    async def clear(self) -> None:
        """Clear all content from the knowledge base."""
        await self._vector_store.clear()
