"""
Internal memory interface for agent execution.

This module provides working memory (conversations) and long-term memory (persistent
facts) for agents. Memory is internal infrastructure - not exposed to external clients.

Implementation uses agent-memory-server internally, but that's hidden from users.
Users interact only through the Memory class on TaskContext.

EXPERIMENTAL: This API is still evolving.
"""

from __future__ import annotations

import json
import logging
from typing import TYPE_CHECKING, Any

from ulid import ULID

if TYPE_CHECKING:
    from redis.asyncio import Redis

logger = logging.getLogger(__name__)


class MessageList(list[dict[str, str]]):
    """
    A list of messages with formatting methods.

    Supports .dict(), .json(), and .markdown() for different output formats.
    """

    def dict(self) -> list[dict[str, str]]:
        """Return messages as a list of dicts."""
        return list(self)

    def json(self, **kwargs: Any) -> str:
        """Return messages as a JSON string."""
        return json.dumps(self.dict(), **kwargs)

    def markdown(
        self,
        format: str = "**{role}**: {content}",
        separator: str = "\n\n",
    ) -> str:
        """
        Return messages formatted as markdown.

        Args:
            format: Format string for each message (supports {role}, {content})
            separator: String to join messages

        Returns:
            Formatted markdown string
        """
        if not self:
            return ""
        return separator.join(format.format(**m) for m in self)


class MemorySearchResults(list[dict[str, Any]]):
    """
    A list of memory search results with formatting methods.

    Supports .dict(), .json(), and .markdown() for different output formats.
    """

    def dict(self) -> list[dict[str, Any]]:
        """Return results as a list of dicts."""
        return list(self)

    def json(self, **kwargs: Any) -> str:
        """Return results as a JSON string."""
        return json.dumps(self.dict(), **kwargs)

    def markdown(
        self,
        format: str = "- {text}",
        separator: str = "\n",
        include_metadata: bool = False,
    ) -> str:
        """
        Return results formatted as markdown.

        Args:
            format: Format string for each result (supports {text}, {memory_type}, etc.)
            separator: String to join results
            include_metadata: Include memory_type and topics in output

        Returns:
            Formatted markdown string
        """
        if not self:
            return ""

        if include_metadata:
            lines = []
            for m in self:
                line = format.format(**m)
                meta = []
                if m.get("memory_type"):
                    meta.append(f"type: {m['memory_type']}")
                if m.get("topics"):
                    meta.append(f"topics: {', '.join(m['topics'])}")
                if meta:
                    line += f" ({'; '.join(meta)})"
                lines.append(line)
            return separator.join(lines)

        return separator.join(format.format(**m) for m in self)


# Cache import check result
_ams_available: bool | None = None


def _check_ams() -> bool:
    """Check if agent-memory-server is available."""
    global _ams_available
    if _ams_available is None:
        try:
            import agent_memory_server  # noqa: F401

            _ams_available = True
        except ImportError:
            _ams_available = False
    return _ams_available


def _require_ams() -> None:
    """Raise if agent-memory-server not installed."""
    if not _check_ams():
        raise ImportError(
            "Memory features require agent-memory-server. "
            "Install with: pip install agent-memory-server"
        )


class Memory:
    """
    Memory interface for agent execution.

    Provides working memory (conversation history) and long-term memory
    (persistent facts, preferences, etc.).

    Memory is always available on TaskContext. Sessions are created lazily
    on first write - no data exists until something is added.

    Example:
        async def my_agent(ctx: TaskContext) -> dict:
            # Get conversation history
            messages = await ctx.memory.get_messages()

            # Search relevant memories
            memories = await ctx.memory.search("user preferences")

            # Add response (creates session if needed)
            await ctx.memory.add_message("assistant", response)

            return {"response": response}
    """

    def __init__(
        self,
        redis_client: Redis | None = None,
        namespace: str | None = None,
        *,
        enabled: bool = True,
    ):
        self._redis = redis_client
        self._namespace = namespace
        self._enabled = enabled and _check_ams()
        self._session_id: str | None = None
        self._user_id: str | None = None
        self._session_exists: bool = False
        self._ams_configured: bool = False

    def with_session(
        self,
        session_id: str | None = None,
        user_id: str | None = None,
    ) -> Memory:
        """
        Return a Memory instance bound to a session.

        If session_id is None, generates a new one.
        Session is not created in Redis until first write.

        Args:
            session_id: Session ID to use (or None to generate)
            user_id: Optional user ID for memory isolation

        Returns:
            New Memory instance bound to the session
        """
        m = Memory(
            redis_client=self._redis,
            namespace=self._namespace,
            enabled=self._enabled,
        )
        m._session_id = session_id or str(ULID())
        m._user_id = user_id
        return m

    @property
    def session_id(self) -> str | None:
        """Current session ID (may not exist in Redis yet)."""
        return self._session_id

    @property
    def user_id(self) -> str | None:
        """Current user ID."""
        return self._user_id

    @property
    def enabled(self) -> bool:
        """Whether memory features are enabled."""
        return self._enabled

    def _configure_ams(self) -> None:
        """Configure AMS settings from RAK settings (once)."""
        if self._ams_configured or not self._enabled:
            return

        from redis_agent_kit.config import get_settings

        settings = get_settings()

        try:
            from agent_memory_server.config import settings as ams_settings

            # Core
            ams_settings.redis_url = settings.redis_url

            # Memory settings
            ams_settings.long_term_memory = settings.memory.long_term_enabled
            ams_settings.summarization_threshold = settings.memory.summarization_threshold
            ams_settings.enable_discrete_memory_extraction = settings.memory.enable_extraction

            # Forgetting
            if settings.memory.forgetting_enabled:
                ams_settings.forgetting_enabled = True
                if settings.memory.forgetting_max_age_days:
                    ams_settings.forgetting_max_age_days = settings.memory.forgetting_max_age_days
                if settings.memory.forgetting_max_inactive_days:
                    ams_settings.forgetting_max_inactive_days = (
                        settings.memory.forgetting_max_inactive_days
                    )

            # Models
            ams_settings.generation_model = settings.model.default_model
            ams_settings.embedding_model = settings.model.embedding_model

            self._ams_configured = True
        except Exception as e:
            logger.warning(f"Failed to configure AMS settings: {e}")

    async def _get_session(self) -> Any:
        """Get current working memory session from Redis."""
        if not self._enabled or not self._session_id:
            return None

        self._configure_ams()

        from agent_memory_server import working_memory
        from agent_memory_server.config import settings as ams_settings

        return await working_memory.get_working_memory(
            session_id=self._session_id,
            user_id=self._user_id,
            namespace=self._namespace,
            redis_client=self._redis,
            config=ams_settings,
        )

    async def _ensure_session(self) -> Any:
        """Get or create session (lazy creation)."""
        if not self._enabled:
            return None

        self._configure_ams()

        from agent_memory_server.models import WorkingMemory

        session = await self._get_session()
        if session is None:
            if not self._session_id:
                self._session_id = str(ULID())
            session = WorkingMemory(
                session_id=self._session_id,
                user_id=self._user_id,
                namespace=self._namespace,
            )
        return session

    async def _save_session(self, session: Any) -> None:
        """Save working memory session to Redis."""
        if not self._enabled:
            return

        from agent_memory_server import working_memory
        from agent_memory_server.config import settings as ams_settings

        await working_memory.set_working_memory(
            working_memory=session,
            redis_client=self._redis,
            config=ams_settings,
        )
        self._session_exists = True

    # =========================================================================
    # Working Memory (Conversation)
    # =========================================================================

    async def add_message(self, role: str, content: str) -> str | None:
        """
        Add a message to working memory.

        Creates session on first call if it doesn't exist.

        Args:
            role: Message role (user, assistant, system)
            content: Message content

        Returns:
            Session ID, or None if memory disabled
        """
        if not self._enabled:
            return None

        _require_ams()
        from agent_memory_server.models import MemoryMessage

        session = await self._ensure_session()
        if session is None:
            return None

        session.messages.append(MemoryMessage(role=role, content=content))
        await self._save_session(session)
        return self._session_id

    async def get_messages(self, limit: int | None = None) -> MessageList:
        """
        Get messages from current session.

        Args:
            limit: Max messages to return (None for all)

        Returns:
            MessageList with 'role' and 'content' dicts. Supports:
            - .dict() - list of dicts
            - .json() - JSON string
            - .markdown() - formatted markdown string
        """
        if not self._enabled:
            return MessageList()

        session = await self._get_session()
        if session is None:
            return MessageList()

        messages = session.messages
        if limit:
            messages = messages[-limit:]

        return MessageList({"role": m.role, "content": m.content} for m in messages)

    async def get_history(
        self,
        limit: int | None = 10,
        format: str = "{role}: {content}",
        separator: str = "\n",
    ) -> str:
        """
        Get conversation history formatted as text.

        Convenience method that formats messages for LLM context.

        Args:
            limit: Max messages to include (None for all)
            format: Format string for each message (supports {role}, {content})
            separator: String to join messages

        Returns:
            Formatted conversation history string

        Example:
            # Default format
            history = await ctx.memory.get_history(limit=10)
            # "user: Hello\\nassistant: Hi there!"

            # Custom format
            history = await ctx.memory.get_history(
                format="[{role}] {content}",
                separator="\\n---\\n"
            )
        """
        messages = await self.get_messages(limit=limit)
        return separator.join(format.format(role=m["role"], content=m["content"]) for m in messages)

    async def get_context(self) -> str | None:
        """
        Get context string from working memory.

        Returns summarized context if available, otherwise None.
        """
        if not self._enabled:
            return None

        session = await self._get_session()
        if session is None:
            return None

        return str(session.context) if session.context is not None else None

    async def set_data(self, key: str, value: Any) -> None:
        """
        Set arbitrary data in session.

        Args:
            key: Data key
            value: Data value (must be JSON serializable)
        """
        if not self._enabled:
            return

        _require_ams()
        session = await self._ensure_session()
        if session is None:
            return

        if session.data is None:
            session.data = {}
        session.data[key] = value
        await self._save_session(session)

    async def get_data(self, key: str, default: Any = None) -> Any:
        """
        Get arbitrary data from session.

        Args:
            key: Data key
            default: Default value if key not found

        Returns:
            Value or default
        """
        if not self._enabled:
            return default

        session = await self._get_session()
        if session is None or session.data is None:
            return default

        return session.data.get(key, default)

    # =========================================================================
    # Long-Term Memory
    # =========================================================================

    async def search(
        self,
        text: str,
        limit: int = 10,
        memory_type: str | None = None,
        topics: list[str] | None = None,
    ) -> MemorySearchResults:
        """
        Search long-term memories by semantic similarity.

        Args:
            text: Search query
            limit: Max results
            memory_type: Filter by type (semantic, episodic, etc.)
            topics: Filter by topics

        Returns:
            MemorySearchResults with 'id', 'text', 'memory_type', 'score', etc. Supports:
            - .dict() - list of dicts
            - .json() - JSON string
            - .markdown() - formatted markdown string
        """
        if not self._enabled:
            return MemorySearchResults()

        _require_ams()
        self._configure_ams()

        from agent_memory_server import long_term_memory

        result = await long_term_memory.search_long_term_memories(
            text=text,
            user_id=self._user_id,
            namespace=self._namespace,
            limit=limit,
            memory_type=memory_type,
            topics=topics,
            redis_client=self._redis,
        )

        if result is None:
            return MemorySearchResults()

        return MemorySearchResults(
            {
                "id": m.id,
                "text": m.text,
                "memory_type": m.memory_type,
                "topics": m.topics,
                "entities": m.entities,
                "score": getattr(m, "dist", None),
            }
            for m in result.memories
        )

    async def search_text(
        self,
        text: str,
        limit: int = 10,
        separator: str = "\n",
        memory_type: str | None = None,
        topics: list[str] | None = None,
    ) -> str:
        """
        Search long-term memories and return text content only.

        Convenience method that returns just the text from search results,
        formatted for direct use in LLM context.

        Args:
            text: Search query
            limit: Max results
            separator: String to join memory texts
            memory_type: Filter by type (semantic, episodic, etc.)
            topics: Filter by topics

        Returns:
            Concatenated memory texts, or empty string if no results

        Example:
            # Get relevant context for a query
            memory_context = await ctx.memory.search_text(ctx.message, limit=3)
            prompt = f"Context:\\n{memory_context}\\n\\nQuestion: {ctx.message}"
        """
        results = await self.search(
            text=text,
            limit=limit,
            memory_type=memory_type,
            topics=topics,
        )
        return separator.join(r.get("text", "") for r in results if r.get("text"))

    async def create_memory(
        self,
        text: str,
        memory_type: str = "semantic",
        topics: list[str] | None = None,
        entities: list[str] | None = None,
    ) -> str | None:
        """
        Create a long-term memory explicitly.

        For passive memory creation, just use working memory -
        the system auto-promotes based on configuration.

        Args:
            text: Memory content
            memory_type: Type (semantic, episodic, etc.)
            topics: Associated topics
            entities: Associated entities

        Returns:
            Memory ID, or None if disabled
        """
        if not self._enabled:
            return None

        _require_ams()
        self._configure_ams()

        from agent_memory_server import long_term_memory
        from agent_memory_server.models import MemoryRecord

        memory = MemoryRecord(
            text=text,
            user_id=self._user_id,
            namespace=self._namespace,
            memory_type=memory_type,
            topics=topics or [],
            entities=entities or [],
        )

        result = await long_term_memory.create_long_term_memory(
            memory=memory,
            redis_client=self._redis,
        )
        return result.id if result else None

    async def delete_memories(self, memory_ids: list[str]) -> int:
        """
        Delete long-term memories by ID.

        Args:
            memory_ids: List of memory IDs to delete

        Returns:
            Number of memories deleted
        """
        if not self._enabled or not memory_ids:
            return 0

        _require_ams()
        self._configure_ams()

        from agent_memory_server import long_term_memory

        result: int = await long_term_memory.delete_long_term_memories(
            memory_ids=memory_ids,
            user_id=self._user_id,
            namespace=self._namespace,
            redis_client=self._redis,
        )
        return result

    # =========================================================================
    # Session Management
    # =========================================================================

    async def delete_session(self) -> bool:
        """
        Delete current working memory session.

        Returns:
            True if deleted, False if not found or disabled
        """
        if not self._enabled or not self._session_id:
            return False

        _require_ams()
        self._configure_ams()

        from agent_memory_server import working_memory
        from agent_memory_server.config import settings as ams_settings

        result: bool = await working_memory.delete_working_memory(
            session_id=self._session_id,
            user_id=self._user_id,
            namespace=self._namespace,
            redis_client=self._redis,
            config=ams_settings,
        )
        self._session_exists = False
        return result


class NoOpMemory(Memory):
    """Memory implementation that does nothing (for disabled memory)."""

    def __init__(self) -> None:
        super().__init__(redis_client=None, namespace=None, enabled=False)

    async def add_message(self, role: str, content: str) -> str | None:
        return None

    async def get_messages(self, limit: int | None = None) -> MessageList:
        return MessageList()

    async def get_context(self) -> str | None:
        return None

    async def set_data(self, key: str, value: Any) -> None:
        pass

    async def get_data(self, key: str, default: Any = None) -> Any:
        return default

    async def search(
        self,
        text: str,
        limit: int = 10,
        memory_type: str | None = None,
        topics: list[str] | None = None,
    ) -> MemorySearchResults:
        return MemorySearchResults()

    async def create_memory(
        self,
        text: str,
        memory_type: str = "semantic",
        topics: list[str] | None = None,
        entities: list[str] | None = None,
    ) -> str | None:
        return None

    async def delete_memories(self, memory_ids: list[str]) -> int:
        return 0

    async def delete_session(self) -> bool:
        return False
