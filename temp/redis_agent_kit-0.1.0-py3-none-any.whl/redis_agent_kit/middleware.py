"""Middleware for Redis Agent Kit.

Middleware allows you to wrap handlers with reusable functionality like:
- RAG context injection
- Progress updates (emitter)
- Thread message saving
- Error handling
- Logging/tracing

Supports two types of middleware:
1. Task middleware (for AgentKit task handlers)
2. Pipeline middleware (for PipelineOrchestrator)

Example (Task Middleware):
    from redis_agent_kit import AgentKit
    from redis_agent_kit.middleware import RAGMiddleware, MemoryMiddleware

    async def my_agent(ctx: TaskContext) -> dict:
        # ctx.rag_context is injected by RAGMiddleware
        return {"response": f"Based on: {ctx.rag_context}"}

    kit = AgentKit(
        client,
        agent_callable=my_agent,
        middleware=[RAGMiddleware(), MemoryMiddleware()],
    )

Example (Pipeline Middleware):
    from redis_agent_kit.pipelines import PipelineOrchestrator
    from redis_agent_kit.middleware import PipelineLoggingMiddleware

    orchestrator = PipelineOrchestrator(
        config=config,
        base_path=path,
        middleware=[PipelineLoggingMiddleware()],
    )
"""

from __future__ import annotations

import time
from abc import ABC, abstractmethod
from collections.abc import Callable, Coroutine
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Any

from redis_agent_kit.models import TaskStatus

if TYPE_CHECKING:
    from redis_agent_kit.core import AgentKit
    from redis_agent_kit.emitter import TaskEmitter
    from redis_agent_kit.memory import Memory


@dataclass
class TaskContext:
    """Context passed through the middleware chain to the task handler.

    Contains all the information needed to process a task, plus any
    data injected by middleware (like rag_context).

    Attributes:
        task_id: The unique task identifier
        session_id: The memory session identifier (optional)
        message: The user's message/query
        attachments: List of attachments (images, audio, files) for multi-modal input
        context: Additional context data (user_id, instance_id, etc.)
        kit: The AgentKit instance for accessing managers
        emitter: TaskEmitter for progress updates
        memory: Memory instance for working/long-term memory
        rag_context: RAG context injected by RAGMiddleware (optional)
        metadata: Additional data injected by custom middleware
    """

    task_id: str
    session_id: str | None
    message: str
    context: dict[str, Any]
    kit: AgentKit
    emitter: TaskEmitter
    memory: Memory
    attachments: list[Any] = field(default_factory=list)  # list[Attachment]
    rag_context: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)


# Type for the next middleware or final handler
NextHandler = Callable[[TaskContext], Coroutine[Any, Any, dict[str, Any]]]


class TaskMiddleware(ABC):
    """Base class for task handler middleware.

    Middleware wraps task handlers to add cross-cutting functionality.
    Each middleware receives a TaskContext and a 'next' function to call
    the next middleware in the chain (or the final handler).

    Example:
        class LoggingMiddleware(TaskMiddleware):
            async def __call__(self, ctx: TaskContext, next: NextHandler) -> dict:
                print(f"Starting task {ctx.task_id}")
                result = await next(ctx)
                print(f"Completed task {ctx.task_id}")
                return result
    """

    @abstractmethod
    async def __call__(self, ctx: TaskContext, next: NextHandler) -> dict[str, Any]:
        """Process the task context and call the next handler.

        Args:
            ctx: The task context with all task information
            next: Function to call the next middleware or final handler

        Returns:
            The task result dictionary
        """
        pass  # pragma: no cover


class MiddlewareChain:
    """Chains multiple middleware together with a final handler.

    The chain is built from the inside out:
    - The innermost function is the actual task handler
    - Each middleware wraps the previous, forming a chain
    - When called, execution flows: middleware1 -> middleware2 -> ... -> handler
    """

    def __init__(
        self,
        handler: Callable[[TaskContext], Coroutine[Any, Any, dict[str, Any]]],
        middleware: list[TaskMiddleware] | None = None,
    ):
        """Initialize the middleware chain.

        Args:
            handler: The final task handler function
            middleware: List of middleware to apply (in order)
        """
        self._handler = handler
        self._middleware = middleware or []

    async def __call__(self, ctx: TaskContext) -> dict[str, Any]:
        """Execute the middleware chain with the given context.

        Args:
            ctx: The task context

        Returns:
            The result from the handler (possibly modified by middleware)
        """
        # Build chain from inside out
        chain: NextHandler = self._handler

        # Wrap in reverse order so first middleware runs first
        for mw in reversed(self._middleware):
            # Capture current chain in closure
            prev_chain = chain

            def chain(
                ctx: TaskContext,
                mw: TaskMiddleware = mw,
                prev: NextHandler = prev_chain,
            ) -> Coroutine[Any, Any, dict[str, Any]]:
                return mw(ctx, prev)

        return await chain(ctx)


# =============================================================================
# Built-in Middleware
# =============================================================================


class EmitterMiddleware(TaskMiddleware):
    """Middleware that emits progress updates at start and end.

    Automatically emits "Starting..." when the task begins and handles
    the status update pattern that most handlers need.

    Args:
        start_message: Message to emit when starting (default: "Starting...")
        end_message: Message to emit on success (default: None, no message)
    """

    def __init__(
        self,
        start_message: str = "Starting...",
        end_message: str | None = None,
    ):
        self.start_message = start_message
        self.end_message = end_message

    async def __call__(self, ctx: TaskContext, next: NextHandler) -> dict[str, Any]:
        """Emit progress updates around the handler."""
        await ctx.emitter.emit(self.start_message)
        result = await next(ctx)
        if self.end_message:
            await ctx.emitter.emit(self.end_message)
        return result


class RAGMiddleware(TaskMiddleware):
    """Middleware that injects RAG context from the vector store.

    Searches the vector store for relevant documents based on the user's
    message and injects them into ctx.rag_context.

    Args:
        limit: Maximum number of results to retrieve (default: 3)
        separator: String to join multiple results (default: "\\n\\n")
        emit_status: Whether to emit a status update (default: True)
    """

    def __init__(
        self,
        limit: int = 3,
        separator: str = "\n\n",
        emit_status: bool = True,
    ):
        self.limit = limit
        self.separator = separator
        self.emit_status = emit_status

    async def __call__(self, ctx: TaskContext, next: NextHandler) -> dict[str, Any]:
        """Search knowledge store and inject context."""
        # Import here to avoid circular import
        from redis_agent_kit.knowledge import KnowledgeStore

        if self.emit_status:
            await ctx.emitter.emit("Searching knowledge base...")

        # Create knowledge store from kit's redis client
        knowledge_store = KnowledgeStore(ctx.kit._redis)

        results = await knowledge_store.search(ctx.message, limit=self.limit)
        ctx.rag_context = self.separator.join([r.content for r in results]) if results else ""

        # Store result count in metadata for later use
        ctx.metadata["rag_result_count"] = len(results) if results else 0

        return await next(ctx)


class MemoryMiddleware(TaskMiddleware):
    """Middleware that saves the response to working memory.

    After the handler completes, if the result contains a 'response' key,
    it's saved as an assistant message in memory.

    Args:
        response_key: Key in result dict containing the response (default: "response")
        role: Message role to use (default: "assistant")
    """

    def __init__(self, response_key: str = "response", role: str = "assistant"):
        self.response_key = response_key
        self.role = role

    async def __call__(self, ctx: TaskContext, next: NextHandler) -> dict[str, Any]:
        """Save response to memory after handler completes."""
        result = await next(ctx)

        if self.response_key in result and ctx.memory.enabled:
            await ctx.memory.add_message(
                role=self.role,
                content=result[self.response_key],
            )

        return result


class ResultMiddleware(TaskMiddleware):
    """Middleware that sets the task result/error status.

    Automatically calls set_result on success or set_error on exception.
    This is the outermost middleware that handles the task lifecycle.

    Note: If the task is in AWAITING_INPUT status (paused for user input),
    the result is stored but status is not changed to DONE.
    """

    async def __call__(self, ctx: TaskContext, next: NextHandler) -> dict[str, Any]:
        """Handle task result and error states."""
        try:
            result = await next(ctx)
            # Check if task is awaiting input (paused)
            task = await ctx.kit.task_manager.get_task(ctx.task_id)
            if task and task.status == TaskStatus.AWAITING_INPUT:
                # Store result but don't change status
                await ctx.kit.task_manager.update(ctx.task_id, result=result)
            else:
                await ctx.kit.task_manager.set_result(ctx.task_id, result)
            return result
        except Exception as e:
            await ctx.kit.task_manager.set_error(ctx.task_id, str(e))
            raise


# =============================================================================
# Pipeline Middleware
# =============================================================================


@dataclass
class PipelineContext:
    """Context passed through the pipeline middleware chain.

    Contains all the information needed to process a pipeline stage,
    plus any data injected by middleware.

    Attributes:
        stage: The pipeline stage being executed ("prepare", "ingest", "run")
        batch_id: The batch ID (set after prepare, required for ingest)
        config: The pipeline configuration
        base_path: Base path for document sources
        orchestrator: The PipelineOrchestrator instance
        metadata: Additional data injected by custom middleware
    """

    stage: str
    batch_id: str | None
    config: Any  # PipelineConfig, avoid circular import
    base_path: Path
    orchestrator: Any  # PipelineOrchestrator, avoid circular import
    metadata: dict[str, Any] = field(default_factory=dict)


# Type for the next pipeline middleware or final handler
NextPipelineHandler = Callable[[PipelineContext], Coroutine[Any, Any, Any]]


class PipelineMiddleware(ABC):
    """Base class for pipeline middleware.

    Middleware wraps pipeline stages to add cross-cutting functionality.
    Each middleware receives a PipelineContext and a 'next' function to call
    the next middleware in the chain (or the final stage handler).

    Example:
        class LoggingMiddleware(PipelineMiddleware):
            async def __call__(self, ctx: PipelineContext, next) -> Any:
                print(f"Starting {ctx.stage} stage")
                result = await next(ctx)
                print(f"Completed {ctx.stage} stage")
                return result
    """

    @abstractmethod
    async def __call__(self, ctx: PipelineContext, next: NextPipelineHandler) -> Any:
        """Process the pipeline context and call the next handler.

        Args:
            ctx: The pipeline context with all stage information
            next: Function to call the next middleware or final handler

        Returns:
            The stage result (batch_id for prepare, IngestionManifest for ingest)
        """
        pass  # pragma: no cover


class PipelineMiddlewareChain:
    """Chains multiple pipeline middleware together with a final handler.

    The chain is built from the inside out:
    - The innermost function is the actual stage handler
    - Each middleware wraps the previous, forming a chain
    - When called, execution flows: middleware1 -> middleware2 -> ... -> handler
    """

    def __init__(
        self,
        handler: Callable[[PipelineContext], Coroutine[Any, Any, Any]],
        middleware: list[PipelineMiddleware] | None = None,
    ):
        """Initialize the pipeline middleware chain.

        Args:
            handler: The final stage handler function
            middleware: List of middleware to apply (in order)
        """
        self._handler = handler
        self._middleware = middleware or []

    async def __call__(self, ctx: PipelineContext) -> Any:
        """Execute the middleware chain with the given context.

        Args:
            ctx: The pipeline context

        Returns:
            The result from the handler (possibly modified by middleware)
        """
        # Build chain from inside out
        chain: NextPipelineHandler = self._handler

        # Wrap in reverse order so first middleware runs first
        for mw in reversed(self._middleware):
            prev_chain = chain

            def chain(
                ctx: PipelineContext,
                mw: PipelineMiddleware = mw,
                prev: NextPipelineHandler = prev_chain,
            ) -> Coroutine[Any, Any, Any]:
                return mw(ctx, prev)

        return await chain(ctx)


# =============================================================================
# Built-in Pipeline Middleware
# =============================================================================


class PipelineLoggingMiddleware(PipelineMiddleware):
    """Middleware that logs pipeline stage execution.

    Args:
        logger: Optional logger to use (defaults to print)
    """

    def __init__(self, logger: Callable[[str], None] | None = None):
        self.logger = logger or print

    async def __call__(self, ctx: PipelineContext, next: NextPipelineHandler) -> Any:
        """Log stage execution."""
        self.logger(f"Starting pipeline stage: {ctx.stage}")
        if ctx.batch_id:
            self.logger(f"  Batch ID: {ctx.batch_id}")

        result = await next(ctx)

        self.logger(f"Completed pipeline stage: {ctx.stage}")
        return result


class PipelineTimingMiddleware(PipelineMiddleware):
    """Middleware that tracks pipeline stage execution time.

    Adds timing information to ctx.metadata["timing"].
    """

    async def __call__(self, ctx: PipelineContext, next: NextPipelineHandler) -> Any:
        """Track stage execution time."""
        start = time.perf_counter()
        result = await next(ctx)
        elapsed = time.perf_counter() - start

        if "timing" not in ctx.metadata:
            ctx.metadata["timing"] = {}
        ctx.metadata["timing"][ctx.stage] = elapsed

        return result


class PipelineValidationMiddleware(PipelineMiddleware):
    """Middleware that validates pipeline configuration before execution.

    Raises ValueError if configuration is invalid.
    """

    async def __call__(self, ctx: PipelineContext, next: NextPipelineHandler) -> Any:
        """Validate pipeline configuration."""
        # Validate sources exist for prepare stage
        if ctx.stage == "prepare":
            if not ctx.config.sources:
                raise ValueError("Pipeline config must have at least one source")

            for source in ctx.config.sources:
                if not source.path_pattern:
                    raise ValueError(f"Source '{source.name}' must have a path_pattern")

        # Validate batch_id for ingest stage
        if ctx.stage == "ingest" and not ctx.batch_id:
            raise ValueError("batch_id is required for ingest stage")

        return await next(ctx)
