"""Data pipeline components for document ingestion and vectorization."""

from .artifact_storage import ArtifactStorage
from .config_loader import find_config_file, load_config
from .deduplicator import DocumentDeduplicator
from .frontmatter import FrontmatterParser
from .ingest_stage import IngestStage
from .models import (
    # Phase 6: Two-stage pipeline models
    BatchManifest,
    # Core models
    Chunk,
    ChunkingDefaults,
    Document,
    DocumentFrontmatter,
    DocumentType,
    IngestionManifest,
    PipelineConfig,
    PipelineResult,
    PreparedDocument,
    ProcessorConfig,
    SearchResult,
    SourceConfig,
)
from .orchestrator import PipelineOrchestrator, PipelineRunResult
from .pipeline import Pipeline
from .prepare_stage import PrepareStage
from .processor import DocumentProcessor
from .scraper import BaseScraper, FileScraper
from .vector_store import VectorStore

__all__ = [
    # Core Models
    "Document",
    "DocumentType",
    "Chunk",
    "ProcessorConfig",
    "PipelineResult",
    "SearchResult",
    # Phase 6: Two-stage pipeline models
    "SourceConfig",
    "PipelineConfig",
    "ChunkingDefaults",
    "DocumentFrontmatter",
    "PreparedDocument",
    "BatchManifest",
    "IngestionManifest",
    # Components
    "ArtifactStorage",
    "DocumentDeduplicator",
    "DocumentProcessor",
    "FrontmatterParser",
    "IngestStage",
    "PipelineOrchestrator",
    "PipelineRunResult",
    "PrepareStage",
    "BaseScraper",
    "FileScraper",
    "VectorStore",
    "Pipeline",
    # Configuration
    "load_config",
    "find_config_file",
]
