"""YAML frontmatter parser for Markdown documents."""

import re
from pathlib import Path

import yaml  # type: ignore[import-untyped]
from pydantic import ValidationError

from .models import DocumentFrontmatter, ProcessorConfig, SourceConfig


class FrontmatterParser:
    """Parser for YAML frontmatter in Markdown documents."""

    # Regex to match frontmatter: starts with ---, ends with ---, at document start
    # The (.*?) allows empty content between the markers
    FRONTMATTER_PATTERN = re.compile(r"^---\s*\n(.*?)---\s*\n", re.DOTALL)

    def parse(self, content: str) -> tuple[DocumentFrontmatter | None, str]:
        """Parse frontmatter from markdown content.

        Args:
            content: The full markdown content with optional frontmatter.

        Returns:
            Tuple of (frontmatter, body) where frontmatter is None if not present.
        """
        match = self.FRONTMATTER_PATTERN.match(content)
        if not match:
            return None, content

        yaml_content = match.group(1)
        body = content[match.end() :]

        # Parse YAML
        try:
            data = yaml.safe_load(yaml_content)
        except yaml.YAMLError:
            # Invalid YAML - treat as no frontmatter
            return None, content

        # Empty frontmatter block (just ---)
        if data is None:
            data = {}

        # Parse into DocumentFrontmatter, ignoring unknown fields
        try:
            frontmatter = DocumentFrontmatter.model_validate(data)
        except ValidationError:
            # Invalid data - treat as no frontmatter
            return None, content

        return frontmatter, body

    def parse_file(self, path: Path) -> tuple[DocumentFrontmatter | None, str]:
        """Parse frontmatter from a file.

        Args:
            path: Path to the markdown file.

        Returns:
            Tuple of (frontmatter, body).

        Raises:
            FileNotFoundError: If the file doesn't exist.
        """
        if not path.exists():
            raise FileNotFoundError(f"File not found: {path}")

        content = path.read_text(encoding="utf-8")
        return self.parse(content)

    def merge_config(
        self,
        frontmatter: DocumentFrontmatter | None,
        source: SourceConfig,
    ) -> ProcessorConfig:
        """Merge frontmatter with source config (frontmatter takes priority).

        Args:
            frontmatter: Parsed frontmatter (may be None).
            source: Source configuration to use as base.

        Returns:
            ProcessorConfig with merged values.
        """
        # Start with source config values
        chunk_size = source.chunk_size
        chunk_overlap = source.chunk_overlap
        min_chunk_size = source.min_chunk_size
        max_chunks_per_doc = source.max_chunks_per_doc

        # Override with frontmatter values if present
        if frontmatter is not None:
            if frontmatter.chunk_size is not None:
                chunk_size = frontmatter.chunk_size
            if frontmatter.chunk_overlap is not None:
                chunk_overlap = frontmatter.chunk_overlap
            if frontmatter.min_chunk_size is not None:
                min_chunk_size = frontmatter.min_chunk_size
            if frontmatter.max_chunks_per_doc is not None:
                max_chunks_per_doc = frontmatter.max_chunks_per_doc

        return ProcessorConfig(
            chunk_size=chunk_size,
            chunk_overlap=chunk_overlap,
            min_chunk_size=min_chunk_size,
            max_chunks_per_doc=max_chunks_per_doc,
        )
