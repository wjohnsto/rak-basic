"""Pipeline orchestrator for two-stage pipeline."""

from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING

from redis_agent_kit.vectorizer import Vectorizer

from .artifact_storage import ArtifactStorage
from .ingest_stage import IngestStage
from .models import IngestionManifest, PipelineConfig
from .prepare_stage import PrepareStage
from .vector_store import VectorStore

if TYPE_CHECKING:
    from docket import Docket

    from redis_agent_kit.middleware import PipelineMiddleware


@dataclass
class PipelineRunResult:
    """Result of a full pipeline run."""

    batch_id: str
    ingestion_manifest: IngestionManifest


class PipelineOrchestrator:
    """Orchestrates the two-stage pipeline.

    Provides both synchronous methods (prepare, ingest, run) and
    asynchronous methods (submit_prepare, submit_ingest, submit_full)
    that use Docket for background processing.

    Supports middleware for cross-cutting concerns like logging, timing,
    and validation.
    """

    def __init__(
        self,
        config: PipelineConfig,
        base_path: Path,
        vectorizer: Vectorizer | None = None,
        vector_store: VectorStore | None = None,
        docket: "Docket | None" = None,
        middleware: "list[PipelineMiddleware] | None" = None,
    ):
        """Initialize the orchestrator.

        Args:
            config: Pipeline configuration.
            base_path: Base path for document sources.
            vectorizer: Vectorizer for generating embeddings.
            vector_store: Vector store for storing embedded chunks.
            docket: Docket instance for background task submission.
            middleware: List of pipeline middleware to apply to stage execution.
        """
        self.config = config
        self.base_path = base_path
        self.vectorizer = vectorizer
        self.vector_store = vector_store
        self.docket = docket
        self.middleware = middleware or []
        self.storage = ArtifactStorage(artifacts_dir=config.artifacts_dir)

    def prepare(self) -> str:
        """Run the prepare stage synchronously.

        Returns:
            The batch ID of the prepared documents.
        """
        stage = PrepareStage(
            storage=self.storage,
            sources=self.config.sources,
            base_path=self.base_path,
        )
        return stage.prepare()

    def ingest(self, batch_id: str) -> IngestionManifest:
        """Run the ingest stage synchronously.

        Args:
            batch_id: The batch ID to ingest.

        Returns:
            The ingestion manifest.

        Raises:
            ValueError: If vectorizer or vector_store not configured.
        """
        if self.vectorizer is None or self.vector_store is None:
            raise ValueError("Vectorizer and vector_store required for ingestion")

        stage = IngestStage(
            storage=self.storage,
            vectorizer=self.vectorizer,
            vector_store=self.vector_store,
        )
        return stage.ingest(batch_id)

    def run(self) -> PipelineRunResult:
        """Run both stages synchronously.

        Returns:
            PipelineRunResult with batch_id and ingestion manifest.
        """
        batch_id = self.prepare()
        manifest = self.ingest(batch_id)
        return PipelineRunResult(batch_id=batch_id, ingestion_manifest=manifest)

    async def prepare_async(self) -> str:
        """Run the prepare stage with middleware support.

        Returns:
            The batch ID of the prepared documents.
        """
        if not self.middleware:
            return self.prepare()

        # Import here to avoid circular import (orchestrator <-> middleware)
        from redis_agent_kit.middleware import PipelineContext, PipelineMiddlewareChain

        ctx = PipelineContext(
            stage="prepare",
            batch_id=None,
            config=self.config,
            base_path=self.base_path,
            orchestrator=self,
        )

        async def handler(ctx: PipelineContext) -> str:
            return self.prepare()

        chain = PipelineMiddlewareChain(handler, self.middleware)
        result: str = await chain(ctx)
        return result

    async def ingest_async(self, batch_id: str) -> IngestionManifest:
        """Run the ingest stage with middleware support.

        Args:
            batch_id: The batch ID to ingest.

        Returns:
            The ingestion manifest.

        Raises:
            ValueError: If vectorizer or vector_store not configured.
        """
        if not self.middleware:
            return self.ingest(batch_id)

        # Import here to avoid circular import (orchestrator <-> middleware)
        from redis_agent_kit.middleware import PipelineContext, PipelineMiddlewareChain

        ctx = PipelineContext(
            stage="ingest",
            batch_id=batch_id,
            config=self.config,
            base_path=self.base_path,
            orchestrator=self,
        )

        async def handler(ctx: PipelineContext) -> IngestionManifest:
            if ctx.batch_id is None:
                raise ValueError("batch_id is required for ingest stage")
            return self.ingest(ctx.batch_id)

        chain = PipelineMiddlewareChain(handler, self.middleware)
        result: IngestionManifest = await chain(ctx)
        return result

    async def run_async(self) -> PipelineRunResult:
        """Run both stages with middleware support.

        Returns:
            PipelineRunResult with batch_id and ingestion manifest.
        """
        if not self.middleware:
            return self.run()

        # Import here to avoid circular import (orchestrator <-> middleware)
        from redis_agent_kit.middleware import PipelineContext, PipelineMiddlewareChain

        ctx = PipelineContext(
            stage="run",
            batch_id=None,
            config=self.config,
            base_path=self.base_path,
            orchestrator=self,
        )

        async def handler(ctx: PipelineContext) -> PipelineRunResult:
            batch_id = self.prepare()
            manifest = self.ingest(batch_id)
            return PipelineRunResult(batch_id=batch_id, ingestion_manifest=manifest)

        chain = PipelineMiddlewareChain(handler, self.middleware)
        result: PipelineRunResult = await chain(ctx)
        return result

    async def submit_prepare(self) -> str:
        """Submit prepare stage as background task.

        Returns:
            The task ID.

        Raises:
            ValueError: If docket not configured.
        """
        if self.docket is None:
            raise ValueError("Docket required for async submission")

        result = await self.docket.add(  # type: ignore[call-overload]
            "pipeline_prepare",
            config=self.config.model_dump(),
            base_path=str(self.base_path),
        )
        return str(result)

    async def submit_ingest(self, batch_id: str) -> str:
        """Submit ingest stage as background task.

        Args:
            batch_id: The batch ID to ingest.

        Returns:
            The task ID.

        Raises:
            ValueError: If docket not configured.
        """
        if self.docket is None:
            raise ValueError("Docket required for async submission")

        result = await self.docket.add(  # type: ignore[call-overload]
            "pipeline_ingest",
            config=self.config.model_dump(),
            batch_id=batch_id,
        )
        return str(result)

    async def submit_full(self) -> str:
        """Submit full pipeline as background task.

        Returns:
            The task ID.

        Raises:
            ValueError: If docket not configured.
        """
        if self.docket is None:
            raise ValueError("Docket required for async submission")

        result = await self.docket.add(  # type: ignore[call-overload]
            "pipeline_full",
            config=self.config.model_dump(),
            base_path=str(self.base_path),
        )
        return str(result)

    async def submit_document(self, content: str, filename: str) -> str:
        """Submit document for ingestion as background task.

        Args:
            content: The document content (Markdown with optional YAML frontmatter).
            filename: The filename for the document.

        Returns:
            The task ID.

        Raises:
            ValueError: If docket not configured.
        """
        if self.docket is None:
            raise ValueError("Docket required for async submission")

        result = await self.docket.add(  # type: ignore[call-overload]
            "pipeline_document",
            config=self.config.model_dump(),
            content=content,
            filename=filename,
        )
        return str(result)
