"""Prepare stage for two-stage pipeline (Stage 1)."""

from datetime import UTC, datetime
from pathlib import Path

from .artifact_storage import ArtifactStorage
from .frontmatter import FrontmatterParser
from .models import BatchManifest, Document, PreparedDocument, SourceConfig
from .processor import DocumentProcessor


class PrepareStage:
    """Stage 1: Scrape documents, parse frontmatter, chunk, and save to artifacts."""

    def __init__(
        self,
        storage: ArtifactStorage,
        sources: list[SourceConfig],
        base_path: Path,
    ):
        """Initialize PrepareStage.

        Args:
            storage: ArtifactStorage instance for saving artifacts.
            sources: List of source configurations.
            base_path: Base path for source documents.
        """
        self.storage = storage
        self.sources = sources
        self.base_path = Path(base_path)
        self.frontmatter_parser = FrontmatterParser()

    def prepare(self) -> str:
        """Prepare all documents from configured sources.

        Returns:
            Batch ID for the prepared documents.
        """
        batch_dir, batch_id = self.storage.create_batch()
        documents_prepared = 0
        chunks_created = 0

        # Process documents from each source
        for source in self.sources:
            source_docs, source_chunks = self._process_source(source, batch_id)
            documents_prepared += source_docs
            chunks_created += source_chunks

        # Process custom documents
        custom_docs, custom_chunks = self._process_custom_docs(batch_id)
        documents_prepared += custom_docs
        chunks_created += custom_chunks

        # Create and save manifest
        manifest = BatchManifest(
            batch_id=batch_id,
            batch_date=datetime.now(UTC).strftime("%Y-%m-%d"),
            documents_prepared=documents_prepared,
            chunks_created=chunks_created,
        )
        self.storage.save_batch_manifest(batch_id, manifest)

        return batch_id

    def _process_source(self, source: SourceConfig, batch_id: str) -> tuple[int, int]:
        """Process documents from a single source.

        Args:
            source: Source configuration.
            batch_id: Batch ID for saving documents.

        Returns:
            Tuple of (documents_prepared, chunks_created).
        """
        documents_prepared = 0
        chunks_created = 0

        for file_path in self.base_path.glob(source.path_pattern):
            if not file_path.is_file():
                continue

            content = file_path.read_text()
            frontmatter, body = self.frontmatter_parser.parse(content)
            config = self.frontmatter_parser.merge_config(frontmatter, source)

            # Create Document object for chunking
            doc = Document(
                title=file_path.stem,
                content=body,
                source=str(file_path.relative_to(self.base_path)),
            )
            assert doc.doc_id is not None

            # Chunk the document
            processor = DocumentProcessor(config)
            chunks = processor.chunk_document(doc)

            # Create prepared document
            prepared_doc = PreparedDocument(
                doc_id=doc.doc_id,
                title=file_path.stem,
                source=str(file_path.relative_to(self.base_path)),
                chunks=chunks,
                frontmatter=frontmatter,
                metadata=frontmatter.metadata if frontmatter else {},
            )

            self.storage.save_document(batch_id, prepared_doc)
            documents_prepared += 1
            chunks_created += len(chunks)

        return documents_prepared, chunks_created

    def _process_custom_docs(self, batch_id: str) -> tuple[int, int]:
        """Process custom documents from custom_docs_dir.

        Args:
            batch_id: Batch ID for saving documents.

        Returns:
            Tuple of (documents_prepared, chunks_created).
        """
        documents_prepared = 0
        chunks_created = 0

        for file_path in self.storage.list_custom_docs():
            content = file_path.read_text()
            frontmatter, body = self.frontmatter_parser.parse(content)

            # Use default config for custom docs, merged with frontmatter
            default_source = SourceConfig(
                name="custom", path_pattern="*.md", chunk_size=1000, chunk_overlap=200
            )
            config = self.frontmatter_parser.merge_config(frontmatter, default_source)

            # Create Document object for chunking
            doc = Document(
                title=file_path.stem,
                content=body,
                source=f"custom/{file_path.name}",
            )
            assert doc.doc_id is not None

            processor = DocumentProcessor(config)
            chunks = processor.chunk_document(doc)

            prepared_doc = PreparedDocument(
                doc_id=doc.doc_id,
                title=file_path.stem,
                source=f"custom/{file_path.name}",
                chunks=chunks,
                frontmatter=frontmatter,
                metadata=frontmatter.metadata if frontmatter else {},
            )

            self.storage.save_document(batch_id, prepared_doc)
            documents_prepared += 1
            chunks_created += len(chunks)

        return documents_prepared, chunks_created
