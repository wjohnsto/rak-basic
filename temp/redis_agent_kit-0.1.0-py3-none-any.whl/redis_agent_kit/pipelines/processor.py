"""Document processor for chunking documents."""

import re
from typing import Any

from .models import Chunk, Document, ProcessorConfig


class DocumentProcessor:
    """Processes documents into chunks for vectorization."""

    def __init__(self, config: ProcessorConfig | None = None):
        """Initialize processor with configuration.

        Args:
            config: Processing configuration. Uses defaults if not provided.
        """
        self.config = config or ProcessorConfig()

    def chunk_document(self, document: Document) -> list[Chunk]:
        """Split a document into chunks.

        Args:
            document: The document to chunk.

        Returns:
            List of chunks with metadata.
        """
        content = document.content

        # Strip YAML front matter if configured
        if self.config.strip_front_matter:
            content = self._strip_front_matter(content)

        # Clean up whitespace
        content = content.strip()

        # If content is short enough, return single chunk
        if len(content) <= self.config.chunk_size:
            return [self._create_chunk(document, content, 0)]

        # Split into chunks with overlap
        chunks: list[Chunk] = []
        start = 0
        chunk_index = 0
        prev_start = -1

        while start < len(content) and chunk_index < self.config.max_chunks_per_doc:
            # Prevent infinite loop (defensive check, should not trigger normally)
            if start == prev_start:  # pragma: no cover
                break
            prev_start = start

            end = min(start + self.config.chunk_size, len(content))

            # If this is not the last chunk, try to break at word boundary
            if end < len(content):
                # Look for last space within chunk
                last_space = content.rfind(" ", start, end)
                if last_space > start + self.config.min_chunk_size:
                    end = last_space

            chunk_content = content[start:end].strip()

            if chunk_content:  # Only add non-empty chunks
                chunks.append(self._create_chunk(document, chunk_content, chunk_index))
                chunk_index += 1

            # Move start forward, accounting for overlap
            if end >= len(content):
                break  # We've reached the end
            start = end - self.config.chunk_overlap
            if start <= prev_start:
                start = end  # Ensure forward progress

        return chunks

    def _create_chunk(self, document: Document, content: str, index: int) -> Chunk:
        """Create a chunk from document content.

        Args:
            document: Parent document.
            content: Chunk content.
            index: Chunk index.

        Returns:
            Chunk with metadata.
        """
        assert document.doc_id is not None
        chunk_id = f"{document.doc_id}_{index}"

        # Build metadata from document
        metadata: dict[str, Any] = {
            "source": document.source,
            "title": document.title,
            "doc_type": document.doc_type.value,
        }
        # Include any custom metadata from document
        metadata.update(document.metadata)

        return Chunk(
            chunk_id=chunk_id,
            doc_id=document.doc_id,
            content=content,
            chunk_index=index,
            metadata=metadata,
        )

    def _strip_front_matter(self, content: str) -> str:
        """Strip YAML front matter from content.

        Args:
            content: Content that may have front matter.

        Returns:
            Content with front matter removed.
        """
        # Match YAML front matter: starts with ---, ends with ---
        pattern = r"^---\s*\n.*?\n---\s*\n"
        return re.sub(pattern, "", content, flags=re.DOTALL)
