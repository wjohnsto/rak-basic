"""Vector store for storing and searching chunks with embeddings using RedisVL."""

import asyncio
import logging
from collections.abc import Awaitable
from typing import Any, TypeVar, cast

import redis.asyncio as redis
from redisvl.index import AsyncSearchIndex
from redisvl.query import VectorQuery

T = TypeVar("T")


def _redis_await(result: Awaitable[T] | T) -> Awaitable[T]:
    """Cast ambiguous redis-py return types for mypy."""
    return cast(Awaitable[T], result)


from .models import Chunk, SearchResult

logger = logging.getLogger(__name__)


class VectorStore:
    """Store and search document chunks with vector embeddings using RedisVL.

    Uses RedisVL's AsyncSearchIndex for schema management and vector search.
    Requires Redis Stack (redis-stack or Redis 8+) for vector search.
    """

    DEFAULT_DIMENSIONS = 1536  # OpenAI text-embedding-3-small default

    def __init__(
        self,
        client: redis.Redis,
        prefix: str = "rak",
        index_name: str = "chunks",
        dimensions: int | None = None,
    ):
        """Initialize vector store.

        Args:
            client: Async Redis client.
            prefix: Key prefix for all stored data.
            index_name: Name for the vector index.
            dimensions: Vector dimensions (auto-detected on first store if None).
        """
        self.client = client
        self.prefix = prefix
        self.index_name = index_name
        self._dimensions = dimensions
        self._index: AsyncSearchIndex | None = None
        self._index_created = False

    @property
    def full_index_name(self) -> str:
        """Full index name with prefix."""
        return f"{self.prefix}:{self.index_name}"

    def _chunk_key(self, chunk_id: str) -> str:
        """Get Redis key for a chunk."""
        return f"{self.prefix}:chunk:{chunk_id}"

    def _doc_chunks_key(self, doc_id: str) -> str:
        """Get Redis key for document's chunk set."""
        return f"{self.prefix}:doc_chunks:{doc_id}"

    def _all_chunks_key(self) -> str:
        """Get Redis key for all chunks set."""
        return f"{self.prefix}:all_chunks"

    def _build_schema(self, dims: int) -> dict[str, Any]:
        """Build RedisVL schema definition."""
        return {
            "index": {
                "name": self.full_index_name,
                "prefix": f"{self.prefix}:chunk:",
                "storage_type": "json",
            },
            "fields": [
                {"name": "$.chunk_id", "type": "text", "path": "$.chunk_id"},
                {"name": "$.doc_id", "type": "tag", "path": "$.doc_id"},
                {"name": "$.content", "type": "text", "path": "$.content"},
                {"name": "$.chunk_index", "type": "numeric", "path": "$.chunk_index"},
                {
                    "name": "$.embedding",
                    "type": "vector",
                    "path": "$.embedding",
                    "attrs": {
                        "dims": dims,
                        "distance_metric": "cosine",
                        "algorithm": "flat",
                        "datatype": "float32",
                    },
                },
            ],
        }

    async def ensure_index(self, dimensions: int | None = None) -> None:
        """Ensure the vector search index exists.

        Args:
            dimensions: Vector dimensions (uses stored or default if None).
        """
        if self._index_created and self._index is not None:
            return

        dims = dimensions or self._dimensions or self.DEFAULT_DIMENSIONS
        self._dimensions = dims

        schema = self._build_schema(dims)
        # Pass redis_client directly to avoid RedisVL trying to create its own connection
        self._index = AsyncSearchIndex.from_dict(schema, redis_client=self.client)

        # Create index if it doesn't exist
        if not await self._index.exists():
            await self._index.create(overwrite=False)
            logger.info(f"Created vector index {self.full_index_name} with {dims} dimensions")

        self._index_created = True

    async def store_chunk(
        self,
        chunk_id: str,
        doc_id: str,
        content: str,
        embedding: list[float],
        metadata: dict[str, Any] | None = None,
    ) -> None:
        """Store a single chunk asynchronously.

        Args:
            chunk_id: Unique chunk identifier.
            doc_id: Document ID this chunk belongs to.
            content: Chunk text content.
            embedding: Embedding vector.
            metadata: Optional metadata dict.
        """
        await self.ensure_index(len(embedding))

        key = self._chunk_key(chunk_id)
        data = {
            "chunk_id": chunk_id,
            "doc_id": doc_id,
            "content": content,
            "chunk_index": metadata.get("chunk_index", 0) if metadata else 0,
            "metadata": metadata or {},
            "embedding": embedding,  # Store as list for JSON
        }

        await _redis_await(self.client.json().set(key, "$", data))  # type: ignore[arg-type]
        await _redis_await(self.client.sadd(self._doc_chunks_key(doc_id), chunk_id))
        await _redis_await(self.client.sadd(self._all_chunks_key(), chunk_id))

    def store_chunk_sync(
        self,
        chunk_id: str,
        doc_id: str,
        content: str,
        embedding: list[float],
        metadata: dict[str, Any] | None = None,
    ) -> None:
        """Store a single chunk synchronously.

        Args:
            chunk_id: Unique chunk identifier.
            doc_id: Document ID this chunk belongs to.
            content: Chunk text content.
            embedding: Embedding vector.
            metadata: Optional metadata dict.
        """

        async def _store() -> None:
            await self.store_chunk(chunk_id, doc_id, content, embedding, metadata)

        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = None

        if loop and loop.is_running():
            import nest_asyncio

            nest_asyncio.apply()
            loop.run_until_complete(_store())
        else:
            asyncio.run(_store())

    async def store_chunks(
        self,
        chunks: list[Chunk],
        embeddings: list[list[float]],
    ) -> None:
        """Store chunks with their embeddings.

        Args:
            chunks: List of chunks to store.
            embeddings: Corresponding embeddings for each chunk.
        """
        if len(chunks) != len(embeddings):
            raise ValueError("Number of chunks must match number of embeddings")

        if not chunks:
            return

        await self.ensure_index(len(embeddings[0]))

        pipe = self.client.pipeline()

        for chunk, embedding in zip(chunks, embeddings, strict=False):
            key = self._chunk_key(chunk.chunk_id)

            # Store chunk data as JSON for FT.SEARCH
            data = {
                "chunk_id": chunk.chunk_id,
                "doc_id": chunk.doc_id,
                "content": chunk.content,
                "chunk_index": chunk.chunk_index,
                "metadata": chunk.metadata,
                "embedding": embedding,
            }
            pipe.json().set(key, "$", data)  # type: ignore[arg-type]

            # Add to document's chunk set
            pipe.sadd(self._doc_chunks_key(chunk.doc_id), chunk.chunk_id)

            # Add to all chunks set
            pipe.sadd(self._all_chunks_key(), chunk.chunk_id)

        await pipe.execute()

    async def search(
        self,
        query_embedding: list[float],
        limit: int = 10,
        distance_threshold: float | None = None,
    ) -> list[SearchResult]:
        """Search for similar chunks using RedisVL vector query.

        Args:
            query_embedding: Query vector to search with.
            limit: Maximum number of results.
            distance_threshold: Optional max distance (lower is more similar for cosine).

        Returns:
            List of SearchResult objects sorted by similarity.
        """
        await self.ensure_index(len(query_embedding))

        if self._index is None:
            logger.warning("Index not initialized")
            return []

        # Build RedisVL VectorQuery
        query = VectorQuery(
            vector=query_embedding,
            vector_field_name="$.embedding",
            return_fields=["$.chunk_id", "$.doc_id", "$.content", "$.metadata"],
            num_results=limit,
        )

        try:
            results = await self._index.query(query)
        except Exception as e:
            logger.warning(f"Vector search failed: {e}")
            return []

        search_results: list[SearchResult] = []
        for doc in results:
            # Parse score (distance) - RedisVL returns as 'vector_distance'
            score = float(doc.get("vector_distance", 1.0))

            # Apply distance threshold filter
            if distance_threshold is not None and score > distance_threshold:
                continue

            # Get document fields (RedisVL returns with $. prefix)
            content = doc.get("$.content", "")
            chunk_id = doc.get("$.chunk_id", "")
            doc_id = doc.get("$.doc_id", "")

            # Parse metadata
            metadata = doc.get("$.metadata", {})
            if isinstance(metadata, str):
                import json

                try:
                    metadata = json.loads(metadata)
                except (json.JSONDecodeError, TypeError):
                    metadata = {}

            search_results.append(
                SearchResult(
                    chunk_id=chunk_id,
                    doc_id=doc_id,
                    content=content,
                    score=score,
                    metadata=metadata if isinstance(metadata, dict) else {},
                )
            )

        return search_results

    async def get_chunk(self, chunk_id: str) -> Chunk | None:
        """Retrieve a chunk by ID.

        Args:
            chunk_id: The chunk ID.

        Returns:
            Chunk if found, None otherwise.
        """
        key = self._chunk_key(chunk_id)
        data: Any = await _redis_await(self.client.json().get(key))

        if not data:
            return None

        return Chunk(
            chunk_id=data["chunk_id"],
            doc_id=data["doc_id"],
            content=data["content"],
            chunk_index=int(data["chunk_index"]),
            metadata=data.get("metadata", {}),
        )

    async def delete_by_doc_id(self, doc_id: str) -> int:
        """Delete all chunks for a document.

        Args:
            doc_id: Document ID.

        Returns:
            Number of chunks deleted.
        """
        doc_chunks_key = self._doc_chunks_key(doc_id)
        chunk_ids = await _redis_await(self.client.smembers(doc_chunks_key))

        if not chunk_ids:
            return 0

        pipe = self.client.pipeline()
        for chunk_id in chunk_ids:
            pipe.delete(self._chunk_key(chunk_id))
            pipe.srem(self._all_chunks_key(), chunk_id)

        pipe.delete(doc_chunks_key)
        await pipe.execute()

        return len(chunk_ids)

    async def count(self) -> int:
        """Count total stored chunks.

        Returns:
            Number of chunks.
        """
        return int(await _redis_await(self.client.scard(self._all_chunks_key())))

    async def clear(self) -> None:
        """Delete all stored chunks and drop the index."""
        chunk_ids = await _redis_await(self.client.smembers(self._all_chunks_key()))

        if chunk_ids:
            pipe = self.client.pipeline()
            for chunk_id in chunk_ids:
                pipe.delete(self._chunk_key(chunk_id))
            pipe.delete(self._all_chunks_key())
            await pipe.execute()

        # Clean up doc_chunks keys
        pattern = f"{self.prefix}:doc_chunks:*"
        async for key in self.client.scan_iter(match=pattern):
            await self.client.delete(key)

        # Drop the index using RedisVL if available, else raw command
        try:
            if self._index is not None:
                await self._index.delete()
            else:
                await self.client.ft(self.full_index_name).dropindex(delete_documents=False)
            self._index_created = False
            self._index = None
        except (redis.ResponseError, Exception):
            pass  # Index doesn't exist
