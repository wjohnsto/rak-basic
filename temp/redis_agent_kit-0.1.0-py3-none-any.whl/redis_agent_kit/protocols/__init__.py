"""Protocol adapters for multi-protocol agent support.

This module provides adapters for different agent communication protocols:
- A2A (Agent-to-Agent Protocol)
- ACP (Agent Communication Protocol)

Each adapter translates between RAK primitives and protocol-specific types.
"""

from redis_agent_kit.protocols.a2a import A2AAdapter, create_a2a_router
from redis_agent_kit.protocols.acp import ACPAdapter, create_acp_router
from redis_agent_kit.protocols.base import ProtocolAdapter
from redis_agent_kit.protocols.unified import ProtocolConfig, create_multi_protocol_app

__all__ = [
    "A2AAdapter",
    "ACPAdapter",
    "ProtocolAdapter",
    "ProtocolConfig",
    "create_a2a_router",
    "create_acp_router",
    "create_multi_protocol_app",
]
