"""A2A protocol adapter.

Translates between RAK primitives and A2A protocol types.
"""

import json
from typing import Any

from redis_agent_kit.models import AgentCard, Message, TaskState, TaskStatus
from redis_agent_kit.protocols.a2a.models import (
    A2AArtifact,
    A2AMessage,
    A2ATask,
    A2ATaskState,
    A2ATaskStatus,
    TextPart,
)
from redis_agent_kit.protocols.base import ProtocolAdapter

# Status mapping: RAK TaskStatus -> A2A TaskState
_RAK_TO_A2A_STATUS: dict[TaskStatus, A2ATaskState] = {
    TaskStatus.QUEUED: A2ATaskState.SUBMITTED,
    TaskStatus.IN_PROGRESS: A2ATaskState.WORKING,
    TaskStatus.AWAITING_INPUT: A2ATaskState.INPUT_REQUIRED,
    TaskStatus.DONE: A2ATaskState.COMPLETED,
    TaskStatus.FAILED: A2ATaskState.FAILED,
    TaskStatus.CANCELLED: A2ATaskState.CANCELED,
}

# Reverse mapping: A2A TaskState -> RAK TaskStatus
_A2A_TO_RAK_STATUS: dict[A2ATaskState, TaskStatus] = {v: k for k, v in _RAK_TO_A2A_STATUS.items()}


class A2AAdapter(ProtocolAdapter):
    """Adapter for the A2A (Agent-to-Agent) protocol.

    Translates between RAK primitives (TaskState, Message) and A2A types
    (A2ATask, A2AMessage).

    Example:
        ```python
        from redis_agent_kit import AgentCard, Skill
        from redis_agent_kit.protocols.a2a import A2AAdapter

        card = AgentCard(
            name="My Agent",
            description="A helpful assistant",
            url="https://agent.example.com",
            skills=[Skill(id="chat", name="Chat", description="General chat")],
        )
        adapter = A2AAdapter(agent_card=card)

        # Convert RAK task to A2A task
        a2a_task = adapter.to_protocol_task(rak_task)
        ```
    """

    def __init__(self, agent_card: AgentCard) -> None:
        """Initialize the A2A adapter.

        Args:
            agent_card: The agent card for discovery.
        """
        self.agent_card = agent_card

    def map_status_to_a2a(self, status: TaskStatus) -> A2ATaskState:
        """Map RAK TaskStatus to A2A TaskState."""
        return _RAK_TO_A2A_STATUS[status]

    def map_status_from_a2a(self, state: A2ATaskState) -> TaskStatus:
        """Map A2A TaskState to RAK TaskStatus."""
        return _A2A_TO_RAK_STATUS[state]

    def to_protocol_task(self, task: TaskState) -> A2ATask:
        """Convert RAK TaskState to A2A Task.

        Args:
            task: The RAK TaskState to convert.

        Returns:
            A2A Task representation.
        """
        a2a_state = self.map_status_to_a2a(task.status)
        status = A2ATaskStatus(
            state=a2a_state,
            message=task.error_message if task.status == TaskStatus.FAILED else None,
        )

        # Convert result to artifact if present
        artifacts: list[A2AArtifact] = []
        if task.result is not None:
            result_text = (
                json.dumps(task.result) if not isinstance(task.result, str) else task.result
            )
            artifacts.append(A2AArtifact(parts=[TextPart(text=result_text)]))

        return A2ATask(
            id=task.task_id,
            context_id=task.session_id,
            status=status,
            artifacts=artifacts,
            metadata=task.metadata,
        )

    def from_protocol_message(self, message: A2AMessage) -> Message:
        """Convert A2A Message to RAK Message.

        Args:
            message: A2A Message to convert.

        Returns:
            RAK Message.
        """
        # Concatenate text parts
        text_parts = [p.text for p in message.parts if isinstance(p, TextPart)]
        content = "".join(text_parts)

        return Message(
            role=message.role,
            content=content,
            metadata=message.metadata,
        )

    def to_protocol_message(self, message: Message) -> A2AMessage:
        """Convert RAK Message to A2A Message.

        Args:
            message: RAK Message to convert.

        Returns:
            A2A Message representation.
        """
        # Map "assistant" role to "agent" for A2A
        role = "agent" if message.role == "assistant" else message.role

        return A2AMessage(
            role=role,
            parts=[TextPart(text=message.content)],
            metadata=message.metadata,
        )

    def get_discovery_document(self) -> dict[str, Any]:
        """Return the Agent Card as a discovery document.

        Returns:
            Dictionary representing the Agent Card for /.well-known/agent.json.
        """
        return self.agent_card.model_dump(mode="json")
