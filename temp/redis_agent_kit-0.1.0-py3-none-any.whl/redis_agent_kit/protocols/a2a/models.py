"""A2A protocol models.

These models represent the A2A protocol data structures as defined in
the A2A specification: https://a2a-protocol.org/
"""

from datetime import UTC, datetime
from enum import StrEnum
from typing import Annotated, Any, Literal

from pydantic import BaseModel, Field, RootModel


def _utc_now() -> datetime:
    """Return current UTC datetime."""
    return datetime.now(UTC)


class A2ATaskState(StrEnum):
    """A2A task states."""

    SUBMITTED = "submitted"
    WORKING = "working"
    INPUT_REQUIRED = "input-required"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELED = "canceled"


class TextPart(BaseModel):
    """A text part in an A2A message."""

    type: Literal["text"] = "text"
    text: str
    metadata: dict[str, Any] = Field(default_factory=dict)


class FilePart(BaseModel):
    """A file part in an A2A message."""

    type: Literal["file"] = "file"
    name: str
    media_type: str
    bytes: str | None = None  # Base64 encoded
    uri: str | None = None


class DataPart(BaseModel):
    """A structured data part in an A2A message."""

    type: Literal["data"] = "data"
    data: dict[str, Any]


# Union type for message parts
PartUnion = Annotated[
    TextPart | FilePart | DataPart,
    Field(discriminator="type"),
]


class A2APart(RootModel[PartUnion]):
    """A part in an A2A message (text, file, or data)."""

    root: PartUnion


class A2AMessage(BaseModel):
    """An A2A message containing parts."""

    role: str  # "user" or "agent"
    parts: list[TextPart | FilePart | DataPart]
    metadata: dict[str, Any] = Field(default_factory=dict)


class A2ATaskStatus(BaseModel):
    """Status of an A2A task."""

    state: A2ATaskState
    message: str | None = None
    timestamp: datetime = Field(default_factory=_utc_now)


class A2AArtifact(BaseModel):
    """An artifact produced by an A2A task."""

    parts: list[TextPart | FilePart | DataPart]
    name: str | None = None
    index: int = 0
    metadata: dict[str, Any] = Field(default_factory=dict)


class A2ATask(BaseModel):
    """An A2A task representing a unit of work."""

    id: str
    context_id: str | None = None  # Maps to RAK session_id
    status: A2ATaskStatus
    artifacts: list[A2AArtifact] = Field(default_factory=list)
    history: list[A2AMessage] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)
