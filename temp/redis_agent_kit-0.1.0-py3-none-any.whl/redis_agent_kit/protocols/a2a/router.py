"""A2A protocol FastAPI router.

Provides JSON-RPC endpoints for the A2A protocol.
"""

from typing import Any

from fastapi import APIRouter
from pydantic import BaseModel, Field

from redis_agent_kit.models import AgentCard, Caller, CallerType
from redis_agent_kit.protocols.a2a.adapter import A2AAdapter
from redis_agent_kit.protocols.a2a.models import A2AMessage, TextPart


class JSONRPCRequest(BaseModel):
    """JSON-RPC 2.0 request."""

    jsonrpc: str = "2.0"
    method: str
    params: dict[str, Any] = Field(default_factory=dict)
    id: str | int | None = None


class JSONRPCResponse(BaseModel):
    """JSON-RPC 2.0 response."""

    jsonrpc: str = "2.0"
    result: Any = None
    error: dict[str, Any] | None = None
    id: str | int | None = None


class JSONRPCError:
    """Standard JSON-RPC error codes."""

    PARSE_ERROR = -32700
    INVALID_REQUEST = -32600
    METHOD_NOT_FOUND = -32601
    INVALID_PARAMS = -32602
    INTERNAL_ERROR = -32603
    # Custom error codes
    TASK_NOT_FOUND = -32001


def create_a2a_router(agent_card: AgentCard, kit: Any) -> APIRouter:
    """Create a FastAPI router for A2A protocol endpoints.

    Args:
        agent_card: The agent card for discovery.
        kit: The AgentKit instance for task management.

    Returns:
        FastAPI router with A2A endpoints.
    """
    router = APIRouter()
    adapter = A2AAdapter(agent_card=agent_card)

    @router.get("/.well-known/agent.json")
    async def get_agent_card() -> dict[str, Any]:
        """Return the agent card for discovery."""
        return adapter.get_discovery_document()

    @router.post("/")
    async def handle_jsonrpc(request: JSONRPCRequest) -> JSONRPCResponse:
        """Handle JSON-RPC requests."""
        try:
            if request.method == "message/send":
                return await _handle_message_send(request, adapter, kit)
            elif request.method == "tasks/get":
                return await _handle_tasks_get(request, adapter, kit)
            elif request.method == "tasks/cancel":
                return await _handle_tasks_cancel(request, adapter, kit)
            else:
                return JSONRPCResponse(
                    id=request.id,
                    error={
                        "code": JSONRPCError.METHOD_NOT_FOUND,
                        "message": f"Method not found: {request.method}",
                    },
                )
        except Exception as e:
            return JSONRPCResponse(
                id=request.id,
                error={
                    "code": JSONRPCError.INTERNAL_ERROR,
                    "message": str(e),
                },
            )

    return router


async def _handle_message_send(
    request: JSONRPCRequest, adapter: A2AAdapter, kit: Any
) -> JSONRPCResponse:
    """Handle message/send method."""
    params = request.params
    message_data = params.get("message", {})
    context_id = params.get("contextId")
    metadata = params.get("metadata", {})
    callback_url = params.get("callbackUrl")  # Optional webhook for push notifications

    # Parse A2A message
    parts = [TextPart(**p) if p.get("type") == "text" else p for p in message_data.get("parts", [])]
    a2a_message = A2AMessage(
        role=message_data.get("role", "user"),
        parts=parts,
    )

    # Convert to RAK message
    adapter.from_protocol_message(a2a_message)

    # Extract message text from parts (text parts were converted to TextPart above)
    message_text = ""
    for part in parts:
        if isinstance(part, TextPart):
            message_text += part.text

    # Build context from metadata (include callback_url for webhook notification)
    context = {**metadata, "protocol": "a2a"}
    if callback_url:
        context["callback_url"] = callback_url

    # Build caller (A2A requests are always from agents)
    caller = Caller(
        type=CallerType.AGENT,
        id=metadata.get("agent_id"),
        name=metadata.get("agent_name"),
        metadata={"protocol": "a2a"},
    )

    # Create and submit task for background processing
    result = await kit.create_and_submit_task(
        message=message_text,
        context=context,
        session_id=context_id,
        caller=caller,
    )

    # Get the created task to convert to A2A format
    task = await kit.task_manager.get_task(result["task_id"])
    a2a_task = adapter.to_protocol_task(task)

    return JSONRPCResponse(
        id=request.id,
        result=a2a_task.model_dump(mode="json"),
    )


async def _handle_tasks_get(
    request: JSONRPCRequest, adapter: A2AAdapter, kit: Any
) -> JSONRPCResponse:
    """Handle tasks/get method."""
    task_id = request.params.get("id")
    task = await kit.task_manager.get_task(task_id)

    if task is None:
        return JSONRPCResponse(
            id=request.id,
            error={
                "code": JSONRPCError.TASK_NOT_FOUND,
                "message": f"Task not found: {task_id}",
            },
        )

    a2a_task = adapter.to_protocol_task(task)
    return JSONRPCResponse(
        id=request.id,
        result=a2a_task.model_dump(mode="json"),
    )


async def _handle_tasks_cancel(
    request: JSONRPCRequest, adapter: A2AAdapter, kit: Any
) -> JSONRPCResponse:
    """Handle tasks/cancel method."""
    task_id = request.params.get("id")
    task = await kit.task_manager.get_task(task_id)

    if task is None:
        return JSONRPCResponse(
            id=request.id,
            error={
                "code": JSONRPCError.TASK_NOT_FOUND,
                "message": f"Task not found: {task_id}",
            },
        )

    await kit.task_manager.update_status(task_id, "cancelled")
    task = await kit.task_manager.get_task(task_id)
    a2a_task = adapter.to_protocol_task(task)
    return JSONRPCResponse(
        id=request.id,
        result=a2a_task.model_dump(mode="json"),
    )
