"""ACP protocol adapter.

Translates between RAK primitives and ACP protocol types.
"""

import json
from typing import Any

from redis_agent_kit.models import AgentManifest, Message, TaskState, TaskStatus
from redis_agent_kit.protocols.acp.models import (
    ACPMessage,
    ACPRun,
    ACPRunState,
    ACPRunStatus,
    ACPTextContent,
)
from redis_agent_kit.protocols.base import ProtocolAdapter

# Status mapping: RAK TaskStatus -> ACP RunState
_RAK_TO_ACP_STATUS: dict[TaskStatus, ACPRunState] = {
    TaskStatus.QUEUED: ACPRunState.CREATED,
    TaskStatus.IN_PROGRESS: ACPRunState.IN_PROGRESS,
    TaskStatus.AWAITING_INPUT: ACPRunState.AWAITING,
    TaskStatus.DONE: ACPRunState.COMPLETED,
    TaskStatus.FAILED: ACPRunState.FAILED,
    TaskStatus.CANCELLED: ACPRunState.CANCELLED,
}

# Reverse mapping: ACP RunState -> RAK TaskStatus
_ACP_TO_RAK_STATUS: dict[ACPRunState, TaskStatus] = {
    ACPRunState.CREATED: TaskStatus.QUEUED,
    ACPRunState.IN_PROGRESS: TaskStatus.IN_PROGRESS,
    ACPRunState.AWAITING: TaskStatus.AWAITING_INPUT,
    ACPRunState.COMPLETED: TaskStatus.DONE,
    ACPRunState.FAILED: TaskStatus.FAILED,
    ACPRunState.CANCELING: TaskStatus.IN_PROGRESS,  # Map to in_progress
    ACPRunState.CANCELLED: TaskStatus.CANCELLED,
    ACPRunState.EXPIRED: TaskStatus.FAILED,  # Map to failed
}


class ACPAdapter(ProtocolAdapter):
    """Adapter for the ACP (Agent Communication Protocol).

    Translates between RAK primitives (TaskState, Message) and ACP types
    (ACPRun, ACPMessage).

    Example:
        ```python
        from redis_agent_kit import AgentManifest
        from redis_agent_kit.protocols.acp import ACPAdapter

        manifest = AgentManifest(
            name="my-agent",
            description="A helpful assistant",
        )
        adapter = ACPAdapter(agent_manifest=manifest)

        # Convert RAK task to ACP run
        acp_run = adapter.to_protocol_task(rak_task)
        ```
    """

    def __init__(self, agent_manifest: AgentManifest) -> None:
        """Initialize the ACP adapter.

        Args:
            agent_manifest: The agent manifest for discovery.
        """
        self.agent_manifest = agent_manifest

    def map_status_to_acp(self, status: TaskStatus) -> ACPRunState:
        """Map RAK TaskStatus to ACP RunState."""
        return _RAK_TO_ACP_STATUS[status]

    def map_status_from_acp(self, state: ACPRunState) -> TaskStatus:
        """Map ACP RunState to RAK TaskStatus."""
        return _ACP_TO_RAK_STATUS[state]

    def to_protocol_task(self, task: TaskState) -> ACPRun:
        """Convert RAK TaskState to ACP Run.

        Args:
            task: The RAK TaskState to convert.

        Returns:
            ACP Run representation.
        """
        acp_state = self.map_status_to_acp(task.status)
        status = ACPRunStatus(
            state=acp_state,
            message=task.error_message if task.status == TaskStatus.FAILED else None,
        )

        # Convert result to output if present
        output: list[ACPMessage] = []
        if task.result is not None:
            result_text = (
                json.dumps(task.result) if not isinstance(task.result, str) else task.result
            )
            output.append(
                ACPMessage(
                    role="agent",
                    parts=[ACPTextContent(content=result_text)],
                )
            )

        return ACPRun(
            id=task.task_id,
            agent_name=self.agent_manifest.name,
            status=status,
            session_id=task.session_id,
            output=output,
            metadata=task.metadata,
        )

    def from_protocol_message(self, message: ACPMessage) -> Message:
        """Convert ACP Message to RAK Message.

        Args:
            message: ACP Message to convert.

        Returns:
            RAK Message.
        """
        # Concatenate text parts
        text_parts = [p.content for p in message.parts]
        content = "".join(text_parts)

        return Message(
            role=message.role,
            content=content,
            metadata=message.metadata,
        )

    def to_protocol_message(self, message: Message) -> ACPMessage:
        """Convert RAK Message to ACP Message.

        Args:
            message: RAK Message to convert.

        Returns:
            ACP Message representation.
        """
        # Map "assistant" role to "agent" for ACP
        role = "agent" if message.role == "assistant" else message.role

        return ACPMessage(
            role=role,
            parts=[ACPTextContent(content=message.content)],
            metadata=message.metadata,
        )

    def get_discovery_document(self) -> dict[str, Any]:
        """Return the Agent Manifest as a discovery document.

        Returns:
            Dictionary representing the Agent Manifest for /agents.
        """
        return self.agent_manifest.model_dump(mode="json")
