"""ACP protocol models.

These models represent the ACP protocol data structures as defined in
the ACP specification: https://agentcommunicationprotocol.dev/
"""

from datetime import UTC, datetime
from enum import StrEnum
from typing import Any, Literal

from pydantic import BaseModel, Field


def _utc_now() -> datetime:
    """Return current UTC datetime."""
    return datetime.now(UTC)


class ACPRunState(StrEnum):
    """ACP run states."""

    CREATED = "created"
    IN_PROGRESS = "in_progress"
    AWAITING = "awaiting"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELING = "canceling"
    CANCELLED = "cancelled"
    EXPIRED = "expired"


class ACPTextContent(BaseModel):
    """A text content part in an ACP message."""

    type: Literal["text"] = "text"
    content: str
    metadata: dict[str, Any] = Field(default_factory=dict)


class ACPMessage(BaseModel):
    """An ACP message containing content parts."""

    role: str  # "user" or "agent"
    parts: list[ACPTextContent]
    metadata: dict[str, Any] = Field(default_factory=dict)


class ACPRunStatus(BaseModel):
    """Status of an ACP run."""

    state: ACPRunState
    message: str | None = None
    timestamp: datetime = Field(default_factory=_utc_now)


class ACPRun(BaseModel):
    """An ACP run representing a unit of work."""

    id: str
    agent_name: str
    status: ACPRunStatus
    session_id: str | None = None  # Maps to RAK session_id
    input: list[ACPMessage] = Field(default_factory=list)
    output: list[ACPMessage] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)
