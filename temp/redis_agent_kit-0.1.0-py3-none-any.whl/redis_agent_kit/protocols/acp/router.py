"""ACP protocol FastAPI router.

Provides REST endpoints for the ACP protocol.
"""

from typing import Any

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from redis_agent_kit.models import AgentManifest, Caller, CallerType
from redis_agent_kit.protocols.acp.adapter import ACPAdapter


class CreateRunRequest(BaseModel):
    """Request to create a new run."""

    agent_name: str
    session_id: str | None = None
    input: list[dict[str, Any]] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)
    callback_url: str | None = Field(
        default=None,
        description="Optional webhook URL to receive task completion notification",
    )


def create_acp_router(agent_manifest: AgentManifest, kit: Any) -> APIRouter:
    """Create a FastAPI router for ACP protocol endpoints.

    Args:
        agent_manifest: The agent manifest for discovery.
        kit: The AgentKit instance for task management.

    Returns:
        FastAPI router with ACP endpoints.
    """
    router = APIRouter()
    adapter = ACPAdapter(agent_manifest=agent_manifest)

    @router.get("/agents")
    async def list_agents() -> list[dict[str, Any]]:
        """List available agents."""
        return [adapter.get_discovery_document()]

    @router.post("/runs")
    async def create_run(request: CreateRunRequest) -> dict[str, Any]:
        """Create a new run."""
        # Extract message text from input
        message_text = ""
        for msg in request.input:
            for part in msg.get("parts", []):
                if part.get("type") == "text":
                    message_text += part.get("content", "") or part.get("text", "")

        # Build context from metadata (include callback_url for webhook notification)
        context = {
            **request.metadata,
            "protocol": "acp",
            "agent_name": request.agent_name,
        }
        if request.callback_url:
            context["callback_url"] = request.callback_url

        # Build caller (ACP requests are always from agents)
        caller = Caller(
            type=CallerType.AGENT,
            id=request.metadata.get("agent_id"),
            name=request.metadata.get("agent_name"),
            metadata={"protocol": "acp"},
        )

        # Create and submit task for background processing
        result = await kit.create_and_submit_task(
            message=message_text,
            context=context,
            session_id=request.session_id,
            caller=caller,
        )

        # Get the created task to convert to ACP format
        task = await kit.task_manager.get_task(result["task_id"])
        acp_run = adapter.to_protocol_task(task)
        return acp_run.model_dump(mode="json")

    @router.get("/runs/{run_id}")
    async def get_run(run_id: str) -> dict[str, Any]:
        """Get a run by ID."""
        task = await kit.task_manager.get_task(run_id)
        if task is None:
            raise HTTPException(status_code=404, detail=f"Run not found: {run_id}")

        acp_run = adapter.to_protocol_task(task)
        return acp_run.model_dump(mode="json")

    @router.post("/runs/{run_id}/cancel")
    async def cancel_run(run_id: str) -> dict[str, Any]:
        """Cancel a run."""
        task = await kit.task_manager.get_task(run_id)
        if task is None:
            raise HTTPException(status_code=404, detail=f"Run not found: {run_id}")

        await kit.task_manager.update_status(run_id, "cancelled")
        task = await kit.task_manager.get_task(run_id)
        acp_run = adapter.to_protocol_task(task)
        return acp_run.model_dump(mode="json")

    return router
