"""Unified multi-protocol server factory.

Creates a FastAPI application that can serve multiple agent protocols
simultaneously: A2A, ACP, and REST.
"""

from typing import Any

from fastapi import FastAPI
from pydantic import BaseModel

from redis_agent_kit.models import AgentCard, AgentManifest
from redis_agent_kit.protocols.a2a import create_a2a_router
from redis_agent_kit.protocols.acp import create_acp_router


class ProtocolConfig(BaseModel):
    """Configuration for which protocols to enable."""

    enable_a2a: bool = False
    enable_acp: bool = False
    enable_rest: bool = True


def create_multi_protocol_app(
    kit: Any,
    config: ProtocolConfig | None = None,
    agent_card: AgentCard | None = None,
    agent_manifest: AgentManifest | None = None,
    **kwargs: Any,
) -> FastAPI:
    """Create a FastAPI app with multiple protocol support.

    This factory creates a unified server that can expose:
    - A2A (Agent-to-Agent) protocol endpoints
    - ACP (Agent Communication Protocol) endpoints
    - REST API endpoints

    Args:
        kit: The AgentKit instance for task management.
        config: Protocol configuration. Defaults to REST only.
        agent_card: Required when A2A is enabled.
        agent_manifest: Required when ACP is enabled.
        **kwargs: Additional kwargs passed to FastAPI constructor.

    Returns:
        FastAPI application with configured protocol endpoints.

    Raises:
        ValueError: If required configuration is missing for enabled protocols.

    Example:
        ```python
        from redis_agent_kit import AgentKit, AgentCard, AgentManifest
        from redis_agent_kit.protocols.unified import (
            create_multi_protocol_app,
            ProtocolConfig,
        )

        kit = AgentKit(redis_url="redis://localhost:6379")
        config = ProtocolConfig(enable_a2a=True, enable_acp=True)

        agent_card = AgentCard(
            name="My Agent",
            description="A helpful assistant",
            url="http://localhost:8000",
        )
        agent_manifest = AgentManifest(
            name="my-agent",
            description="A helpful assistant",
        )

        app = create_multi_protocol_app(
            kit=kit,
            config=config,
            agent_card=agent_card,
            agent_manifest=agent_manifest,
        )
        ```
    """
    if config is None:
        config = ProtocolConfig()

    # Validate required configuration
    if config.enable_a2a and agent_card is None:
        raise ValueError("agent_card is required when A2A is enabled")
    if config.enable_acp and agent_manifest is None:
        raise ValueError("agent_manifest is required when ACP is enabled")

    # Set defaults for FastAPI
    defaults = {
        "title": "Multi-Protocol Agent Server",
        "description": "Agent server supporting A2A, ACP, and REST protocols",
        "version": "1.0.0",
    }
    for key, value in defaults.items():
        kwargs.setdefault(key, value)

    app = FastAPI(**kwargs)

    # Mount A2A router
    if config.enable_a2a and agent_card is not None:
        a2a_router = create_a2a_router(agent_card=agent_card, kit=kit)
        app.include_router(a2a_router, tags=["A2A"])

    # Mount ACP router
    if config.enable_acp and agent_manifest is not None:
        acp_router = create_acp_router(agent_manifest=agent_manifest, kit=kit)
        app.include_router(acp_router, tags=["ACP"])

    return app
