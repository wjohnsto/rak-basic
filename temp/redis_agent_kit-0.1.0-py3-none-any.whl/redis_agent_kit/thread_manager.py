"""Thread manager for Redis Agent Kit."""

from collections.abc import Awaitable
from datetime import UTC, datetime
from typing import Any, TypeVar, cast

import redis.asyncio as redis
from ulid import ULID

from redis_agent_kit.keys import RedisKeys
from redis_agent_kit.models import Message, Thread

T = TypeVar("T")


def _redis_await(result: Awaitable[T] | T) -> Awaitable[T]:
    return cast(Awaitable[T], result)


class ThreadManager:
    """Manages thread state in Redis.

    Threads represent conversations or sessions. They contain messages
    and context that persists across multiple tasks.
    """

    def __init__(
        self,
        redis_client: redis.Redis,
        prefix: str | None = None,
    ):
        """Initialize ThreadManager.

        Args:
            redis_client: Async Redis client
            prefix: Optional custom key prefix (default: 'rak')
        """
        self._redis = redis_client
        self._prefix = prefix

    async def create_thread(
        self,
        context: dict[str, Any] | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> Thread:
        """Create a new thread.

        Args:
            context: Optional context data (user info, instance IDs, etc.)
            metadata: Optional metadata

        Returns:
            The created Thread
        """
        thread_id = str(ULID())
        now = datetime.now(UTC)

        thread = Thread(
            thread_id=thread_id,
            context=context or {},
            metadata=metadata or {},
            created_at=now,
            updated_at=now,
        )

        # Store thread state
        key = RedisKeys.thread(thread_id, self._prefix)
        await self._redis.set(key, thread.model_dump_json())

        # Add to index
        await _redis_await(self._redis.sadd(RedisKeys.all_threads(self._prefix), thread_id))

        return thread

    async def get_thread(self, thread_id: str) -> Thread | None:
        """Get a thread by ID.

        Args:
            thread_id: The thread ID

        Returns:
            Thread if found, None otherwise
        """
        key = RedisKeys.thread(thread_id, self._prefix)
        data = await self._redis.get(key)
        if data is None:
            return None
        return Thread.model_validate_json(data)

    async def add_message(
        self,
        thread_id: str,
        role: str,
        content: str,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        """Add a message to a thread.

        Args:
            thread_id: The thread ID
            role: Message role (user, assistant, system, tool)
            content: Message content
            metadata: Optional message metadata
        """
        thread = await self.get_thread(thread_id)
        if thread is None:
            return

        message = Message(
            role=role,
            content=content,
            metadata=metadata or {},
        )
        thread.messages.append(message)
        thread.updated_at = datetime.now(UTC)

        key = RedisKeys.thread(thread_id, self._prefix)
        await self._redis.set(key, thread.model_dump_json())

    async def get_messages(
        self,
        thread_id: str,
        limit: int | None = None,
    ) -> list[Message]:
        """Get messages from a thread.

        Args:
            thread_id: The thread ID
            limit: Optional limit on number of messages (most recent)

        Returns:
            List of Message objects
        """
        thread = await self.get_thread(thread_id)
        if thread is None:
            return []

        messages = thread.messages
        if limit is not None:
            # Return the last N messages
            messages = messages[-limit:]
        return messages

    async def update_context(
        self,
        thread_id: str,
        context: dict[str, Any],
    ) -> None:
        """Update thread context (merges with existing).

        Args:
            thread_id: The thread ID
            context: Context data to merge
        """
        thread = await self.get_thread(thread_id)
        if thread is None:
            return

        thread.context.update(context)
        thread.updated_at = datetime.now(UTC)

        key = RedisKeys.thread(thread_id, self._prefix)
        await self._redis.set(key, thread.model_dump_json())

    async def delete_thread(self, thread_id: str) -> None:
        """Delete a thread.

        Args:
            thread_id: The thread ID to delete
        """
        # Remove from index
        await _redis_await(self._redis.srem(RedisKeys.all_threads(self._prefix), thread_id))

        # Remove the thread data
        key = RedisKeys.thread(thread_id, self._prefix)
        await self._redis.delete(key)
