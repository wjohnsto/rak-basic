"""Decorator and utilities for convenient tool definition.

This module provides a @tool decorator that automatically generates JSON schemas
from Python function signatures, type hints, and docstrings.

Example:
    from typing import Annotated
    from redis_agent_kit.tools import tool, Param

    @tool
    async def search_knowledge(
        query: Annotated[str, "Search query to find relevant content"],
        limit: Annotated[int, Param(description="Max results", ge=1, le=100)] = 5,
    ) -> dict:
        '''Search the knowledge base.'''
        return {"results": [...]}

    # Get the ToolDefinition
    tool_def = search_knowledge.tool_definition

    # Get OpenAI function calling format
    openai_schema = search_knowledge.to_openai_schema()
"""

from __future__ import annotations

import inspect
import re
import types
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from functools import update_wrapper
from typing import Annotated, Any, get_args, get_origin, get_type_hints

from pydantic import BaseModel

from .models import Tool, ToolCapability, ToolDefinition, ToolMetadata


@dataclass
class Param:
    """Parameter metadata for use with Annotated type hints.

    Example:
        from typing import Annotated
        from redis_agent_kit.tools import tool, Param

        @tool
        async def search(
            query: Annotated[str, Param(description="Search query")],
            limit: Annotated[int, Param(description="Max results", ge=1, le=100)] = 10,
        ) -> dict:
            '''Search the database.'''
            return {}
    """

    description: str | None = None
    # JSON Schema validation constraints
    ge: int | float | None = None  # >= minimum
    gt: int | float | None = None  # > exclusiveMinimum
    le: int | float | None = None  # <= maximum
    lt: int | float | None = None  # < exclusiveMaximum
    min_length: int | None = None
    max_length: int | None = None
    pattern: str | None = None
    enum: list[Any] | None = field(default=None)

    def to_schema_constraints(self) -> dict[str, Any]:
        """Convert constraints to JSON Schema properties."""
        constraints: dict[str, Any] = {}
        if self.ge is not None:
            constraints["minimum"] = self.ge
        if self.gt is not None:
            constraints["exclusiveMinimum"] = self.gt
        if self.le is not None:
            constraints["maximum"] = self.le
        if self.lt is not None:
            constraints["exclusiveMaximum"] = self.lt
        if self.min_length is not None:
            constraints["minLength"] = self.min_length
        if self.max_length is not None:
            constraints["maxLength"] = self.max_length
        if self.pattern is not None:
            constraints["pattern"] = self.pattern
        if self.enum is not None:
            constraints["enum"] = self.enum
        return constraints


def _extract_annotated_metadata(
    type_hint: Any,
) -> tuple[Any, str | None, dict[str, Any]]:
    """Extract the base type, description, and constraints from an Annotated type.

    Args:
        type_hint: A type hint, possibly Annotated[T, ...]

    Returns:
        Tuple of (base_type, description, constraints_dict)
    """
    if get_origin(type_hint) is Annotated:
        args = get_args(type_hint)
        base_type = args[0]
        description = None
        constraints: dict[str, Any] = {}

        for meta in args[1:]:
            if isinstance(meta, str):
                description = meta
            elif isinstance(meta, Param):
                if meta.description:
                    description = meta.description
                constraints.update(meta.to_schema_constraints())

        return base_type, description, constraints

    return type_hint, None, {}


# Python type to JSON Schema type mapping
TYPE_MAP: dict[type, str] = {
    str: "string",
    int: "integer",
    float: "number",
    bool: "boolean",
    list: "array",
    dict: "object",
    type(None): "null",
}


def _python_type_to_json_schema(py_type: type) -> dict[str, Any]:
    """Convert a Python type annotation to JSON Schema.

    Args:
        py_type: Python type annotation

    Returns:
        JSON Schema dict for the type
    """
    # Handle None/NoneType
    if py_type is type(None):
        return {"type": "null"}

    # Handle basic types
    if py_type in TYPE_MAP:
        return {"type": TYPE_MAP[py_type]}

    # Handle Python 3.10+ union types (X | Y)
    if isinstance(py_type, types.UnionType):
        args = get_args(py_type)
        if type(None) in args:
            non_none_args = [a for a in args if a is not type(None)]
            if len(non_none_args) == 1:
                return _python_type_to_json_schema(non_none_args[0])
            return {"anyOf": [_python_type_to_json_schema(a) for a in args if a is not type(None)]}
        return {"anyOf": [_python_type_to_json_schema(a) for a in args]}

    # Handle Optional[X] (Union[X, None])
    origin = getattr(py_type, "__origin__", None)

    if origin is type(None):
        return {"type": "null"}

    # Handle Union types (including Optional)
    if origin is not None:
        args = getattr(py_type, "__args__", ())

        # Check for Optional (Union[X, None])
        if type(None) in args:
            non_none_args = [a for a in args if a is not type(None)]
            if len(non_none_args) == 1:
                # Simple Optional[X]
                return _python_type_to_json_schema(non_none_args[0])
            # Union with None and multiple types - return anyOf
            return {"anyOf": [_python_type_to_json_schema(a) for a in args if a is not type(None)]}

        # Handle list[X]
        if origin is list:
            if args:
                return {"type": "array", "items": _python_type_to_json_schema(args[0])}
            return {"type": "array"}

        # Handle dict[K, V]
        if origin is dict:
            return {"type": "object"}

    # Handle Pydantic models
    if isinstance(py_type, type) and issubclass(py_type, BaseModel):
        return py_type.model_json_schema()

    # Handle string literal types like "str", "int" (from get_type_hints with string annotations)
    if isinstance(py_type, str):
        type_map = {
            "str": "string",
            "int": "integer",
            "float": "number",
            "bool": "boolean",
        }
        return {"type": type_map.get(py_type, "string")}

    # Fallback to string
    return {"type": "string"}


def _parse_docstring(docstring: str | None) -> tuple[str, dict[str, str]]:
    """Parse a docstring to extract description and parameter descriptions.

    Supports Google-style and NumPy-style docstrings.

    Args:
        docstring: The function docstring

    Returns:
        Tuple of (main description, {param_name: param_description})
    """
    if not docstring:
        return "", {}

    lines = docstring.strip().split("\n")
    description_lines: list[str] = []
    param_descriptions: dict[str, str] = {}

    # States: 'desc', 'args', 'other'
    state = "desc"
    current_param: str | None = None
    current_param_desc: list[str] = []

    for line in lines:
        stripped = line.strip()

        # Check for section headers (Google style)
        if stripped.lower() in ("args:", "arguments:", "parameters:", "params:"):
            state = "args"
            continue
        elif stripped.lower() in (
            "returns:",
            "return:",
            "raises:",
            "example:",
            "examples:",
            "note:",
            "notes:",
            "yields:",
        ):
            # Save any pending param
            if current_param and current_param_desc:
                param_descriptions[current_param] = " ".join(current_param_desc).strip()
            state = "other"
            continue

        # Check for NumPy style section headers
        if stripped and state == "desc" and re.match(r"^-{3,}$", stripped):
            state = "other"
            continue

        if state == "desc":
            if stripped:
                description_lines.append(stripped)
            elif description_lines:
                # Empty line after description - might be end of description
                pass

        elif state == "args":
            # Google style: param_name: description
            # or: param_name (type): description
            match = re.match(r"^(\w+)\s*(?:\([^)]*\))?\s*:\s*(.*)$", stripped)
            if match:
                # Save previous param
                if current_param and current_param_desc:
                    param_descriptions[current_param] = " ".join(current_param_desc).strip()
                current_param = match.group(1)
                current_param_desc = [match.group(2)] if match.group(2) else []
            elif stripped and current_param:
                # Continuation of previous param description
                current_param_desc.append(stripped)

    # Save final param
    if current_param and current_param_desc:
        param_descriptions[current_param] = " ".join(current_param_desc).strip()

    return " ".join(description_lines), param_descriptions


def tool_from_function(
    func: Callable[..., Awaitable[Any]],
    *,
    name: str | None = None,
    description: str | None = None,
    capability: ToolCapability = ToolCapability.CUSTOM,
) -> Tool:
    """Create a Tool from a function using introspection.

    Automatically generates JSON schema from function signature, type hints,
    and docstring.

    Args:
        func: The async function to create a tool from
        name: Optional override for tool name (default: function name)
        description: Optional override for description (default: from docstring)
        capability: Tool capability category

    Returns:
        Tool instance ready for use

    Example:
        async def get_weather(city: str, units: str = "celsius") -> dict:
            '''Get weather for a city.

            Args:
                city: The city name
                units: Temperature units (celsius or fahrenheit)
            '''
            return {"temp": 72, "city": city}

        weather_tool = tool_from_function(get_weather)
        result = await weather_tool.invoke({"city": "London"})
    """
    tool_name = name or func.__name__
    docstring = func.__doc__
    doc_description, param_descriptions = _parse_docstring(docstring)
    tool_description = description or doc_description or f"Execute {tool_name}"

    # Get type hints (include_extras=True preserves Annotated metadata)
    try:
        hints = get_type_hints(func, include_extras=True)
    except Exception:
        hints = {}

    # Get signature
    sig = inspect.signature(func)
    parameters: dict[str, Any] = {"type": "object", "properties": {}, "required": []}

    for param_name, param in sig.parameters.items():
        # Skip *args, **kwargs, self, cls
        if param.kind in (
            inspect.Parameter.VAR_POSITIONAL,
            inspect.Parameter.VAR_KEYWORD,
        ):
            continue
        if param_name in ("self", "cls"):
            continue

        # Get type hint
        py_type = hints.get(param_name, str)
        if py_type is inspect.Parameter.empty:
            py_type = str

        # Extract Annotated metadata (description and constraints)
        base_type, annotated_desc, constraints = _extract_annotated_metadata(py_type)

        # Build parameter schema from base type
        param_schema = _python_type_to_json_schema(base_type)

        # Add constraints from Param
        param_schema.update(constraints)

        # Add description: Annotated takes priority, then docstring
        if annotated_desc:
            param_schema["description"] = annotated_desc
        elif param_name in param_descriptions:
            param_schema["description"] = param_descriptions[param_name]

        # Handle default values
        if param.default is not inspect.Parameter.empty:
            param_schema["default"] = param.default
        else:
            parameters["required"].append(param_name)

        parameters["properties"][param_name] = param_schema

    # Create ToolDefinition
    tool_def = ToolDefinition(
        name=tool_name,
        description=tool_description,
        parameters=parameters,
        capability=capability,
    )

    # Create Tool with invoke wrapper
    async def _invoke(args: dict[str, Any]) -> Any:
        return await func(**(args or {}))

    return Tool(
        metadata=ToolMetadata(
            name=tool_name,
            description=tool_description,
            capability=capability,
            provider_name="function",
        ),
        definition=tool_def,
        invoke=_invoke,
    )


class ToolWrapper:
    """Wrapper that holds both the function and its tool definition."""

    def __init__(
        self,
        func: Callable[..., Awaitable[Any]],
        tool: Tool,
    ):
        self._func = func
        self._tool = tool
        # Copy function attributes
        self.__name__ = func.__name__
        self.__doc__ = func.__doc__
        module_name = getattr(func, "__module__", "")
        self.__module__ = module_name if isinstance(module_name, str) else ""
        self.__wrapped__ = func

    async def __call__(self, *args: Any, **kwargs: Any) -> Any:
        """Call the underlying function."""
        return await self._func(*args, **kwargs)

    @property
    def tool_definition(self) -> ToolDefinition:
        """Get the ToolDefinition for this function."""
        return self._tool.definition

    @property
    def tool(self) -> Tool:
        """Get the full Tool object."""
        return self._tool

    def to_openai_schema(self) -> dict[str, Any]:
        """Get OpenAI function calling format."""
        return self._tool.to_openai_schema()

    async def invoke(self, args: dict[str, Any]) -> Any:
        """Invoke the tool with arguments dict."""
        return await self._tool.invoke(args)


def tool(
    func: Callable[..., Awaitable[Any]] | None = None,
    *,
    name: str | None = None,
    description: str | None = None,
    capability: ToolCapability = ToolCapability.CUSTOM,
) -> Callable[..., Awaitable[Any]] | Callable[[Callable[..., Awaitable[Any]]], ToolWrapper]:
    """Decorator to convert a function into a tool with automatic schema generation.

    Can be used with or without parentheses:
        @tool
        async def my_func(...): ...

        @tool(name="custom_name")
        async def my_func(...): ...

    Args:
        func: The function to decorate (when used without parentheses)
        name: Optional override for tool name
        description: Optional override for description
        capability: Tool capability category

    Returns:
        ToolWrapper that wraps the function with tool metadata

    Example:
        @tool
        async def remember(fact: str) -> dict:
            '''Store important information for later.

            Args:
                fact: What to remember
            '''
            await memory.create_memory(fact)
            return {"stored": True}

        @tool(name="recall", capability=ToolCapability.KNOWLEDGE)
        async def search_memories(query: str, limit: int = 5) -> dict:
            '''Search for relevant memories.

            Args:
                query: What to search for
                limit: Maximum results
            '''
            return await memory.search(query, limit=limit)

        # Access tool definition
        print(remember.tool_definition)

        # Get OpenAI schema
        tools = [remember.to_openai_schema(), search_memories.to_openai_schema()]
    """

    def decorator(fn: Callable[..., Awaitable[Any]]) -> ToolWrapper:
        tool_obj = tool_from_function(
            fn,
            name=name,
            description=description,
            capability=capability,
        )
        wrapper = ToolWrapper(fn, tool_obj)
        update_wrapper(wrapper, fn)
        return wrapper

    if func is not None:
        # Called without parentheses: @tool
        return decorator(func)
    else:
        # Called with parentheses: @tool(...)
        return decorator


def collect_tools(*decorated_functions: ToolWrapper) -> list[Tool]:
    """Collect Tool objects from decorated functions.

    Args:
        *decorated_functions: Functions decorated with @tool

    Returns:
        List of Tool objects

    Example:
        @tool
        async def remember(fact: str) -> dict: ...

        @tool
        async def recall(query: str) -> dict: ...

        tools = collect_tools(remember, recall)
        manager.register_tools(tools)
    """
    return [fn.tool for fn in decorated_functions]


def get_openai_tools(*decorated_functions: ToolWrapper) -> list[dict[str, Any]]:
    """Get OpenAI function calling schemas from decorated functions.

    Args:
        *decorated_functions: Functions decorated with @tool

    Returns:
        List of OpenAI tool schemas

    Example:
        @tool
        async def remember(fact: str) -> dict: ...

        @tool
        async def recall(query: str) -> dict: ...

        tools = get_openai_tools(remember, recall)
        response = client.chat.completions.create(
            model="gpt-4",
            messages=messages,
            tools=tools,
        )
    """
    return [fn.to_openai_schema() for fn in decorated_functions]
