"""Base class for tool providers."""

from abc import ABC, abstractmethod
from typing import Any

from .models import Tool, ToolCapability, ToolDefinition, ToolMetadata


class ToolProvider(ABC):
    """Base class for tool providers.

    Tool providers expose tools that LLMs can call. Each provider can
    expose multiple tools and is responsible for implementing them.

    Example:
        class WeatherProvider(ToolProvider):
            @property
            def provider_name(self) -> str:
                return "weather"

            @property
            def capabilities(self) -> set[ToolCapability]:
                return {ToolCapability.UTILITIES}

            def create_tool_schemas(self) -> list[ToolDefinition]:
                return [
                    ToolDefinition(
                        name="get_weather",
                        description="Get current weather for a location",
                        capability=ToolCapability.UTILITIES,
                        parameters={
                            "type": "object",
                            "properties": {
                                "location": {"type": "string", "description": "City name"}
                            },
                            "required": ["location"],
                        },
                    )
                ]

            async def get_weather(self, location: str) -> dict:
                return {"location": location, "temp": 72, "conditions": "sunny"}
    """

    capabilities: set[ToolCapability] = set()

    @property
    @abstractmethod
    def provider_name(self) -> str:
        """Unique provider name (e.g., 'weather', 'github')."""
        ...

    @abstractmethod
    def create_tool_schemas(self) -> list[ToolDefinition]:
        """Create tool definitions for this provider."""
        ...

    async def __aenter__(self) -> "ToolProvider":
        """Enter async context manager (for setup)."""
        return self

    async def __aexit__(self, *args: Any) -> None:
        """Exit async context manager (for cleanup)."""
        pass

    def _resolve_operation(self, tool_name: str) -> str | None:
        """Map tool name to provider method name.

        Default: returns the tool name itself. Override for custom mapping.
        """
        return tool_name

    def tools(self) -> list[Tool]:
        """Return Tool objects ready for use.

        Builds Tool objects from create_tool_schemas(), wiring each to the
        corresponding method on this provider.
        """
        schemas = self.create_tool_schemas()
        tools: list[Tool] = []

        for schema in schemas:
            meta = ToolMetadata(
                name=schema.name,
                description=schema.description,
                capability=schema.capability,
                provider_name=self.provider_name,
            )

            # Find the method for this tool
            op_name = self._resolve_operation(schema.name)
            method = getattr(self, op_name, None) if op_name else None

            if not callable(method):
                raise RuntimeError(
                    f"Provider {self.__class__.__name__} has no method {op_name!r} "
                    f"for tool {schema.name!r}."
                )

            # Capture method via default arg
            async def _invoke(args: dict[str, Any], _method: Any = method) -> Any:
                return await _method(**(args or {}))

            tools.append(Tool(metadata=meta, definition=schema, invoke=_invoke))

        return tools
