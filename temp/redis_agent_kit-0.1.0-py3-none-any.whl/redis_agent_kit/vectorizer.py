"""Vectorizer wrapper using RedisVL vectorizers.

RedisVL provides vectorizers for OpenAI, Cohere, HuggingFace, Azure, and more.
This module provides a unified interface and a LiteLLM adapter for additional
provider support.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, cast

import litellm
from redisvl.utils.vectorize import (
    BaseVectorizer,
    CustomTextVectorizer,
    OpenAITextVectorizer,
)

if TYPE_CHECKING:
    from redisvl.extensions.llmcache import EmbeddingsCache


class Vectorizer:
    """Wrapper around RedisVL vectorizers with a simplified interface.

    By default uses OpenAI's text-embedding-3-small model. Can be configured
    to use any RedisVL vectorizer or a custom LiteLLM-based vectorizer.

    Examples:
        # Default OpenAI vectorizer
        vectorizer = Vectorizer()

        # Custom model
        vectorizer = Vectorizer(model="text-embedding-ada-002")

        # Use LiteLLM for broader provider support
        vectorizer = Vectorizer.from_litellm(model="cohere/embed-english-v3.0")

        # Use any RedisVL vectorizer directly
        from redisvl.utils.vectorize import CohereTextVectorizer
        vectorizer = Vectorizer(vectorizer=CohereTextVectorizer())
    """

    def __init__(
        self,
        model: str = "text-embedding-3-small",
        vectorizer: BaseVectorizer | None = None,
        api_config: dict[str, Any] | None = None,
        cache: EmbeddingsCache | None = None,
    ):
        """Initialize vectorizer.

        Args:
            model: OpenAI embedding model name (ignored if vectorizer provided).
            vectorizer: Optional RedisVL vectorizer instance to use directly.
            api_config: Optional API configuration for the vectorizer.
            cache: Optional RedisVL EmbeddingsCache for caching.
        """
        self._model = model
        if vectorizer is not None:
            self._vectorizer = vectorizer
        else:
            self._vectorizer = OpenAITextVectorizer(
                model=model,
                api_config=api_config,
                cache=cache,
            )

    @property
    def model(self) -> str:
        """Get the model name."""
        return self._model

    @classmethod
    def from_litellm(
        cls,
        model: str = "text-embedding-3-small",
        dimensions: int | None = None,
        cache: EmbeddingsCache | None = None,
    ) -> Vectorizer:
        """Create a vectorizer using LiteLLM for broader provider support.

        LiteLLM supports many providers beyond what RedisVL offers natively:
        - OpenAI: text-embedding-3-small, text-embedding-ada-002
        - Cohere: cohere/embed-english-v3.0
        - Azure: azure/text-embedding-ada-002
        - Voyage: voyage/voyage-2
        - And many more...

        Args:
            model: LiteLLM model name.
            dimensions: Output dimensions (if supported by model).
            cache: Optional RedisVL EmbeddingsCache.

        Returns:
            Vectorizer instance using LiteLLM.
        """
        adapter = LiteLLMVectorizerAdapter(model=model, dimensions=dimensions)
        vectorizer = CustomTextVectorizer(
            embed=adapter.embed,
            embed_many=adapter.embed_many,
            aembed=adapter.aembed,
            aembed_many=adapter.aembed_many,
            cache=cache,
        )
        return cls(vectorizer=vectorizer)

    @property
    def dims(self) -> int | None:
        """Get embedding dimensions from underlying vectorizer."""
        if hasattr(self._vectorizer, "dims"):
            return cast(int | None, self._vectorizer.dims)
        return None

    async def embed(self, text: str) -> list[float]:
        """Generate embedding for a single text (async)."""
        return cast(list[float], await self._vectorizer.aembed(text))

    def embed_sync(self, text: str) -> list[float]:
        """Generate embedding for a single text (synchronous)."""
        return cast(list[float], self._vectorizer.embed(text))

    async def embed_many(self, texts: list[str]) -> list[list[float]]:
        """Generate embeddings for multiple texts (async)."""
        if not texts:
            return []
        return cast(list[list[float]], await self._vectorizer.aembed_many(texts))

    def embed_many_sync(self, texts: list[str]) -> list[list[float]]:
        """Generate embeddings for multiple texts (synchronous)."""
        if not texts:
            return []
        return cast(list[list[float]], self._vectorizer.embed_many(texts))


class LiteLLMVectorizerAdapter:
    """Adapter to use LiteLLM with RedisVL's CustomTextVectorizer.

    Provides sync and async embedding methods compatible with RedisVL.
    """

    def __init__(
        self,
        model: str = "text-embedding-3-small",
        dimensions: int | None = None,
        batch_size: int = 100,
    ):
        """Initialize adapter.

        Args:
            model: LiteLLM model name.
            dimensions: Output dimensions (if supported).
            batch_size: Maximum texts per API call.
        """
        self.model = model
        self.dimensions = dimensions
        self.batch_size = batch_size

    def embed(self, text: str) -> list[float]:
        """Embed a single text synchronously."""
        return self.embed_many([text])[0]

    def embed_many(self, texts: list[str]) -> list[list[float]]:
        """Embed multiple texts synchronously."""
        if not texts:
            return []

        kwargs: dict[str, Any] = {"model": self.model, "input": texts}
        if self.dimensions is not None:
            kwargs["dimensions"] = self.dimensions

        response = litellm.embedding(**kwargs)
        return [item["embedding"] for item in response.data]

    async def aembed(self, text: str) -> list[float]:
        """Embed a single text asynchronously."""
        result = await self.aembed_many([text])
        return result[0]

    async def aembed_many(self, texts: list[str]) -> list[list[float]]:
        """Embed multiple texts asynchronously."""
        if not texts:
            return []

        all_embeddings: list[list[float]] = []

        for i in range(0, len(texts), self.batch_size):
            batch = texts[i : i + self.batch_size]

            kwargs: dict[str, Any] = {"model": self.model, "input": batch}
            if self.dimensions is not None:
                kwargs["dimensions"] = self.dimensions

            response = await litellm.aembedding(**kwargs)
            all_embeddings.extend([item["embedding"] for item in response.data])

        return all_embeddings
