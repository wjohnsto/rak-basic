# CLI Reference

The `rak` (Redis Agent Kit) command provides task, pipeline, and worker management.

## Global Options

```bash
rak --redis-url redis://myhost:6379 <command>
```

Or set via environment:
```bash
export REDIS_URL=redis://myhost:6379
rak <command>
```

## Tasks

### List Tasks

```bash
rak tasks list
rak tasks list --status in_progress
rak tasks list --status done --limit 20
```

### Get Task

```bash
rak tasks get <task_id>
```

Output:
```
Task: 01HXYZ...
Status: done
Message: What is Redis?
Result: {"answer": "Redis is..."}
Updates:
  - [info] Searching knowledge base...
  - [tool_call] Found 5 documents
```

### Delete Task

```bash
rak tasks delete <task_id>
```

## Pipelines

### Run Pipeline

```bash
# Basic
rak pipelines run ./docs

# With patterns
rak pipelines run ./docs -p "*.md" -p "*.txt"

# Custom chunking
rak pipelines run ./docs --chunk-size 500 --chunk-overlap 100
```

### Check Status

```bash
rak pipelines status
```

Output:
```
Pipeline Status:
  Chunks: 142
  Index: rak:pipeline:chunks
```

### Clear Data

```bash
rak pipelines clear
```

## Worker

### Start Worker

```bash
# Default settings
rak worker

# Custom concurrency
rak worker --concurrency 8

# Custom queue
rak worker --name my_queue

# Custom Redis
rak worker --redis-url redis://myhost:6379

# Load tasks from module
rak worker --tasks myapp.tasks:task_list
```

### Worker Output

```
Starting worker on queue: my_queue
Concurrency: 4
Redis: redis://localhost:6379

Processing task 01HXYZ...
Task completed: 01HXYZ...
```

## Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `REDIS_URL` | `redis://localhost:6379` | Redis connection |
| `OPENAI_API_KEY` | - | For embeddings |

