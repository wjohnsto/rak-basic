# Middleware

Middleware lets you compose reusable behaviors around task execution. Use it for cross-cutting concerns like logging, error handling, or RAG context injection.

## Overview

Middleware wraps your task handler:

```
Request → Middleware A → Middleware B → Handler → Middleware B → Middleware A → Response
```

## Using Middleware

Pass middleware to `AgentKit`:

```python
from redis_agent_kit import AgentKit, ResultMiddleware, EmitterMiddleware

kit = AgentKit(
    client,
    agent_callable=my_handler,
    middleware=[
        ResultMiddleware(),
        EmitterMiddleware(start_message="Processing..."),
    ],
    redis_url="redis://localhost:6379",
)
```

Middleware executes in order: `ResultMiddleware` wraps `EmitterMiddleware` wraps `my_handler`.

## Built-in Middleware

### ResultMiddleware

Automatically sets task result on success and error on exception:

```python
from redis_agent_kit import ResultMiddleware

ResultMiddleware()  # Sets result/error and updates status
```

### EmitterMiddleware

Emits progress updates at start and end:

```python
from redis_agent_kit import EmitterMiddleware

EmitterMiddleware(
    start_message="Starting...",  # Optional
    end_message="Done",           # Optional
)
```

### RAGMiddleware

Searches the vector store and injects context:

```python
from redis_agent_kit import RAGMiddleware

RAGMiddleware(
    limit=5,           # Number of results
    emit_status=True,  # Emit "Searching..." update
)
```

Your handler receives `ctx.rag_context`:

```python
async def handler(ctx):
    print(ctx.rag_context)  # List of relevant chunks
```

### ThreadMiddleware

Saves assistant response to the conversation thread:

```python
from redis_agent_kit import ThreadMiddleware

ThreadMiddleware(response_key="response")  # Key in result dict
```

## Custom Middleware

Extend `TaskMiddleware`:

```python
from redis_agent_kit import TaskMiddleware, TaskContext

class TimingMiddleware(TaskMiddleware):
    async def __call__(self, ctx: TaskContext, next) -> dict:
        import time
        start = time.time()
        result = await next(ctx)
        elapsed = time.time() - start
        print(f"Task {ctx.task_id} took {elapsed:.2f}s")
        return result
```

## TaskContext

Middleware receives a `TaskContext` with:

| Field | Type | Description |
|-------|------|-------------|
| `task_id` | str | Task ID |
| `thread_id` | str | Thread ID |
| `message` | str | User message |
| `context` | dict | Thread context |
| `emitter` | TaskEmitter | For progress updates |
| `rag_context` | list | Injected by RAGMiddleware |

## Pipeline Middleware

Pipelines have separate middleware:

```python
from redis_agent_kit import PipelineLoggingMiddleware, PipelineTimingMiddleware
from redis_agent_kit.pipelines import PipelineOrchestrator

orchestrator = PipelineOrchestrator(
    config=config,
    base_path=path,
    middleware=[
        PipelineLoggingMiddleware(),
        PipelineTimingMiddleware(),
    ],
)
```

### Built-in Pipeline Middleware

| Middleware | Description |
|------------|-------------|
| `PipelineLoggingMiddleware` | Logs stage start/end |
| `PipelineTimingMiddleware` | Tracks timing in metadata |
| `PipelineValidationMiddleware` | Validates config |

### Custom Pipeline Middleware

```python
from redis_agent_kit import PipelineMiddleware, PipelineContext

class AuditMiddleware(PipelineMiddleware):
    async def __call__(self, ctx: PipelineContext, next) -> dict:
        print(f"Starting {ctx.stage}")
        result = await next(ctx)
        print(f"Finished {ctx.stage}: {result}")
        return result
```

