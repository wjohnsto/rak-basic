# Redis Agent Kit Examples

Progressive examples demonstrating RAK features from simple to complex.

## Prerequisites

```bash
# Install dependencies
uv sync --all-extras

# Set environment variables
export OPENAI_API_KEY=sk-...
export REDIS_URL=redis://localhost:6379

# Start Redis
docker run -d --name redis -p 6379:6379 redis:8
```

## Examples

### 1. Basic LLM Agent (`basic_llm/`)

Minimal agent that responds using an LLM.

```bash
python -m examples.basic_llm.agent serve
curl -X POST http://localhost:8000/chat -H "Content-Type: application/json" \
    -d '{"message": "What is Redis?"}'
```

### 2. RAG Agent (`rag_agent/`)

Agent with document indexing and RAG-based responses.

```bash
python -m examples.rag_agent.agent ingest  # Index docs
python -m examples.rag_agent.agent serve
curl -X POST http://localhost:8000/chat -H "Content-Type: application/json" \
    -d '{"message": "How do I use Redis for caching?"}'
```

### 3. LangGraph RAG (`langgraph_rag/`)

RAG agent using LangGraph for structured workflow.

```bash
python -m examples.langgraph_rag.agent serve
```

### 4. LangGraph Interrupt (`langgraph_interrupt/`)

Human-in-the-loop with LangGraph interrupt + RAK pause/resume.

```bash
python -m examples.langgraph_interrupt.agent serve

# Create task (will pause for dangerous actions)
curl -X POST http://localhost:8000/chat -H "Content-Type: application/json" \
    -d '{"message": "Delete all user data"}'

# Submit confirmation
curl -X POST http://localhost:8000/tasks/{task_id}/input \
    -H "Content-Type: application/json" \
    -d '{"response": {"confirm": true}}'
```

### 5. RAG + Long-Term Memory (`rag_with_memory/`)

Combines knowledge search with conversation memory.

```bash
export RAK_MEMORY__ENABLED=true
python -m examples.rag_with_memory.agent serve

# Agent remembers across conversations
curl -X POST http://localhost:8000/chat -H "Content-Type: application/json" \
    -d '{"message": "My name is Alice", "session_id": "alice-123"}'
```

### 6. Multi-Protocol Agent (`multi_protocol_agent/`)

Agent exposed via REST, A2A, and ACP protocols.

```bash
python -m examples.multi_protocol_agent.agent serve

# REST chat
curl -X POST http://localhost:8000/chat \
    -H "Content-Type: application/json" \
    -d '{"message": "Hello!"}'

# A2A discovery
curl http://localhost:8000/.well-known/agent.json

# ACP discovery
curl http://localhost:8000/agents
```

### 7. Tool Agent (`tool_agent/`)

Agent with LLM-driven tool selection using ToolProvider and ToolManager.

```bash
python -m examples.tool_agent.agent serve

curl -X POST http://localhost:8000/chat -H "Content-Type: application/json" \
    -d '{"message": "What is 25 * 4 plus 15?"}'
```

### 8. Minimal Release Demo (`minimal_release_demo/`)

Tiny UV-based companion app for the `0.1.0` launch with a small browser UI.

```bash
cd examples/minimal_release_demo
uv sync
uv run uvicorn app:app --reload

# In another terminal
uv run rak worker --name minimal_release_demo --tasks app:tasks
```

Open `http://localhost:8000/demo` to exercise:

- background task execution
- live SSE updates
- approval-gated pause/resume
- REST, A2A, and ACP endpoints from one app

### Legacy Examples

- `openai_agent/` - OpenAI Agents SDK with RAK
- `langgraph_agent/` - LangGraph with RAK

## Architecture

All examples use the **middleware pattern** to reduce boilerplate:

```python
from redis_agent_kit import (
    AgentKit, TaskContext,
    EmitterMiddleware, RAGMiddleware, MemoryMiddleware, ResultMiddleware,
)

async def run_agent(ctx: TaskContext) -> dict:
    # ctx.rag_context is injected by RAGMiddleware
    # ctx.emitter is ready for progress updates
    response = await my_llm_call(ctx.message, ctx.rag_context)
    return {"response": response}  # MemoryMiddleware saves, ResultMiddleware sets status

kit = AgentKit(
    client,
    agent_callable=run_agent,
    middleware=[
        ResultMiddleware(),   # Handles result/error status
        EmitterMiddleware(),  # Emits progress updates
        RAGMiddleware(),      # Injects ctx.rag_context
        MemoryMiddleware(),   # Saves response to memory
    ],
)
```

### Flow

```
┌─────────────────────────────────────────────────────────────┐
│                        API Server                           │
│  POST /chat → Create task → Background worker → Response    │
│  GET /tasks/{id} → Check status/result                      │
│  POST /pipelines/full → Ingest documents                    │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                    Middleware Stack                         │
│  ResultMiddleware → EmitterMiddleware → RAGMiddleware →     │
│  ThreadMiddleware → Your Handler                            │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                         Redis                               │
│  • Tasks (status, updates, results)                         │
│  • Threads (conversation history)                           │
│  • Vectors (document embeddings)                            │
└─────────────────────────────────────────────────────────────┘
```

### Built-in Pipeline API

The examples use the bundled pipeline API endpoints:

```bash
# Ingest documents via API (instead of CLI)
curl -X POST http://localhost:8000/pipelines/full \
  -H "Content-Type: application/json" \
  -d '{"base_path": "examples/docs", "sources": [{"name": "docs", "path_pattern": "**/*.md"}]}'
```

## Sample Documents

The `docs/` folder contains sample Markdown documents with YAML frontmatter:

- `redis-basics.md` - Introduction to Redis
- `vector-search.md` - Vector search with Redis
- `caching-patterns.md` - Caching patterns

These are ingested by the pipeline and used for RAG context.
