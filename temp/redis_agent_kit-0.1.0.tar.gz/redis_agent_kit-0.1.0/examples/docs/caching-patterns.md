---
title: Caching Patterns with Redis
category: documentation
doc_type: tutorial
chunk_size: 800
tags:
  - redis
  - caching
  - patterns
---

# Caching Patterns with Redis

Redis excels as a caching layer. Here are the most common patterns for effective caching.

## Cache-Aside Pattern

The application manages the cache directly:

```python
async def get_user(user_id: str) -> User:
    # Try cache first
    cached = await redis.get(f"user:{user_id}")
    if cached:
        return User.parse_raw(cached)
    
    # Miss: fetch from database
    user = await db.get_user(user_id)
    
    # Store in cache with TTL
    await redis.setex(f"user:{user_id}", 3600, user.json())
    return user
```

## Write-Through Pattern

Write to cache and database simultaneously:

```python
async def update_user(user_id: str, data: dict) -> User:
    # Update database
    user = await db.update_user(user_id, data)
    
    # Update cache
    await redis.setex(f"user:{user_id}", 3600, user.json())
    return user
```

## Cache Invalidation

Use Redis pub/sub or keyspace notifications:

```python
# Invalidate on update
async def invalidate_user(user_id: str):
    await redis.delete(f"user:{user_id}")
    await redis.publish("cache:invalidate", f"user:{user_id}")
```

## TTL Strategies

- **Fixed TTL**: Simple, predictable expiration
- **Sliding TTL**: Reset on access for hot data
- **Adaptive TTL**: Adjust based on access patterns

```python
# Sliding window TTL
async def get_with_refresh(key: str, ttl: int = 3600):
    value = await redis.get(key)
    if value:
        await redis.expire(key, ttl)  # Refresh TTL
    return value
```

## Best Practices

1. Always set TTLs to prevent stale data accumulation
2. Use consistent key naming conventions
3. Monitor cache hit rates
4. Consider memory limits with eviction policies

