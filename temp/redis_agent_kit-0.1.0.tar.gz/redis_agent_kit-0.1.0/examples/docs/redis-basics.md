---
title: Redis Basics
category: documentation
doc_type: tutorial
pin: true
tags:
  - redis
  - database
  - fundamentals
---

# Redis Basics

Redis is an open-source, in-memory data structure store that can be used as a database, cache, message broker, and streaming engine.

## Key Features

- **In-Memory Storage**: All data is stored in RAM for ultra-fast access
- **Data Structures**: Supports strings, hashes, lists, sets, sorted sets, streams, and more
- **Persistence**: Optional durability with RDB snapshots and AOF logging
- **Replication**: Master-replica architecture for high availability
- **Clustering**: Horizontal scaling with Redis Cluster

## Basic Commands

### Strings

```bash
SET mykey "Hello"
GET mykey
INCR counter
```

### Hashes

```bash
HSET user:1 name "Alice" age 30
HGET user:1 name
HGETALL user:1
```

### Lists

```bash
LPUSH mylist "world"
LPUSH mylist "hello"
LRANGE mylist 0 -1
```

## Use Cases

1. **Caching**: Store frequently accessed data for fast retrieval
2. **Session Storage**: Manage user sessions with automatic expiration
3. **Real-time Analytics**: Use sorted sets for leaderboards and time-series data
4. **Message Queues**: Implement pub/sub or stream-based messaging
5. **Rate Limiting**: Track API usage with atomic counters

## Getting Started

Install Redis locally or use Redis Cloud for a managed experience:

```bash
# Start Redis locally
redis-server

# Connect with redis-cli
redis-cli ping
# Returns: PONG
```

