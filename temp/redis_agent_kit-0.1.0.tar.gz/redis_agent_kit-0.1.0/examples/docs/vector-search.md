---
title: Vector Search with Redis
category: documentation
doc_type: reference
tags:
  - redis
  - vector-search
  - embeddings
  - ai
---

# Vector Search with Redis

Redis provides native vector similarity search capabilities through the RediSearch module, enabling semantic search, recommendation systems, and AI-powered applications.

## Overview

Vector search allows you to find similar items based on their vector embeddings rather than exact matches. This is essential for:

- Semantic text search
- Image similarity
- Recommendation engines
- RAG (Retrieval Augmented Generation) applications

## Creating a Vector Index

```python
from redis import Redis
from redis.commands.search.field import VectorField, TextField, TagField
from redis.commands.search.indexDefinition import IndexDefinition, IndexType

r = Redis()

# Define schema with vector field
schema = (
    TextField("content"),
    TagField("category"),
    VectorField("embedding",
        "FLAT", {
            "TYPE": "FLOAT32",
            "DIM": 1536,
            "DISTANCE_METRIC": "COSINE"
        }
    )
)

# Create index
r.ft("docs").create_index(
    schema,
    definition=IndexDefinition(prefix=["doc:"], index_type=IndexType.HASH)
)
```

## Storing Vectors

```python
import numpy as np

# Store document with embedding
embedding = np.random.rand(1536).astype(np.float32)
r.hset("doc:1", mapping={
    "content": "Redis is an in-memory database",
    "category": "database",
    "embedding": embedding.tobytes()
})
```

## Querying Vectors

```python
from redis.commands.search.query import Query

# Create query vector
query_embedding = get_embedding("What is Redis?")

# KNN search
q = Query("*=>[KNN 5 @embedding $vec AS score]") \
    .return_fields("content", "score") \
    .sort_by("score") \
    .dialect(2)

results = r.ft("docs").search(q, {"vec": query_embedding.tobytes()})
```

## Best Practices

1. **Choose the right algorithm**: FLAT for small datasets, HNSW for large
2. **Normalize embeddings**: Use unit vectors for cosine similarity
3. **Set appropriate dimensions**: Match your embedding model (e.g., 1536 for OpenAI)
4. **Use hybrid search**: Combine vector and full-text search for better results

