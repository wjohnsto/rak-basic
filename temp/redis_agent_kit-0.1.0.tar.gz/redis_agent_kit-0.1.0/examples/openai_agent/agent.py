"""OpenAI Agents SDK example with Redis Agent Kit.

This example demonstrates:
1. Creating an agent that uses RAK middleware for task/thread management
2. Using the pipeline API to ingest Markdown documents
3. Running the agent as a background task via the API

Usage:
    # Set up environment
    export OPENAI_API_KEY=sk-...

    # Install dependencies
    pip install redis-agent-kit[examples]

    # Ingest documents via the API (or use the CLI)
    curl -X POST http://localhost:8000/pipelines/full \
        -H "Content-Type: application/json" \
        -d '{"base_path": "examples/docs", "sources": [{"name": "docs", "path_pattern": "**/*.md"}]}'

    # Start the API server
    python -m examples.openai_agent.agent serve

    # In another terminal, create a task
    curl -X POST http://localhost:8000/chat -H "Content-Type: application/json" \
        -d '{"message": "What is Redis?"}'
"""

import asyncio
import sys
from pathlib import Path
from typing import Any

import redis.asyncio as redis_lib
import uvicorn
from agents import Agent, Runner
from dotenv import load_dotenv
from fastapi import Request
from pydantic import BaseModel

from redis_agent_kit import (
    AgentKit,
    EmitterMiddleware,
    RAGMiddleware,
)
from redis_agent_kit.api import create_app
from redis_agent_kit.pipelines import (
    PipelineConfig,
    PipelineOrchestrator,
    SourceConfig,
)

# Load .env from project root
load_dotenv(Path(__file__).parent.parent.parent / ".env")


async def run_agent(ctx) -> dict[str, Any]:
    """Run the OpenAI agent for a task.

    This is the task handler that gets called by the background worker.
    Middleware handles: emitter updates, RAG context, thread messages, result/error.

    Args:
        ctx: TaskContext with task_id, thread_id, message, rag_context, emitter, etc.
    """
    # Build agent with RAG context (injected by RAGMiddleware)
    system_prompt = """You are a helpful Redis expert assistant.
Use the following context from the knowledge base to answer questions:

{context}

If the context doesn't contain relevant information, use your general knowledge
but mention that the information isn't from the knowledge base.""".format(
        context=ctx.rag_context if ctx.rag_context else "No relevant context found."
    )

    agent = Agent(
        name="Redis Expert",
        instructions=system_prompt,
        model="gpt-4o-mini",
    )

    await ctx.emitter.emit("Generating response...")

    # Run the agent
    result = Runner.run_sync(agent, ctx.message)
    response = result.final_output

    return {"response": response, "sources": ctx.metadata.get("rag_result_count", 0)}


async def ingest_documents():
    """Ingest example documents into the vector store."""
    docs_path = Path(__file__).parent.parent / "docs"

    print(f"Ingesting documents from {docs_path}...")

    config = PipelineConfig(
        sources=[
            SourceConfig(
                name="docs",
                path_pattern="**/*.md",
                chunk_size=800,
                chunk_overlap=200,
            )
        ],
        artifacts_dir=Path("artifacts"),
    )

    client = redis_lib.from_url("redis://localhost:6379")
    orchestrator = PipelineOrchestrator(config=config, base_path=docs_path, redis_client=client)

    # Run prepare stage
    print("Running prepare stage...")
    batch_id = await orchestrator.prepare()
    print(f"Prepared batch: {batch_id}")

    # Run ingest stage
    print("Running ingest stage...")
    await orchestrator.ingest(batch_id)
    print("Ingestion complete!")


def _create_kit():
    """Create AgentKit for worker and server."""
    return AgentKit(
        agent_callable=run_agent,
        middleware=[
            EmitterMiddleware(start_message="Starting agent..."),
            RAGMiddleware(limit=3),
        ],
        queue_name="openai_agent",
    )


def serve():
    """Start the API server with the agent."""

    class ChatRequest(BaseModel):
        message: str
        thread_id: str | None = None

    kit = _create_kit()
    app = create_app(kit=kit)

    @app.post("/chat")
    async def chat(request: Request, body: ChatRequest):
        """Create a new chat task."""
        return await kit.create_and_submit_task(message=body.message, thread_id=body.thread_id)

    print("Starting server on http://localhost:8000")
    print("Endpoints:")
    print("  POST /chat - Create a chat task")
    print("  GET /tasks - List all tasks")
    print("  GET /tasks/{task_id} - Get task status")
    uvicorn.run(app, host="0.0.0.0", port=8000)


def main():
    """Main entry point."""
    if len(sys.argv) < 2:
        print("Usage: python -m examples.openai_agent.agent [ingest|serve]")
        sys.exit(1)

    command = sys.argv[1]

    if command == "ingest":
        asyncio.run(ingest_documents())
    elif command == "serve":
        serve()
    else:
        print(f"Unknown command: {command}")
        print("Usage: python -m examples.openai_agent.agent [ingest|serve]")
        sys.exit(1)


if __name__ == "__main__":
    main()
