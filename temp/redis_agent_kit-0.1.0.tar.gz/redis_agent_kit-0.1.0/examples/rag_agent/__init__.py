"""RAG agent example with document indexing."""

