"""Example 2: RAG Agent with Document Indexing.

An agent that indexes documents and responds using RAG + LLM. Demonstrates:
- Document ingestion pipeline
- RAGMiddleware for context injection
- Vector search with Redis

Usage:
    export OPENAI_API_KEY=sk-...
    python -m examples.rag_agent.agent ingest   # Index documents
    python -m examples.rag_agent.agent serve    # Start server

    # In another terminal, start the worker:
    rak worker --name rag_agent --tasks examples.rag_agent.agent:tasks

    # Then send a request:
    curl -X POST http://localhost:8000/chat -H "Content-Type: application/json" \
        -d '{"message": "How do I use Redis for caching?"}'
"""

import asyncio
import sys
from pathlib import Path
from typing import Any

import redis.asyncio as redis_lib
import uvicorn
from dotenv import load_dotenv
from fastapi import Request
from openai import AsyncOpenAI
from pydantic import BaseModel

from redis_agent_kit import AgentKit, EmitterMiddleware, RAGMiddleware
from redis_agent_kit.api import create_app
from redis_agent_kit.pipelines import (
    PipelineConfig,
    PipelineOrchestrator,
    SourceConfig,
    VectorStore,
)
from redis_agent_kit.vectorizer import Vectorizer

load_dotenv(Path(__file__).parent.parent.parent / ".env")

DOCS_PATH = Path(__file__).parent.parent / "docs"


async def run_agent(ctx) -> dict[str, Any]:
    """RAG agent handler with context injection.

    Args:
        ctx: TaskContext with rag_context injected by RAGMiddleware
    """
    client = AsyncOpenAI()

    await ctx.emitter.emit("Generating response...")

    response = await client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[
            {
                "role": "system",
                "content": f"""You are a helpful assistant with access to a knowledge base.
Use the following context to answer questions:

{ctx.rag_context}

If the context doesn't contain relevant information, say so.""",
            },
            {"role": "user", "content": ctx.message},
        ],
    )

    return {"response": response.choices[0].message.content}


def _create_kit():
    """Create AgentKit for worker and server."""
    return AgentKit(
        agent_callable=run_agent,
        middleware=[
            EmitterMiddleware(start_message="Processing..."),
            RAGMiddleware(),
        ],
        queue_name="rag_agent",
    )


_kit = _create_kit()
tasks = [_kit.worker_task]


async def ingest_documents():
    """Ingest documents from the docs folder."""
    config = PipelineConfig(
        sources=[
            SourceConfig(name="docs", path_pattern="**/*.md"),
        ],
    )

    client = redis_lib.from_url("redis://localhost:6379")
    vectorizer = Vectorizer()
    vector_store = VectorStore(client)

    orchestrator = PipelineOrchestrator(
        config=config,
        base_path=DOCS_PATH,
        vectorizer=vectorizer,
        vector_store=vector_store,
    )

    print(f"Ingesting documents from {DOCS_PATH}...")
    batch_id = await orchestrator.prepare_async()
    print(f"Prepared batch: {batch_id}")

    manifest = await orchestrator.ingest_async(batch_id)
    print(f"Ingested {manifest.chunks_embedded} chunks")


def serve():
    """Start the API server."""

    class ChatRequest(BaseModel):
        message: str
        session_id: str | None = None

    kit = _create_kit()
    app = create_app(kit=kit)

    @app.post("/chat")
    async def chat(request: Request, body: ChatRequest):
        return await kit.create_and_submit_task(
            message=body.message, session_id=body.session_id
        )

    print("Starting server on http://localhost:8000")
    uvicorn.run(app, host="0.0.0.0", port=8000)


def main():
    if len(sys.argv) < 2:
        print("Usage: python -m examples.rag_agent.agent [ingest|serve]")
        sys.exit(1)

    if sys.argv[1] == "ingest":
        asyncio.run(ingest_documents())
    elif sys.argv[1] == "serve":
        serve()
    else:
        print(f"Unknown command: {sys.argv[1]}")
        sys.exit(1)


if __name__ == "__main__":
    main()

