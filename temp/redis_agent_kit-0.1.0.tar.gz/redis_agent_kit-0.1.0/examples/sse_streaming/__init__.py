"""SSE streaming agent example."""

