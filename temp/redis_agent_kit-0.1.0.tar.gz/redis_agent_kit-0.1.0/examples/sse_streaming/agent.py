"""Example: SSE Streaming Agent with Redis Agent Kit.

An agent that streams real-time updates to clients via Server-Sent Events (SSE).
Uses Redis Pub/Sub under the hood so multiple API servers can fan out updates.

Demonstrates:
- Using ``StreamConfig`` to configure streaming behaviour
- Emitting incremental progress updates that stream to the client
- Consuming the ``/tasks/{task_id}/stream`` SSE endpoint
- Optional session-scoped streaming via ``/sessions/{session_id}/stream``
- Event filtering via ``?events=token,done``

Usage:
    export OPENAI_API_KEY=sk-...
    python -m examples.sse_streaming.agent serve

    # In another terminal, start the worker:
    rak worker --name sse_streaming --tasks examples.sse_streaming.agent:tasks

    # Create a task and stream updates:
    TASK_ID=$(curl -s -X POST http://localhost:8000/chat \
        -H "Content-Type: application/json" \
        -d '{"message": "Tell me about Redis Streams"}' | python -c "import sys,json; print(json.load(sys.stdin)['task_id'])")

    # Stream all events:
    curl -N http://localhost:8000/tasks/$TASK_ID/stream

    # Stream only tokens and terminal events:
    curl -N 'http://localhost:8000/tasks/$TASK_ID/stream?events=token,done,failed'

JavaScript client example:
    const es = new EventSource(`/tasks/${taskId}/stream`);
    es.addEventListener('update', (e) => {
        const data = JSON.parse(e.data);
        console.log(data.message);          // milestone progress (persisted)
    });
    es.addEventListener('token', (e) => {
        const data = JSON.parse(e.data);
        process.stdout.write(data.message); // individual LLM token (ephemeral)
    });
    es.addEventListener('done', (e) => {
        const data = JSON.parse(e.data);
        console.log(data.result.response);  // final answer
        es.close();
    });
"""

import sys
from pathlib import Path
from typing import Any

import uvicorn
from dotenv import load_dotenv
from fastapi import Request
from openai import AsyncOpenAI
from pydantic import BaseModel

from redis_agent_kit import AgentKit, ChannelScope, EmitterMiddleware, StreamConfig
from redis_agent_kit.api import create_app

load_dotenv(Path(__file__).parent.parent.parent / ".env")


async def run_agent(ctx) -> dict[str, Any]:
    """Streaming-friendly agent handler.

    Emits token-level updates so the SSE endpoint can push them to
    connected clients in real time.

    Args:
        ctx: TaskContext with task_id, session_id, message, emitter, memory
    """
    client = AsyncOpenAI()

    await ctx.emitter.emit("Thinking...")

    stream = await client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": ctx.message},
        ],
        stream=True,
    )

    chunks: list[str] = []
    async for event in stream:
        delta = event.choices[0].delta.content
        if delta:
            chunks.append(delta)
            # emit_token() publishes directly to Redis Pub/Sub without
            # persisting each token to the task state — lightweight and fast.
            await ctx.emitter.emit_token(delta)

    return {"response": "".join(chunks)}


# StreamConfig controls which channels events fan out to and which
# event types are published.  See the StreamConfig docstring for all options.
STREAM_CONFIG = StreamConfig(
    enabled=True,
    channels={ChannelScope.TASK, ChannelScope.SESSION},
)


def _create_kit():
    """Create AgentKit with streaming enabled via StreamConfig."""
    return AgentKit(
        agent_callable=run_agent,
        middleware=[EmitterMiddleware(start_message="Processing...")],
        queue_name="sse_streaming",
        stream_config=STREAM_CONFIG,
    )


# Task collection for Docket worker
_kit = _create_kit()
tasks = [_kit.worker_task]


def serve():
    """Start the API server with SSE streaming enabled."""

    class ChatRequest(BaseModel):
        message: str
        session_id: str | None = None

    kit = _create_kit()
    app = create_app(kit=kit, stream_config=STREAM_CONFIG)

    @app.post("/chat")
    async def chat(request: Request, body: ChatRequest):
        """Create a chat task and return its ID for streaming."""
        result = await kit.create_and_submit_task(
            message=body.message, session_id=body.session_id
        )
        return result

    print("Starting SSE streaming server on http://localhost:8000")
    print("POST /chat                          - Create a task")
    print("GET  /tasks/{task_id}                - Check task status")
    print("GET  /tasks/{task_id}/stream         - Stream updates via SSE")
    print("GET  /sessions/{session_id}/stream   - Stream all tasks in a session")
    print("GET  /stream/global                  - Stream all events globally")
    uvicorn.run(app, host="0.0.0.0", port=8000)


def main():
    if len(sys.argv) < 2:
        print("Usage: python -m examples.sse_streaming.agent serve")
        sys.exit(1)

    if sys.argv[1] == "serve":
        serve()
    else:
        print(f"Unknown command: {sys.argv[1]}")
        sys.exit(1)


if __name__ == "__main__":
    main()
