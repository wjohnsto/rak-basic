"""Example: Tool-Calling Agent with Multiple Tools.

An agent that uses OpenAI function calling to select and execute tools
in a loop until the task is complete.

Demonstrates:
- @tool decorator for automatic schema generation
- get_openai_tools() and collect_tools() helpers
- LLM-driven tool selection loop
- RAK middleware integration

Usage:
    export OPENAI_API_KEY=sk-...
    python -m examples.tool_agent.agent serve

    curl -X POST http://localhost:8000/chat -H "Content-Type: application/json" \
        -d '{"message": "What is 25 * 4 plus 15?"}'
"""

import json
import math
import sys
from datetime import datetime
from pathlib import Path
from typing import Any

import uvicorn
from dotenv import load_dotenv
from fastapi import Request
from openai import AsyncOpenAI
from pydantic import BaseModel

from redis_agent_kit import AgentKit, EmitterMiddleware, RAGMiddleware
from redis_agent_kit.api import create_app
from redis_agent_kit.tools import collect_tools, get_openai_tools, tool

load_dotenv(Path(__file__).parent.parent.parent / ".env")


# Define tools using the @tool decorator - schemas are auto-generated
@tool
async def calculate(expression: str) -> str:
    """Perform a mathematical calculation.

    Args:
        expression: Math expression, e.g. '2 + 2' or 'sqrt(16)'
    """
    allowed = {k: v for k, v in math.__dict__.items() if not k.startswith("_")}
    allowed.update({"abs": abs, "round": round, "min": min, "max": max})
    try:
        result = eval(expression, {"__builtins__": {}}, allowed)
        return f"Result: {result}"
    except Exception as e:
        return f"Error: {e}"


@tool
async def get_current_time() -> str:
    """Get the current date and time."""
    return f"Current time: {datetime.now().isoformat()}"


# Collect all tools for easy lookup
TOOLS = collect_tools(calculate, get_current_time)


def create_search_tool(ctx):
    """Create a search tool bound to the current context."""

    @tool
    async def search_knowledge(query: str) -> str:
        """Search the knowledge base for information.

        Args:
            query: Search query
        """
        if ctx and ctx.rag_context:
            return f"Found: {ctx.rag_context[:500]}"
        return "Knowledge base not configured or no results found."

    return search_knowledge


async def run_agent(ctx) -> dict[str, Any]:
    """Tool-calling agent with execution loop."""
    client = AsyncOpenAI()

    # Create context-bound search tool and combine with static tools
    search_tool = create_search_tool(ctx)
    all_tools = [calculate, get_current_time, search_tool]
    openai_tools = get_openai_tools(*all_tools)
    tool_map = {t.name: t for t in collect_tools(*all_tools).values()}

    messages = [
        {"role": "system", "content": "You are a helpful assistant with access to tools."},
        {"role": "user", "content": ctx.message},
    ]

    for i in range(10):
        await ctx.emitter.emit(f"Thinking... (step {i + 1})")

        response = await client.chat.completions.create(
            model="gpt-4o-mini",
            messages=messages,
            tools=openai_tools,
            tool_choice="auto",
        )

        choice = response.choices[0]

        if not choice.message.tool_calls:
            return {"response": choice.message.content}

        messages.append(choice.message)

        for tool_call in choice.message.tool_calls:
            name = tool_call.function.name
            args = json.loads(tool_call.function.arguments)

            await ctx.emitter.emit(f"Calling {name}...")
            result = await tool_map[name].invoke(args)

            messages.append({
                "role": "tool",
                "tool_call_id": tool_call.id,
                "content": str(result),
            })

    return {"response": "Max iterations reached"}


def _create_kit():
    """Create AgentKit for worker and server."""
    return AgentKit(
        agent_callable=run_agent,
        middleware=[EmitterMiddleware(), RAGMiddleware(limit=3, emit_status=False)],
        queue_name="tool_agent",
    )


_kit = _create_kit()
tasks = [_kit.worker_task]


def serve():
    """Start the API server."""

    class ChatRequest(BaseModel):
        message: str
        session_id: str | None = None

    kit = _create_kit()
    app = create_app(kit=kit)

    @app.post("/chat")
    async def chat(request: Request, body: ChatRequest):
        return await kit.create_and_submit_task(
            message=body.message, session_id=body.session_id
        )

    print("Starting Tool Agent server on http://localhost:8000")
    uvicorn.run(app, host="0.0.0.0", port=8000)


def main():
    if len(sys.argv) < 2:
        print("Usage: python -m examples.tool_agent.agent serve")
        sys.exit(1)

    if sys.argv[1] == "serve":
        serve()


if __name__ == "__main__":
    main()
