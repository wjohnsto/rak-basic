"""Tests for Redis Agent Kit."""
