"""Tests for API authentication."""

from unittest.mock import AsyncMock

import pytest
from httpx import ASGITransport, AsyncClient


class TestAPIKeyAuthentication:
    """Tests for API key authentication."""

    @pytest.mark.asyncio
    async def test_no_auth_when_no_keys_configured(self):
        """Endpoints should be accessible without auth when no keys configured."""
        from redis_agent_kit.api.app import create_app

        mock_kit = AsyncMock()
        mock_kit.create_and_submit_task.return_value = {
            "task_id": "task123",
            "session_id": "thread456",
            "status": "queued",
        }

        app = create_app(kit=mock_kit)  # No api_keys
        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            response = await client.post("/tasks", json={"message": "Hello"})
            assert response.status_code == 200

    @pytest.mark.asyncio
    async def test_auth_required_when_keys_configured(self):
        """Endpoints should require auth when api_keys configured."""
        from redis_agent_kit.api.app import create_app

        mock_kit = AsyncMock()
        app = create_app(kit=mock_kit, api_keys=["secret-key-123"])

        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            # No auth header - should fail
            response = await client.post("/tasks", json={"message": "Hello"})
            assert response.status_code == 401
            assert "Invalid or missing API key" in response.json()["detail"]

    @pytest.mark.asyncio
    async def test_x_api_key_header_auth(self):
        """X-API-Key header should authenticate requests."""
        from redis_agent_kit.api.app import create_app

        mock_kit = AsyncMock()
        mock_kit.create_and_submit_task.return_value = {
            "task_id": "task123",
            "session_id": "thread456",
            "status": "queued",
        }

        app = create_app(kit=mock_kit, api_keys=["secret-key-123"])

        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            response = await client.post(
                "/tasks",
                json={"message": "Hello"},
                headers={"X-API-Key": "secret-key-123"},
            )
            assert response.status_code == 200

    @pytest.mark.asyncio
    async def test_bearer_token_auth(self):
        """Authorization: Bearer token should authenticate requests."""
        from redis_agent_kit.api.app import create_app

        mock_kit = AsyncMock()
        mock_kit.create_and_submit_task.return_value = {
            "task_id": "task123",
            "session_id": "thread456",
            "status": "queued",
        }

        app = create_app(kit=mock_kit, api_keys=["secret-key-123"])

        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            response = await client.post(
                "/tasks",
                json={"message": "Hello"},
                headers={"Authorization": "Bearer secret-key-123"},
            )
            assert response.status_code == 200

    @pytest.mark.asyncio
    async def test_invalid_api_key_rejected(self):
        """Invalid API key should be rejected."""
        from redis_agent_kit.api.app import create_app

        mock_kit = AsyncMock()
        app = create_app(kit=mock_kit, api_keys=["secret-key-123"])

        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            response = await client.post(
                "/tasks",
                json={"message": "Hello"},
                headers={"X-API-Key": "wrong-key"},
            )
            assert response.status_code == 401

    @pytest.mark.asyncio
    async def test_multiple_valid_keys(self):
        """Multiple API keys should all be valid."""
        from redis_agent_kit.api.app import create_app

        mock_kit = AsyncMock()
        mock_kit.create_and_submit_task.return_value = {
            "task_id": "task123",
            "session_id": "thread456",
            "status": "queued",
        }

        app = create_app(kit=mock_kit, api_keys=["key1", "key2", "key3"])

        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            # All keys should work
            for key in ["key1", "key2", "key3"]:
                response = await client.post(
                    "/tasks",
                    json={"message": "Hello"},
                    headers={"X-API-Key": key},
                )
                assert response.status_code == 200

    @pytest.mark.asyncio
    async def test_public_endpoints_no_auth(self):
        """Public endpoints (/, /health) should not require auth."""
        from redis_agent_kit.api.app import create_app

        app = create_app(api_keys=["secret-key-123"])

        async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
            # Root endpoint
            response = await client.get("/")
            assert response.status_code == 200

            # Health endpoint
            response = await client.get("/health")
            assert response.status_code == 200
