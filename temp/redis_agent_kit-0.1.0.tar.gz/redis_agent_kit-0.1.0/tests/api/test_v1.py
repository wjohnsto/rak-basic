"""Tests for unified v1 API endpoints."""

from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from httpx import ASGITransport, AsyncClient


@pytest.mark.asyncio
async def test_v1_healthz() -> None:
    from redis_agent_kit.api.app import create_app

    app = create_app()
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
        response = await client.get("/v1/healthz")
    assert response.status_code == 200
    payload = response.json()
    assert payload["ok"] is True
    assert payload["data"]["status"] == "healthy"


@pytest.mark.asyncio
async def test_v1_capabilities() -> None:
    from redis_agent_kit.api.app import create_app

    app = create_app(
        enable_a2a=True,
        enable_acp=True,
        kit=MagicMock(),
        agent_card=MagicMock(),
        agent_manifest=MagicMock(),
    )
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
        response = await client.get("/v1/capabilities")
    assert response.status_code == 200
    payload = response.json()["data"]
    assert payload["serverType"] == "rak_oss"
    assert "rest" in payload["protocols"]
    assert payload["features"]["deploy.up"] is False


@pytest.mark.asyncio
async def test_v1_agent_list() -> None:
    from redis_agent_kit.api.app import create_app

    app = create_app()
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
        response = await client.get("/v1/projects/p1/agents")
    assert response.status_code == 200
    agents = response.json()["data"]["agents"]
    assert len(agents) == 1
    assert agents[0]["agentId"] == "default"


@pytest.mark.asyncio
async def test_v1_task_list() -> None:
    from redis_agent_kit.api.app import create_app
    from redis_agent_kit.models import TaskState, TaskStatus

    app = create_app()
    mock_manager = AsyncMock()
    mock_manager.list_tasks.return_value = [
        TaskState(task_id="t1", session_id="s1", status=TaskStatus.QUEUED)
    ]
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
        with patch("redis_agent_kit.api.v1._task_manager", return_value=mock_manager):
            response = await client.get("/v1/projects/p1/agents/default/tasks")
    assert response.status_code == 200
    tasks = response.json()["data"]["tasks"]
    assert tasks[0]["taskId"] == "t1"


@pytest.mark.asyncio
async def test_v1_task_create() -> None:
    from redis_agent_kit.api.app import create_app

    mock_kit = AsyncMock()
    mock_kit.create_and_submit_task.return_value = {
        "task_id": "t1",
        "session_id": "s1",
        "status": "queued",
        "message": "queued",
    }
    app = create_app(kit=mock_kit)
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
        response = await client.post(
            "/v1/projects/p1/agents/default/tasks",
            json={"request": {"protocol": "rest", "input": {"message": "hello"}}},
        )
    assert response.status_code == 200
    data = response.json()["data"]
    assert data["taskId"] == "t1"
    mock_kit.create_and_submit_task.assert_called_once()


@pytest.mark.asyncio
async def test_v1_up_runtime_only() -> None:
    from redis_agent_kit.api.app import create_app

    app = create_app()
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as client:
        response = await client.post("/v1/projects/p1/agents/default/up", json={})
    assert response.status_code == 501
    detail = response.json()["detail"]
    assert detail["error"]["code"] == "runtime_only_feature"
