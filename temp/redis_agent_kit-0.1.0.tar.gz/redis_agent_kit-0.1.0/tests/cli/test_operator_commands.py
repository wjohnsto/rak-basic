"""Tests for health/agent/up commands."""

from unittest.mock import patch

from click.testing import CliRunner


def test_health_command_calls_v1_healthz() -> None:
    from redis_agent_kit.cli.main import cli

    runner = CliRunner()
    with patch("redis_agent_kit.cli.health.call_api") as call_api:
        call_api.return_value = {"ok": True, "data": {"status": "healthy"}}
        result = runner.invoke(cli, ["--api-base", "http://localhost:8000", "health"])
    assert result.exit_code == 0
    kwargs = call_api.call_args.kwargs
    assert kwargs["path"] == "/v1/healthz"


def test_agent_list_calls_v1_agents() -> None:
    from redis_agent_kit.cli.main import cli

    runner = CliRunner()
    with patch("redis_agent_kit.cli.agent.call_api") as call_api:
        call_api.return_value = {"ok": True, "data": {"agents": []}}
        result = runner.invoke(
            cli,
            ["--api-base", "http://localhost:8000", "--project", "p1", "agent", "list"],
        )
    assert result.exit_code == 0
    kwargs = call_api.call_args.kwargs
    assert kwargs["path"] == "/v1/projects/p1/agents"


def test_up_calls_runtime_endpoint() -> None:
    from redis_agent_kit.cli.main import cli

    runner = CliRunner()
    with patch("redis_agent_kit.cli.up.call_api") as call_api:
        call_api.return_value = {"ok": True, "data": {"taskId": "up1"}}
        result = runner.invoke(
            cli,
            [
                "--api-base",
                "http://localhost:8000",
                "--project",
                "p1",
                "--agent",
                "a1",
                "up",
                "--entrypoint",
                "agent.py:main",
            ],
        )
    assert result.exit_code == 0
    kwargs = call_api.call_args.kwargs
    assert kwargs["path"] == "/v1/projects/p1/agents/a1/up"
