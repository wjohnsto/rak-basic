"""TDD tests for CLI pipeline commands - written BEFORE implementation."""

import tempfile
from pathlib import Path
from unittest.mock import AsyncMock, patch

from click.testing import CliRunner


class TestPipelinesRun:
    """Tests for 'rak pipelines run' command."""

    def test_pipelines_run_exists(self):
        """Pipelines run command should exist."""
        from redis_agent_kit.cli.main import cli

        runner = CliRunner()
        result = runner.invoke(cli, ["pipelines", "run", "--help"])
        assert result.exit_code == 0
        assert "Run a pipeline" in result.output

    def test_pipelines_run_requires_source(self):
        """Pipelines run should require source path."""
        from redis_agent_kit.cli.main import cli

        runner = CliRunner()
        result = runner.invoke(cli, ["pipelines", "run"])
        # Should fail without source
        assert result.exit_code != 0

    def test_pipelines_run_with_directory(self):
        """Pipelines run should accept directory path."""
        from redis_agent_kit.cli.main import cli

        runner = CliRunner()
        with (
            tempfile.TemporaryDirectory() as tmpdir,
            patch("redis_agent_kit.cli.pipelines.run_pipeline") as mock_run,
        ):
            mock_run.return_value = {
                "status": "completed",
                "documents_processed": 5,
                "chunks_created": 20,
            }
            result = runner.invoke(cli, ["pipelines", "run", tmpdir])
            # May fail for other reasons, but command should parse
            assert "--help" not in result.output or result.exit_code == 0

    def test_pipelines_run_with_patterns(self):
        """Pipelines run should accept file patterns."""
        from redis_agent_kit.cli.main import cli

        runner = CliRunner()
        result = runner.invoke(cli, ["pipelines", "run", "--help"])
        assert "--pattern" in result.output or "-p" in result.output

    def test_pipelines_run_with_chunk_size(self):
        """Pipelines run should accept chunk size option."""
        from redis_agent_kit.cli.main import cli

        runner = CliRunner()
        result = runner.invoke(cli, ["pipelines", "run", "--help"])
        assert "--chunk-size" in result.output


class TestPipelinesStatus:
    """Tests for 'rak pipelines status' command."""

    def test_pipelines_status_exists(self):
        """Pipelines status command should exist."""
        from redis_agent_kit.cli.main import cli

        runner = CliRunner()
        result = runner.invoke(cli, ["pipelines", "status", "--help"])
        assert result.exit_code == 0
        assert "Show pipeline status" in result.output


class TestPipelinesClear:
    """Tests for 'rak pipelines clear' command."""

    def test_pipelines_clear_exists(self):
        """Pipelines clear command should exist."""
        from redis_agent_kit.cli.main import cli

        runner = CliRunner()
        result = runner.invoke(cli, ["pipelines", "clear", "--help"])
        assert result.exit_code == 0
        assert "Clear" in result.output

    def test_pipelines_clear_requires_confirmation(self):
        """Pipelines clear should require --yes flag."""
        from redis_agent_kit.cli.main import cli

        runner = CliRunner()
        with patch("redis_agent_kit.cli.pipelines.get_vector_store") as mock_get_vs:
            mock_vs = AsyncMock()
            mock_get_vs.return_value = mock_vs

            # Without --yes, should prompt
            result = runner.invoke(cli, ["pipelines", "clear"], input="n\n")
            assert "Cancelled" in result.output or result.exit_code == 0

    def test_pipelines_clear_with_yes(self):
        """Pipelines clear should clear data with --yes flag."""
        from redis_agent_kit.cli.main import cli

        runner = CliRunner()
        with patch("redis_agent_kit.cli.pipelines.get_vector_store") as mock_get_vs:
            mock_vs = AsyncMock()
            mock_vs.clear_all.return_value = None
            mock_get_vs.return_value = mock_vs

            result = runner.invoke(cli, ["pipelines", "clear", "--yes"])
            assert result.exit_code == 0
            assert "cleared" in result.output.lower()


class TestPipelinesStatusExecution:
    """Tests for pipelines status command execution."""

    def test_pipelines_status_shows_count(self):
        """Pipelines status should show chunk count."""
        from redis_agent_kit.cli.main import cli

        runner = CliRunner()
        with patch("redis_agent_kit.cli.pipelines.get_vector_store") as mock_get_vs:
            mock_vs = AsyncMock()
            mock_vs.count.return_value = 100
            mock_get_vs.return_value = mock_vs

            result = runner.invoke(cli, ["pipelines", "status"])
            assert result.exit_code == 0
            assert "100" in result.output


class TestPipelinesRunExecution:
    """Tests for pipelines run command execution."""

    def test_pipelines_run_processes_files(self):
        """Pipelines run should process files in directory."""
        from redis_agent_kit.cli.main import cli

        runner = CliRunner()
        with tempfile.TemporaryDirectory() as tmpdir:
            # Create a test file
            test_file = Path(tmpdir) / "test.txt"
            test_file.write_text("Test content for processing")

            with patch("redis_agent_kit.cli.pipelines.run_pipeline") as mock_run:
                mock_run.return_value = {
                    "status": "completed",
                    "documents_processed": 1,
                    "chunks_created": 1,
                }
                result = runner.invoke(cli, ["pipelines", "run", tmpdir])
                assert result.exit_code == 0 or "completed" in result.output.lower()


class TestGetVectorStore:
    """Tests for get_vector_store helper."""

    def test_get_vector_store_creates_store(self):
        """get_vector_store should create VectorStore."""
        from redis_agent_kit.cli.pipelines import get_vector_store

        vs = get_vector_store("redis://localhost:6379", "test")
        assert vs is not None
        assert vs.prefix == "test"


class TestPipelinesPrepare:
    """Tests for 'rak pipelines prepare' command."""

    def test_pipelines_prepare_exists(self):
        """Pipelines prepare command should exist."""
        from redis_agent_kit.cli.main import cli

        runner = CliRunner()
        result = runner.invoke(cli, ["pipelines", "prepare", "--help"])
        assert result.exit_code == 0
        assert "Prepare" in result.output

    def test_pipelines_prepare_requires_source(self):
        """Pipelines prepare should require source path."""
        from redis_agent_kit.cli.main import cli

        runner = CliRunner()
        result = runner.invoke(cli, ["pipelines", "prepare"])
        # Should fail without source
        assert result.exit_code != 0

    def test_pipelines_prepare_with_directory(self):
        """Pipelines prepare should accept directory path."""
        from redis_agent_kit.cli.main import cli

        runner = CliRunner()
        with tempfile.TemporaryDirectory() as tmpdir:
            # Create a test file
            test_file = Path(tmpdir) / "test.md"
            test_file.write_text("# Test\n\nContent.")

            result = runner.invoke(cli, ["pipelines", "prepare", tmpdir])
            assert result.exit_code == 0
            assert "batch" in result.output.lower() or "prepared" in result.output.lower()


class TestPipelinesIngest:
    """Tests for 'rak pipelines ingest' command."""

    def test_pipelines_ingest_exists(self):
        """Pipelines ingest command should exist."""
        from redis_agent_kit.cli.main import cli

        runner = CliRunner()
        result = runner.invoke(cli, ["pipelines", "ingest", "--help"])
        assert result.exit_code == 0
        assert "Ingest" in result.output

    def test_pipelines_ingest_requires_batch_id(self):
        """Pipelines ingest should require batch_id."""
        from redis_agent_kit.cli.main import cli

        runner = CliRunner()
        result = runner.invoke(cli, ["pipelines", "ingest"])
        # Should fail without batch_id
        assert result.exit_code != 0


class TestPipelinesBatches:
    """Tests for 'rak pipelines batches' command."""

    def test_pipelines_batches_exists(self):
        """Pipelines batches command should exist."""
        from redis_agent_kit.cli.main import cli

        runner = CliRunner()
        result = runner.invoke(cli, ["pipelines", "batches", "--help"])
        assert result.exit_code == 0
        assert "batch" in result.output.lower()

    def test_pipelines_batches_lists_batches(self):
        """Pipelines batches should list available batches."""
        from redis_agent_kit.cli.main import cli

        runner = CliRunner()
        with tempfile.TemporaryDirectory() as tmpdir:
            result = runner.invoke(cli, ["pipelines", "batches", "--artifacts-dir", tmpdir])
            assert result.exit_code == 0


class TestPipelinesAdd:
    """Tests for 'rak pipelines add' command."""

    def test_pipelines_add_exists(self):
        """Pipelines add command should exist."""
        from redis_agent_kit.cli.main import cli

        runner = CliRunner()
        result = runner.invoke(cli, ["pipelines", "add", "--help"])
        assert result.exit_code == 0
        assert "Add" in result.output or "add" in result.output.lower()

    def test_pipelines_add_requires_file(self):
        """Pipelines add should require file path."""
        from redis_agent_kit.cli.main import cli

        runner = CliRunner()
        result = runner.invoke(cli, ["pipelines", "add"])
        # Should fail without file
        assert result.exit_code != 0

    def test_pipelines_add_copies_file(self):
        """Pipelines add should copy file to custom docs."""
        from redis_agent_kit.cli.main import cli

        runner = CliRunner()
        with tempfile.TemporaryDirectory() as tmpdir:
            # Create a test file
            test_file = Path(tmpdir) / "test.md"
            test_file.write_text("# Test\n\nContent.")

            artifacts_dir = Path(tmpdir) / "artifacts"
            result = runner.invoke(
                cli, ["pipelines", "add", str(test_file), "--artifacts-dir", str(artifacts_dir)]
            )
            assert result.exit_code == 0
            assert "Added" in result.output


class TestPipelinesIngestExecution:
    """Tests for pipelines ingest command execution."""

    def test_pipelines_ingest_with_batch(self):
        """Pipelines ingest should ingest a prepared batch."""

        from redis_agent_kit.cli.main import cli
        from redis_agent_kit.pipelines.models import IngestionManifest

        runner = CliRunner()
        with tempfile.TemporaryDirectory() as tmpdir:
            artifacts_dir = Path(tmpdir) / "artifacts"
            artifacts_dir.mkdir(parents=True)

            mock_manifest = IngestionManifest(
                batch_id="batch-123",
                documents_ingested=5,
                chunks_embedded=20,
                status="completed",
            )

            with patch(
                "redis_agent_kit.pipelines.orchestrator.PipelineOrchestrator.ingest"
            ) as mock_ingest:
                mock_ingest.return_value = mock_manifest

                result = runner.invoke(
                    cli,
                    ["pipelines", "ingest", "batch-123", "--artifacts-dir", str(artifacts_dir)],
                )
                assert result.exit_code == 0
                assert "Ingested" in result.output
                assert "5 documents" in result.output


class TestPipelinesBatchesExecution:
    """Tests for pipelines batches command execution."""

    def test_pipelines_batches_with_batches(self):
        """Pipelines batches should list batches with manifests."""
        from redis_agent_kit.cli.main import cli

        runner = CliRunner()
        with tempfile.TemporaryDirectory() as tmpdir:
            # Create a batch with manifest
            artifacts_dir = Path(tmpdir) / "artifacts"
            batch_dir = artifacts_dir / "batch-123"
            batch_dir.mkdir(parents=True)

            manifest = {
                "batch_id": "batch-123",
                "batch_date": "2025-01-14",
                "created_at": "2025-01-14T00:00:00",
                "documents_prepared": 5,
                "chunks_created": 20,
            }
            (batch_dir / "manifest.json").write_text(__import__("json").dumps(manifest))

            result = runner.invoke(
                cli, ["pipelines", "batches", "--artifacts-dir", str(artifacts_dir)]
            )
            assert result.exit_code == 0
            assert "batch-123" in result.output
            assert "5 docs" in result.output

    def test_pipelines_batches_without_manifest(self):
        """Pipelines batches should handle batches without manifests."""
        from redis_agent_kit.cli.main import cli

        runner = CliRunner()
        with tempfile.TemporaryDirectory() as tmpdir:
            # Create a batch without manifest
            artifacts_dir = Path(tmpdir) / "artifacts"
            batch_dir = artifacts_dir / "batch-456"
            batch_dir.mkdir(parents=True)

            result = runner.invoke(
                cli, ["pipelines", "batches", "--artifacts-dir", str(artifacts_dir)]
            )
            assert result.exit_code == 0
            assert "batch-456" in result.output
            assert "(no manifest)" in result.output


class TestPipelinesIntegration:
    """Integration tests for pipeline commands."""

    async def test_pipelines_status_integration(self, redis_client):
        """Pipelines status should show chunk count from Redis."""
        from redis_agent_kit.cli.main import cli
        from redis_agent_kit.pipelines import Chunk, VectorStore

        host = redis_client.connection_pool.connection_kwargs["host"]
        port = redis_client.connection_pool.connection_kwargs["port"]
        redis_url = f"redis://{host}:{port}"

        # Add some chunks using store_chunks with embeddings
        vs = VectorStore(redis_client)
        chunk = Chunk(chunk_id="c1", doc_id="d1", content="test", chunk_index=0)
        await vs.store_chunks([chunk], [[0.1, 0.2, 0.3]])

        runner = CliRunner()
        result = runner.invoke(cli, ["--redis-url", redis_url, "pipelines", "status"])
        assert result.exit_code == 0
        assert "1" in result.output or "Chunks" in result.output

    async def test_pipelines_clear_integration(self, redis_client):
        """Pipelines clear should remove all chunks from Redis."""
        from redis_agent_kit.cli.main import cli
        from redis_agent_kit.pipelines import Chunk, VectorStore

        host = redis_client.connection_pool.connection_kwargs["host"]
        port = redis_client.connection_pool.connection_kwargs["port"]
        redis_url = f"redis://{host}:{port}"

        vs = VectorStore(redis_client)
        chunk = Chunk(chunk_id="c1", doc_id="d1", content="test", chunk_index=0)
        await vs.store_chunks([chunk], [[0.1, 0.2, 0.3]])
        assert await vs.count() == 1

        runner = CliRunner()
        result = runner.invoke(cli, ["--redis-url", redis_url, "pipelines", "clear", "--yes"])
        assert result.exit_code == 0
        assert "cleared" in result.output.lower()

    async def test_pipelines_run_integration(self, redis_client):
        """Pipelines run should process files and store chunks."""
        from redis_agent_kit.cli.main import cli

        host = redis_client.connection_pool.connection_kwargs["host"]
        port = redis_client.connection_pool.connection_kwargs["port"]
        redis_url = f"redis://{host}:{port}"

        with tempfile.TemporaryDirectory() as tmpdir:
            # Create a test file
            test_file = Path(tmpdir) / "test.md"
            test_file.write_text("# Test Document\n\nThis is test content for the pipeline.")

            runner = CliRunner()
            result = runner.invoke(
                cli,
                ["--redis-url", redis_url, "pipelines", "run", tmpdir, "--pattern", "*.md"],
            )
            # May fail due to embedding API, but should at least start
            assert "Running pipeline" in result.output or result.exit_code == 0


class TestPipelineRunWithErrors:
    """Tests for pipeline run command with errors."""

    def test_pipelines_run_displays_errors(self):
        """Pipelines run should display errors from pipeline."""
        from redis_agent_kit.cli.main import cli

        runner = CliRunner()
        with tempfile.TemporaryDirectory() as tmpdir:
            with patch("redis_agent_kit.cli.pipelines.run_pipeline") as mock_run:
                mock_run.return_value = {
                    "status": "completed",
                    "documents_processed": 1,
                    "chunks_created": 5,
                    "errors": ["Failed to process doc1.md", "Invalid frontmatter in doc2.md"],
                }
                result = runner.invoke(cli, ["pipelines", "run", tmpdir])
                assert "Errors:" in result.output
                assert "Failed to process doc1.md" in result.output
                assert "Invalid frontmatter in doc2.md" in result.output
