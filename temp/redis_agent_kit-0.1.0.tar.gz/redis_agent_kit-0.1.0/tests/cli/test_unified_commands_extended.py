"""Extended CLI coverage for unified agent/task/up commands."""

from __future__ import annotations

import json
from unittest.mock import patch

from click.testing import CliRunner


def test_task_run_rejects_conflicting_input_flags() -> None:
    from redis_agent_kit.cli.main import cli

    result = CliRunner().invoke(
        cli,
        [
            "--api-base",
            "http://localhost:8000",
            "--project",
            "p1",
            "--agent",
            "a1",
            "task",
            "run",
            "--input-json",
            "{}",
            "--input-file",
            "input.json",
        ],
    )
    assert result.exit_code != 0
    assert "Use only one of --input-json or --input-file" in result.output


def test_task_run_supports_request_file_and_context_json(tmp_path) -> None:
    from redis_agent_kit.cli.main import cli

    request_file = tmp_path / "request.json"
    request_file.write_text('{"protocol":"rest","input":{"message":"hello"}}', encoding="utf-8")

    with patch("redis_agent_kit.cli.task.call_api") as call_api:
        call_api.return_value = {"ok": True}
        result = CliRunner().invoke(
            cli,
            [
                "--api-base",
                "http://localhost:8000",
                "--project",
                "p1",
                "--agent",
                "a1",
                "task",
                "run",
                "--request-file",
                str(request_file),
                "--context-json",
                '{"x":1}',
            ],
        )
    assert result.exit_code == 0
    payload = call_api.call_args.kwargs["payload"]
    assert payload["request"]["input"]["message"] == "hello"
    assert payload["context"] == {"x": 1}


def test_task_run_supports_input_file(tmp_path) -> None:
    from redis_agent_kit.cli.main import cli

    input_file = tmp_path / "input.json"
    input_file.write_text('{"message":"from-file"}', encoding="utf-8")

    with patch("redis_agent_kit.cli.task.call_api") as call_api:
        call_api.return_value = {"ok": True}
        result = CliRunner().invoke(
            cli,
            [
                "--api-base",
                "http://localhost:8000",
                "--project",
                "p1",
                "--agent",
                "a1",
                "task",
                "run",
                "--input-file",
                str(input_file),
            ],
        )
    assert result.exit_code == 0
    payload = call_api.call_args.kwargs["payload"]
    assert payload["request"]["input"]["message"] == "from-file"


def test_task_commands_use_expected_paths() -> None:
    from redis_agent_kit.cli.main import cli

    runner = CliRunner()
    common = ["--api-base", "http://localhost:8000", "--project", "p1", "--agent", "a1"]

    with patch("redis_agent_kit.cli.task.call_api") as call_api:
        call_api.return_value = {"ok": True}

        assert runner.invoke(cli, [*common, "task", "get", "t1"]).exit_code == 0
        assert call_api.call_args.kwargs["path"].endswith("/tasks/t1")

        assert runner.invoke(cli, [*common, "task", "result", "t1"]).exit_code == 0
        assert call_api.call_args.kwargs["path"].endswith("/tasks/t1/result")

        assert runner.invoke(cli, [*common, "task", "logs", "t1", "--limit", "12"]).exit_code == 0
        assert call_api.call_args.kwargs["params"] == {"limit": 12}

        assert runner.invoke(cli, [*common, "task", "cancel", "t1"]).exit_code == 0
        assert call_api.call_args.kwargs["method"] == "POST"

        assert (
            runner.invoke(
                cli,
                [*common, "task", "input", "t1", "--response-json", '{"answer":"ok"}'],
            ).exit_code
            == 0
        )
        assert call_api.call_args.kwargs["payload"] == {"response": {"answer": "ok"}}


def test_task_list_passes_status_filter_and_missing_project_fails() -> None:
    from redis_agent_kit.cli.main import cli

    runner = CliRunner()
    with patch("redis_agent_kit.cli.task.call_api") as call_api:
        call_api.return_value = {"ok": True}
        ok_result = runner.invoke(
            cli,
            [
                "--api-base",
                "http://localhost:8000",
                "--project",
                "p1",
                "--agent",
                "a1",
                "task",
                "list",
                "--status",
                "done",
            ],
        )
    assert ok_result.exit_code == 0
    assert call_api.call_args.kwargs["params"]["status"] == "done"

    missing_project = runner.invoke(
        cli,
        ["--api-base", "http://localhost:8000", "--agent", "a1", "task", "list"],
    )
    assert missing_project.exit_code != 0
    assert "Project ID is required" in missing_project.output


def test_agent_get_and_project_required_errors() -> None:
    from redis_agent_kit.cli.main import cli

    runner = CliRunner()
    with patch("redis_agent_kit.cli.agent.call_api") as call_api:
        call_api.return_value = {"ok": True}
        ok_result = runner.invoke(
            cli,
            ["--api-base", "http://localhost:8000", "--project", "p1", "agent", "get", "a1"],
        )
    assert ok_result.exit_code == 0
    assert call_api.call_args.kwargs["path"] == "/v1/projects/p1/agents/a1"

    missing_project = runner.invoke(cli, ["--api-base", "http://localhost:8000", "agent", "list"])
    assert missing_project.exit_code != 0
    assert "Project ID is required" in missing_project.output

    missing_project_get = runner.invoke(
        cli, ["--api-base", "http://localhost:8000", "agent", "get", "a1"]
    )
    assert missing_project_get.exit_code != 0
    assert "Project ID is required" in missing_project_get.output


def test_up_optional_payload_fields_and_project_required(tmp_path) -> None:
    from redis_agent_kit.cli.main import cli

    manifest_file = tmp_path / "team.json"
    manifest_file.write_text(json.dumps({"team": "alpha"}), encoding="utf-8")

    runner = CliRunner()
    with patch("redis_agent_kit.cli.up.call_api") as call_api:
        call_api.return_value = {"ok": True}
        ok_result = runner.invoke(
            cli,
            [
                "--api-base",
                "http://localhost:8000",
                "--project",
                "p1",
                "--agent",
                "a1",
                "up",
                "--entrypoint",
                "agent.py:main",
                "--build",
                "b1",
                "--deployment",
                "d1",
                "--version",
                "v1",
                "--team-manifest",
                str(manifest_file),
            ],
        )
    assert ok_result.exit_code == 0
    payload = call_api.call_args.kwargs["payload"]
    assert payload["buildId"] == "b1"
    assert payload["deploymentId"] == "d1"
    assert payload["versionId"] == "v1"
    assert payload["teamManifest"] == {"team": "alpha"}

    missing_project = runner.invoke(
        cli,
        [
            "--api-base",
            "http://localhost:8000",
            "--agent",
            "a1",
            "up",
            "--entrypoint",
            "agent.py:main",
        ],
    )
    assert missing_project.exit_code != 0
    assert "Project ID is required" in missing_project.output
