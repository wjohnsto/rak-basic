"""Pytest fixtures for Redis Agent Kit tests."""

import asyncio
from collections.abc import AsyncGenerator

import pytest
import redis.asyncio as redis
from testcontainers.redis import RedisContainer


@pytest.fixture(scope="session")
def event_loop():
    """Create an event loop for the test session."""
    loop = asyncio.new_event_loop()
    yield loop
    loop.close()


@pytest.fixture(scope="session")
def redis_container():
    """Start a Redis Stack container for the test session (includes FT.SEARCH)."""
    with RedisContainer("redis/redis-stack-server:latest") as container:
        yield container


@pytest.fixture(scope="session")
def redis_url(redis_container: RedisContainer) -> str:
    """Get Redis URL from the container."""
    host = redis_container.get_container_host_ip()
    port = redis_container.get_exposed_port(6379)
    return f"redis://{host}:{port}"


@pytest.fixture
async def redis_client(redis_url: str) -> AsyncGenerator[redis.Redis, None]:
    """Create a Redis client for each test, with cleanup."""
    client = redis.from_url(redis_url, decode_responses=True)
    try:
        yield client
    finally:
        # Clean up all keys after each test
        await client.flushdb()
        await client.aclose()


@pytest.fixture
async def redis_client_bytes(redis_url: str) -> AsyncGenerator[redis.Redis, None]:
    """Create a Redis client that returns bytes (for binary data)."""
    client = redis.from_url(redis_url, decode_responses=False)
    try:
        yield client
    finally:
        await client.flushdb()
        await client.aclose()


@pytest.fixture
def mock_openai_vectorizer():
    """Mock OpenAITextVectorizer to avoid API calls during tests."""
    from unittest.mock import AsyncMock, MagicMock, patch

    def make_embeddings(texts):
        """Return one embedding per input text."""
        return [[0.1, 0.2, 0.3] for _ in texts]

    async def make_embeddings_async(texts):
        """Return one embedding per input text (async)."""
        return [[0.1, 0.2, 0.3] for _ in texts]

    mock_vectorizer = MagicMock()
    mock_vectorizer.embed = MagicMock(return_value=[0.1, 0.2, 0.3])
    mock_vectorizer.embed_many = MagicMock(side_effect=make_embeddings)
    mock_vectorizer.aembed = AsyncMock(return_value=[0.1, 0.2, 0.3])
    mock_vectorizer.aembed_many = AsyncMock(side_effect=make_embeddings_async)

    with patch(
        "redis_agent_kit.vectorizer.OpenAITextVectorizer",
        return_value=mock_vectorizer,
    ):
        yield mock_vectorizer


@pytest.fixture(autouse=True)
def _stub_external_embeddings(monkeypatch):
    """Stub external embedding providers for deterministic local test runs."""

    class _DummyOpenAITextVectorizer:
        def __init__(self, model=None, api_config=None, cache=None):  # noqa: ARG002
            self.model = model
            self.api_config = api_config
            self.cache = cache
            self.dims = 3

        def embed(self, text: str):  # noqa: ARG002
            return [0.1, 0.2, 0.3]

        def embed_many(self, texts):
            return [[0.1, 0.2, 0.3] for _ in texts]

        async def aembed(self, text: str):  # noqa: ARG002
            return [0.1, 0.2, 0.3]

        async def aembed_many(self, texts):
            return [[0.1, 0.2, 0.3] for _ in texts]

    class _LiteLLMResponse:
        def __init__(self, batch_size: int):
            self.data = [{"embedding": [0.1, 0.2, 0.3]} for _ in range(batch_size)]

    def _embedding(*args, **kwargs):  # noqa: ANN002, ANN003
        input_values = kwargs.get("input", [])
        batch_size = len(input_values) if isinstance(input_values, list) else 1
        return _LiteLLMResponse(batch_size)

    async def _aembedding(*args, **kwargs):  # noqa: ANN002, ANN003
        input_values = kwargs.get("input", [])
        batch_size = len(input_values) if isinstance(input_values, list) else 1
        return _LiteLLMResponse(batch_size)

    monkeypatch.setattr(
        "redis_agent_kit.vectorizer.OpenAITextVectorizer",
        _DummyOpenAITextVectorizer,
    )
    monkeypatch.setattr("litellm.embedding", _embedding)
    monkeypatch.setattr("litellm.aembedding", _aembedding)
