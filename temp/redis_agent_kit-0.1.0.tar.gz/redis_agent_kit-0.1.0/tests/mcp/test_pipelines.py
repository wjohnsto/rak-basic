"""TDD tests for MCP pipeline tools - written BEFORE implementation."""

import pytest


class TestMCPPipelineStatusTool:
    """Tests for pipeline_status MCP tool."""

    def test_pipeline_status_tool_exists(self):
        """pipeline_status tool should be registered."""
        from redis_agent_kit.mcp.server import create_server

        server = create_server()
        assert "pipeline_status" in server._tool_manager._tools


class TestMCPPipelineClearTool:
    """Tests for pipeline_clear MCP tool."""

    def test_pipeline_clear_tool_exists(self):
        """pipeline_clear tool should be registered."""
        from redis_agent_kit.mcp.server import create_server

        server = create_server()
        assert "pipeline_clear" in server._tool_manager._tools


class TestMCPPipelineSearchTool:
    """Tests for pipeline_search MCP tool."""

    def test_pipeline_search_tool_exists(self):
        """pipeline_search tool should be registered."""
        from redis_agent_kit.mcp.server import create_server

        server = create_server()
        assert "pipeline_search" in server._tool_manager._tools

    def test_pipeline_search_has_correct_parameters(self):
        """pipeline_search should accept query and limit parameters."""
        from redis_agent_kit.mcp.server import create_server

        server = create_server()
        tool = server._tool_manager._tools["pipeline_search"]
        params = tool.fn.__code__.co_varnames
        assert "query" in params
        assert "limit" in params


class TestMCPPipelinePrepareTool:
    """Tests for pipeline_prepare MCP tool."""

    def test_pipeline_prepare_tool_exists(self):
        """pipeline_prepare tool should be registered."""
        from redis_agent_kit.mcp.server import create_server

        server = create_server()
        assert "pipeline_prepare" in server._tool_manager._tools

    def test_pipeline_prepare_has_correct_parameters(self):
        """pipeline_prepare should accept source_path parameter."""
        from redis_agent_kit.mcp.server import create_server

        server = create_server()
        tool = server._tool_manager._tools["pipeline_prepare"]
        params = tool.fn.__code__.co_varnames
        assert "source_path" in params


class TestMCPPipelineIngestTool:
    """Tests for pipeline_ingest MCP tool."""

    def test_pipeline_ingest_tool_exists(self):
        """pipeline_ingest tool should be registered."""
        from redis_agent_kit.mcp.server import create_server

        server = create_server()
        assert "pipeline_ingest" in server._tool_manager._tools

    def test_pipeline_ingest_has_correct_parameters(self):
        """pipeline_ingest should accept batch_id parameter."""
        from redis_agent_kit.mcp.server import create_server

        server = create_server()
        tool = server._tool_manager._tools["pipeline_ingest"]
        params = tool.fn.__code__.co_varnames
        assert "batch_id" in params


class TestMCPPipelineRunTool:
    """Tests for pipeline_run MCP tool."""

    def test_pipeline_run_tool_exists(self):
        """pipeline_run tool should be registered."""
        from redis_agent_kit.mcp.server import create_server

        server = create_server()
        assert "pipeline_run" in server._tool_manager._tools

    def test_pipeline_run_has_correct_parameters(self):
        """pipeline_run should accept source_path parameter."""
        from redis_agent_kit.mcp.server import create_server

        server = create_server()
        tool = server._tool_manager._tools["pipeline_run"]
        params = tool.fn.__code__.co_varnames
        assert "source_path" in params


class TestMCPPipelineAddDocumentTool:
    """Tests for pipeline_add_document MCP tool."""

    def test_pipeline_add_document_tool_exists(self):
        """pipeline_add_document tool should be registered."""
        from redis_agent_kit.mcp.server import create_server

        server = create_server()
        assert "pipeline_add_document" in server._tool_manager._tools

    def test_pipeline_add_document_has_correct_parameters(self):
        """pipeline_add_document should accept content and filename parameters."""
        from redis_agent_kit.mcp.server import create_server

        server = create_server()
        tool = server._tool_manager._tools["pipeline_add_document"]
        params = tool.fn.__code__.co_varnames
        assert "content" in params
        assert "filename" in params


class TestMCPPipelineBatchesTool:
    """Tests for pipeline_batches MCP tool."""

    def test_pipeline_batches_tool_exists(self):
        """pipeline_batches tool should be registered."""
        from redis_agent_kit.mcp.server import create_server

        server = create_server()
        assert "pipeline_batches" in server._tool_manager._tools


class TestMCPPipelineDeleteBatchTool:
    """Tests for pipeline_delete_batch MCP tool."""

    def test_pipeline_delete_batch_tool_exists(self):
        """pipeline_delete_batch tool should be registered."""
        from redis_agent_kit.mcp.server import create_server

        server = create_server()
        assert "pipeline_delete_batch" in server._tool_manager._tools

    def test_pipeline_delete_batch_has_correct_parameters(self):
        """pipeline_delete_batch should accept batch_id parameter."""
        from redis_agent_kit.mcp.server import create_server

        server = create_server()
        tool = server._tool_manager._tools["pipeline_delete_batch"]
        params = tool.fn.__code__.co_varnames
        assert "batch_id" in params


class TestMCPPipelineToolExecution:
    """Tests for MCP pipeline tool execution."""

    @pytest.mark.asyncio
    async def test_pipeline_prepare_execution(self, tmp_path):
        """pipeline_prepare should submit a prepare task."""
        from unittest.mock import AsyncMock, patch

        from redis_agent_kit.mcp.server import create_server

        server = create_server()
        server._artifacts_dir = str(tmp_path)

        tool = server._tool_manager._tools["pipeline_prepare"]

        with (
            patch("redis_agent_kit.mcp.server.Docket") as mock_docket,
            patch(
                "redis_agent_kit.pipelines.orchestrator.PipelineOrchestrator.submit_prepare",
                new_callable=AsyncMock,
            ) as mock_submit,
        ):
            mock_docket_instance = AsyncMock()
            mock_docket.return_value.__aenter__.return_value = mock_docket_instance
            mock_docket.return_value.__aexit__.return_value = None
            mock_submit.return_value = "task-123"
            result = await tool.fn(source_path=str(tmp_path))
            assert result["task_id"] == "task-123"

    @pytest.mark.asyncio
    async def test_pipeline_ingest_execution(self, tmp_path):
        """pipeline_ingest should submit an ingest task."""
        from unittest.mock import AsyncMock, patch

        from redis_agent_kit.mcp.server import create_server

        server = create_server()
        server._artifacts_dir = str(tmp_path)

        tool = server._tool_manager._tools["pipeline_ingest"]

        with (
            patch("redis_agent_kit.mcp.server.Docket") as mock_docket,
            patch(
                "redis_agent_kit.pipelines.orchestrator.PipelineOrchestrator.submit_ingest",
                new_callable=AsyncMock,
            ) as mock_submit,
        ):
            mock_docket_instance = AsyncMock()
            mock_docket.return_value.__aenter__.return_value = mock_docket_instance
            mock_docket.return_value.__aexit__.return_value = None
            mock_submit.return_value = "task-456"
            result = await tool.fn(batch_id="2025-01-14")
            assert result["task_id"] == "task-456"

    @pytest.mark.asyncio
    async def test_pipeline_run_execution(self, tmp_path):
        """pipeline_run should submit a full pipeline task."""
        from unittest.mock import AsyncMock, patch

        from redis_agent_kit.mcp.server import create_server

        server = create_server()
        server._artifacts_dir = str(tmp_path)

        tool = server._tool_manager._tools["pipeline_run"]

        with (
            patch("redis_agent_kit.mcp.server.Docket") as mock_docket,
            patch(
                "redis_agent_kit.pipelines.orchestrator.PipelineOrchestrator.submit_full",
                new_callable=AsyncMock,
            ) as mock_submit,
        ):
            mock_docket_instance = AsyncMock()
            mock_docket.return_value.__aenter__.return_value = mock_docket_instance
            mock_docket.return_value.__aexit__.return_value = None
            mock_submit.return_value = "task-789"
            result = await tool.fn(source_path=str(tmp_path))
            assert result["task_id"] == "task-789"

    @pytest.mark.asyncio
    async def test_pipeline_add_document_execution(self, tmp_path):
        """pipeline_add_document should submit a document task."""
        from unittest.mock import AsyncMock, patch

        from redis_agent_kit.mcp.server import create_server

        server = create_server()
        server._artifacts_dir = str(tmp_path)

        tool = server._tool_manager._tools["pipeline_add_document"]

        with (
            patch("redis_agent_kit.mcp.server.Docket") as mock_docket,
            patch(
                "redis_agent_kit.pipelines.orchestrator.PipelineOrchestrator.submit_document",
                new_callable=AsyncMock,
            ) as mock_submit,
        ):
            mock_docket_instance = AsyncMock()
            mock_docket.return_value.__aenter__.return_value = mock_docket_instance
            mock_docket.return_value.__aexit__.return_value = None
            mock_submit.return_value = "task-doc-1"
            result = await tool.fn(content="# Test", filename="test.md")
            assert result["task_id"] == "task-doc-1"

    @pytest.mark.asyncio
    async def test_pipeline_batches_execution(self, tmp_path):
        """pipeline_batches should list batches."""
        from unittest.mock import patch

        from redis_agent_kit.mcp.server import create_server

        server = create_server()
        server._artifacts_dir = str(tmp_path)

        tool = server._tool_manager._tools["pipeline_batches"]

        with patch(
            "redis_agent_kit.pipelines.artifact_storage.ArtifactStorage.list_batches"
        ) as mock_list:
            mock_list.return_value = ["2025-01-14", "2025-01-13"]
            result = await tool.fn()
            assert result["batches"] == ["2025-01-14", "2025-01-13"]

    @pytest.mark.asyncio
    async def test_pipeline_delete_batch_execution(self, tmp_path):
        """pipeline_delete_batch should delete a batch."""
        from unittest.mock import patch

        from redis_agent_kit.mcp.server import create_server

        server = create_server()
        server._artifacts_dir = str(tmp_path)

        tool = server._tool_manager._tools["pipeline_delete_batch"]

        with patch(
            "redis_agent_kit.pipelines.artifact_storage.ArtifactStorage.delete_batch"
        ) as mock_delete:
            mock_delete.return_value = True
            result = await tool.fn(batch_id="2025-01-14")
            assert result["deleted"] is True
            assert result["batch_id"] == "2025-01-14"
