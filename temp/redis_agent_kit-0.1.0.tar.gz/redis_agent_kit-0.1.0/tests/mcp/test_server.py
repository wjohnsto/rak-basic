"""TDD tests for MCP server - written BEFORE implementation."""


class TestMCPServer:
    """Tests for MCP server setup."""

    def test_create_server_exists(self):
        """create_server function should exist."""
        from redis_agent_kit.mcp.server import create_server

        assert create_server is not None

    def test_create_server_returns_fastmcp(self):
        """create_server should return FastMCP instance."""
        from fastmcp import FastMCP

        from redis_agent_kit.mcp.server import create_server

        server = create_server()
        assert isinstance(server, FastMCP)

    def test_server_has_name(self):
        """Server should have a name."""
        from redis_agent_kit.mcp.server import create_server

        server = create_server()
        assert server.name == "redis-agent-kit"

    def test_server_accepts_redis_url(self):
        """Server should accept redis_url parameter."""
        from redis_agent_kit.mcp.server import create_server

        server = create_server(redis_url="redis://custom:6379")
        # The redis_url should be stored in server context
        assert hasattr(server, "_redis_url") or server._redis_url == "redis://custom:6379"


class TestMCPServerKwargsPassthrough:
    """Tests for kwargs passthrough to FastMCP."""

    def test_create_server_accepts_kwargs(self):
        """create_server should accept kwargs."""
        from redis_agent_kit.mcp.server import create_server

        server = create_server(name="custom-server")
        assert server.name == "custom-server"

    def test_create_server_custom_instructions(self):
        """create_server should pass instructions to FastMCP."""
        from redis_agent_kit.mcp.server import create_server

        server = create_server(instructions="Custom instructions")
        assert server.instructions == "Custom instructions"

    def test_create_server_preserves_defaults(self):
        """create_server should preserve defaults when not overridden."""
        from redis_agent_kit.mcp.server import create_server

        server = create_server()
        assert server.name == "redis-agent-kit"
        assert "Redis Agent Kit" in server.instructions


class TestMCPServerTools:
    """Tests for MCP server tool registration."""

    def test_server_has_tools(self):
        """Server should have registered tools."""
        from redis_agent_kit.mcp.server import create_server

        server = create_server()
        # FastMCP stores tools internally
        assert len(server._tool_manager._tools) > 0

    def test_server_has_task_tools(self):
        """Server should have task-related tools."""
        from redis_agent_kit.mcp.server import create_server

        server = create_server()
        tool_names = list(server._tool_manager._tools.keys())
        assert "list_tasks" in tool_names
        assert "get_task" in tool_names

    def test_server_has_pipeline_tools(self):
        """Server should have pipeline-related tools."""
        from redis_agent_kit.mcp.server import create_server

        server = create_server()
        tool_names = list(server._tool_manager._tools.keys())
        assert "pipeline_status" in tool_names


class TestMCPToolExecution:
    """Tests for actual MCP tool execution."""

    async def test_list_tasks_returns_empty(self, redis_client):
        """list_tasks should return empty list initially."""
        from redis_agent_kit.mcp.server import create_server

        host = redis_client.connection_pool.connection_kwargs["host"]
        port = redis_client.connection_pool.connection_kwargs["port"]
        redis_url = f"redis://{host}:{port}"

        server = create_server(redis_url=redis_url)
        tools = server._tool_manager._tools
        list_tasks_tool = tools["list_tasks"]

        result = await list_tasks_tool.fn()
        assert result["tasks"] == []
        assert result["total"] == 0

    async def test_list_tasks_returns_tasks(self, redis_client):
        """list_tasks should return created tasks."""
        from redis_agent_kit import TaskManager
        from redis_agent_kit.mcp.server import create_server

        host = redis_client.connection_pool.connection_kwargs["host"]
        port = redis_client.connection_pool.connection_kwargs["port"]
        redis_url = f"redis://{host}:{port}"

        # Use same prefix as server default
        tm = TaskManager(redis_client, prefix="rak")
        await tm.create_task(session_id="t1", message="Test")

        server = create_server(redis_url=redis_url)
        tools = server._tool_manager._tools

        result = await tools["list_tasks"].fn()
        assert result["total"] == 1
        assert len(result["tasks"]) == 1

    async def test_list_tasks_with_status_filter(self, redis_client):
        """list_tasks should filter by status."""
        from redis_agent_kit import TaskManager, TaskStatus
        from redis_agent_kit.mcp.server import create_server

        host = redis_client.connection_pool.connection_kwargs["host"]
        port = redis_client.connection_pool.connection_kwargs["port"]
        redis_url = f"redis://{host}:{port}"

        # Use same prefix as server default
        tm = TaskManager(redis_client, prefix="rak")
        task = await tm.create_task(session_id="t1", message="Test")
        await tm.update_status(task.task_id, TaskStatus.IN_PROGRESS)

        server = create_server(redis_url=redis_url)
        tools = server._tool_manager._tools

        result = await tools["list_tasks"].fn(status="in_progress")
        assert result["total"] == 1

        result = await tools["list_tasks"].fn(status="queued")
        assert result["total"] == 0

    async def test_get_task_returns_task(self, redis_client):
        """get_task should return task details."""
        from redis_agent_kit import TaskManager
        from redis_agent_kit.mcp.server import create_server

        host = redis_client.connection_pool.connection_kwargs["host"]
        port = redis_client.connection_pool.connection_kwargs["port"]
        redis_url = f"redis://{host}:{port}"

        # Use same prefix as server default
        tm = TaskManager(redis_client, prefix="rak")
        task = await tm.create_task(session_id="t1", message="Test")

        server = create_server(redis_url=redis_url)
        tools = server._tool_manager._tools

        result = await tools["get_task"].fn(task_id=task.task_id)
        assert result["task_id"] == task.task_id
        # Check metadata contains message
        assert result["metadata"]["message"] == "Test"

    async def test_get_task_not_found(self, redis_client):
        """get_task should return error for non-existent task."""
        from redis_agent_kit.mcp.server import create_server

        host = redis_client.connection_pool.connection_kwargs["host"]
        port = redis_client.connection_pool.connection_kwargs["port"]
        redis_url = f"redis://{host}:{port}"

        server = create_server(redis_url=redis_url)
        tools = server._tool_manager._tools

        result = await tools["get_task"].fn(task_id="nonexistent")
        assert "error" in result

    async def test_delete_task_success(self, redis_client):
        """delete_task should delete an existing task."""
        from redis_agent_kit import TaskManager
        from redis_agent_kit.mcp.server import create_server

        host = redis_client.connection_pool.connection_kwargs["host"]
        port = redis_client.connection_pool.connection_kwargs["port"]
        redis_url = f"redis://{host}:{port}"

        tm = TaskManager(redis_client)
        task = await tm.create_task(session_id="t1", message="Test")

        server = create_server(redis_url=redis_url)
        tools = server._tool_manager._tools

        result = await tools["delete_task"].fn(task_id=task.task_id)
        assert result["deleted"] is True
        assert await tm.get_task(task.task_id) is None

    async def test_delete_task_not_found(self, redis_client):
        """delete_task should return error for non-existent task."""
        from redis_agent_kit.mcp.server import create_server

        host = redis_client.connection_pool.connection_kwargs["host"]
        port = redis_client.connection_pool.connection_kwargs["port"]
        redis_url = f"redis://{host}:{port}"

        server = create_server(redis_url=redis_url)
        tools = server._tool_manager._tools

        result = await tools["delete_task"].fn(task_id="nonexistent")
        assert result["deleted"] is False
        assert "error" in result

    async def test_pipeline_status(self, redis_client):
        """pipeline_status should return chunk count."""
        from redis_agent_kit.mcp.server import create_server

        host = redis_client.connection_pool.connection_kwargs["host"]
        port = redis_client.connection_pool.connection_kwargs["port"]
        redis_url = f"redis://{host}:{port}"

        server = create_server(redis_url=redis_url)
        tools = server._tool_manager._tools

        result = await tools["pipeline_status"].fn()
        assert "chunks" in result
        assert result["status"] == "ready"

    async def test_pipeline_clear(self, redis_client):
        """pipeline_clear should clear all data."""
        from redis_agent_kit.mcp.server import create_server
        from redis_agent_kit.pipelines import Chunk, VectorStore

        host = redis_client.connection_pool.connection_kwargs["host"]
        port = redis_client.connection_pool.connection_kwargs["port"]
        redis_url = f"redis://{host}:{port}"

        vs = VectorStore(redis_client)
        chunk = Chunk(chunk_id="c1", doc_id="d1", content="test", chunk_index=0)
        await vs.store_chunks([chunk], [[0.1, 0.2, 0.3]])
        assert await vs.count() == 1

        server = create_server(redis_url=redis_url)
        tools = server._tool_manager._tools

        result = await tools["pipeline_clear"].fn()
        assert result["cleared"] is True

    async def test_pipeline_search(self, redis_client):
        """pipeline_search should return search results."""
        from redis_agent_kit.mcp.server import create_server

        host = redis_client.connection_pool.connection_kwargs["host"]
        port = redis_client.connection_pool.connection_kwargs["port"]
        redis_url = f"redis://{host}:{port}"

        server = create_server(redis_url=redis_url)
        tools = server._tool_manager._tools

        result = await tools["pipeline_search"].fn(query="test query", limit=5)
        assert result["query"] == "test query"
        assert result["limit"] == 5
        assert "results" in result
        assert "count" in result
