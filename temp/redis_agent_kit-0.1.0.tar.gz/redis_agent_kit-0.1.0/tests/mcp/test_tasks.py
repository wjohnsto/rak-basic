"""TDD tests for MCP task tools - written BEFORE implementation."""


class TestMCPListTasksTool:
    """Tests for list_tasks MCP tool."""

    def test_list_tasks_tool_exists(self):
        """list_tasks tool should be registered."""
        from redis_agent_kit.mcp.server import create_server

        server = create_server()
        assert "list_tasks" in server._tool_manager._tools

    def test_list_tasks_has_correct_parameters(self):
        """list_tasks should accept status, thread_id, limit parameters."""
        from redis_agent_kit.mcp.server import create_server

        server = create_server()
        tool = server._tool_manager._tools["list_tasks"]
        # Check the function signature via parameters
        params = tool.fn.__code__.co_varnames
        assert "status" in params
        assert "session_id" in params
        assert "limit" in params


class TestMCPGetTaskTool:
    """Tests for get_task MCP tool."""

    def test_get_task_tool_exists(self):
        """get_task tool should be registered."""
        from redis_agent_kit.mcp.server import create_server

        server = create_server()
        assert "get_task" in server._tool_manager._tools

    def test_get_task_has_correct_parameters(self):
        """get_task should accept task_id parameter."""
        from redis_agent_kit.mcp.server import create_server

        server = create_server()
        tool = server._tool_manager._tools["get_task"]
        params = tool.fn.__code__.co_varnames
        assert "task_id" in params


class TestMCPDeleteTaskTool:
    """Tests for delete_task MCP tool."""

    def test_delete_task_tool_exists(self):
        """delete_task tool should be registered."""
        from redis_agent_kit.mcp.server import create_server

        server = create_server()
        assert "delete_task" in server._tool_manager._tools

    def test_delete_task_has_correct_parameters(self):
        """delete_task should accept task_id parameter."""
        from redis_agent_kit.mcp.server import create_server

        server = create_server()
        tool = server._tool_manager._tools["delete_task"]
        params = tool.fn.__code__.co_varnames
        assert "task_id" in params
