"""TDD tests for ArtifactStorage - written BEFORE implementation."""


class TestArtifactStorageBatchManagement:
    """Tests for ArtifactStorage batch directory management."""

    def test_create_batch_dir(self, tmp_path):
        """ArtifactStorage should create a timestamped batch directory."""
        from redis_agent_kit.pipelines.artifact_storage import ArtifactStorage

        storage = ArtifactStorage(artifacts_dir=tmp_path)
        batch_dir, batch_id = storage.create_batch()
        assert batch_dir.exists()
        assert batch_dir.parent == tmp_path
        # Batch ID should be a ULID-like string
        assert len(batch_id) > 0

    def test_get_batch_dir(self, tmp_path):
        """ArtifactStorage should get existing batch directory."""
        from redis_agent_kit.pipelines.artifact_storage import ArtifactStorage

        storage = ArtifactStorage(artifacts_dir=tmp_path)
        batch_dir, batch_id = storage.create_batch()
        retrieved = storage.get_batch_dir(batch_id)
        assert retrieved == batch_dir

    def test_get_batch_dir_not_found(self, tmp_path):
        """ArtifactStorage should return None for non-existent batch."""
        from redis_agent_kit.pipelines.artifact_storage import ArtifactStorage

        storage = ArtifactStorage(artifacts_dir=tmp_path)
        result = storage.get_batch_dir("nonexistent")
        assert result is None

    def test_list_batches(self, tmp_path):
        """ArtifactStorage should list all batches."""
        from redis_agent_kit.pipelines.artifact_storage import ArtifactStorage

        storage = ArtifactStorage(artifacts_dir=tmp_path)
        _, batch_id1 = storage.create_batch()
        _, batch_id2 = storage.create_batch()
        batches = storage.list_batches()
        assert len(batches) == 2
        assert batch_id1 in batches
        assert batch_id2 in batches

    def test_list_batches_empty(self, tmp_path):
        """ArtifactStorage should return empty list when no batches."""
        from redis_agent_kit.pipelines.artifact_storage import ArtifactStorage

        storage = ArtifactStorage(artifacts_dir=tmp_path)
        batches = storage.list_batches()
        assert batches == []

    def test_list_batches_nonexistent_dir(self, tmp_path):
        """ArtifactStorage should return empty list when artifacts_dir doesn't exist."""
        from redis_agent_kit.pipelines.artifact_storage import ArtifactStorage

        nonexistent = tmp_path / "nonexistent"
        storage = ArtifactStorage.__new__(ArtifactStorage)
        storage.artifacts_dir = nonexistent
        storage.custom_docs_dir = nonexistent / "custom"
        batches = storage.list_batches()
        assert batches == []

    def test_delete_batch(self, tmp_path):
        """ArtifactStorage should delete a batch directory."""
        from redis_agent_kit.pipelines.artifact_storage import ArtifactStorage

        storage = ArtifactStorage(artifacts_dir=tmp_path)
        batch_dir, batch_id = storage.create_batch()
        assert batch_dir.exists()
        storage.delete_batch(batch_id)
        assert not batch_dir.exists()

    def test_delete_batch_not_found(self, tmp_path):
        """ArtifactStorage should handle deleting non-existent batch."""
        from redis_agent_kit.pipelines.artifact_storage import ArtifactStorage

        storage = ArtifactStorage(artifacts_dir=tmp_path)
        # Should not raise
        storage.delete_batch("nonexistent")


class TestArtifactStorageManifests:
    """Tests for ArtifactStorage manifest operations."""

    def test_save_and_load_batch_manifest(self, tmp_path):
        """ArtifactStorage should save and load batch manifest."""
        from redis_agent_kit.pipelines.artifact_storage import ArtifactStorage
        from redis_agent_kit.pipelines.models import BatchManifest

        storage = ArtifactStorage(artifacts_dir=tmp_path)
        batch_dir, batch_id = storage.create_batch()
        manifest = BatchManifest(
            batch_id=batch_id, batch_date="2025-01-14", documents_prepared=5, chunks_created=25
        )
        storage.save_batch_manifest(batch_id, manifest)
        loaded = storage.load_batch_manifest(batch_id)
        assert loaded is not None
        assert loaded.batch_id == batch_id
        assert loaded.documents_prepared == 5
        assert loaded.chunks_created == 25

    def test_load_batch_manifest_not_found(self, tmp_path):
        """ArtifactStorage should return None for missing manifest."""
        from redis_agent_kit.pipelines.artifact_storage import ArtifactStorage

        storage = ArtifactStorage(artifacts_dir=tmp_path)
        result = storage.load_batch_manifest("nonexistent")
        assert result is None

    def test_load_batch_manifest_batch_exists_no_manifest(self, tmp_path):
        """ArtifactStorage should return None when batch exists but no manifest file."""
        from redis_agent_kit.pipelines.artifact_storage import ArtifactStorage

        storage = ArtifactStorage(artifacts_dir=tmp_path)
        batch_dir, batch_id = storage.create_batch()
        # Batch exists but no manifest saved
        result = storage.load_batch_manifest(batch_id)
        assert result is None

    def test_save_and_load_ingestion_manifest(self, tmp_path):
        """ArtifactStorage should save and load ingestion manifest."""
        from redis_agent_kit.pipelines.artifact_storage import ArtifactStorage
        from redis_agent_kit.pipelines.models import IngestionManifest

        storage = ArtifactStorage(artifacts_dir=tmp_path)
        batch_dir, batch_id = storage.create_batch()
        manifest = IngestionManifest(
            batch_id=batch_id, documents_ingested=5, chunks_embedded=25, status="completed"
        )
        storage.save_ingestion_manifest(batch_id, manifest)
        loaded = storage.load_ingestion_manifest(batch_id)
        assert loaded is not None
        assert loaded.batch_id == batch_id
        assert loaded.documents_ingested == 5
        assert loaded.status == "completed"

    def test_load_ingestion_manifest_not_found(self, tmp_path):
        """ArtifactStorage should return None for missing ingestion manifest."""
        from redis_agent_kit.pipelines.artifact_storage import ArtifactStorage

        storage = ArtifactStorage(artifacts_dir=tmp_path)
        result = storage.load_ingestion_manifest("nonexistent")
        assert result is None

    def test_load_ingestion_manifest_batch_exists_no_manifest(self, tmp_path):
        """ArtifactStorage should return None when batch exists but no ingestion manifest."""
        from redis_agent_kit.pipelines.artifact_storage import ArtifactStorage

        storage = ArtifactStorage(artifacts_dir=tmp_path)
        batch_dir, batch_id = storage.create_batch()
        # Batch exists but no ingestion manifest saved
        result = storage.load_ingestion_manifest(batch_id)
        assert result is None


class TestArtifactStorageDocuments:
    """Tests for ArtifactStorage document operations."""

    def test_save_and_load_documents(self, tmp_path):
        """ArtifactStorage should save and load prepared documents."""
        from redis_agent_kit.pipelines.artifact_storage import ArtifactStorage
        from redis_agent_kit.pipelines.models import Chunk, PreparedDocument

        storage = ArtifactStorage(artifacts_dir=tmp_path)
        batch_dir, batch_id = storage.create_batch()
        chunks = [
            Chunk(chunk_id="doc1_0", doc_id="doc1", content="Chunk 1", chunk_index=0),
            Chunk(chunk_id="doc1_1", doc_id="doc1", content="Chunk 2", chunk_index=1),
        ]
        doc = PreparedDocument(doc_id="doc1", title="Test Doc", source="test.md", chunks=chunks)
        storage.save_document(batch_id, doc)
        loaded = storage.load_documents(batch_id)
        assert len(loaded) == 1
        assert loaded[0].doc_id == "doc1"
        assert len(loaded[0].chunks) == 2

    def test_save_multiple_documents(self, tmp_path):
        """ArtifactStorage should save multiple documents."""
        from redis_agent_kit.pipelines.artifact_storage import ArtifactStorage
        from redis_agent_kit.pipelines.models import PreparedDocument

        storage = ArtifactStorage(artifacts_dir=tmp_path)
        batch_dir, batch_id = storage.create_batch()
        doc1 = PreparedDocument(doc_id="doc1", title="Doc 1", source="doc1.md", chunks=[])
        doc2 = PreparedDocument(doc_id="doc2", title="Doc 2", source="doc2.md", chunks=[])
        storage.save_document(batch_id, doc1)
        storage.save_document(batch_id, doc2)
        loaded = storage.load_documents(batch_id)
        assert len(loaded) == 2

    def test_load_documents_empty_batch(self, tmp_path):
        """ArtifactStorage should return empty list for batch with no documents."""
        import shutil

        from redis_agent_kit.pipelines.artifact_storage import ArtifactStorage

        storage = ArtifactStorage(artifacts_dir=tmp_path)
        batch_dir, batch_id = storage.create_batch()
        # Remove the documents directory to test the edge case
        shutil.rmtree(batch_dir / "documents")
        loaded = storage.load_documents(batch_id)
        assert loaded == []

    def test_load_documents_nonexistent_batch(self, tmp_path):
        """ArtifactStorage should return empty list for non-existent batch."""
        from redis_agent_kit.pipelines.artifact_storage import ArtifactStorage

        storage = ArtifactStorage(artifacts_dir=tmp_path)
        loaded = storage.load_documents("nonexistent")
        assert loaded == []


class TestArtifactStorageCustomDocs:
    """Tests for ArtifactStorage custom document directory."""

    def test_get_custom_docs_dir(self, tmp_path):
        """ArtifactStorage should provide custom docs directory."""
        from redis_agent_kit.pipelines.artifact_storage import ArtifactStorage

        storage = ArtifactStorage(artifacts_dir=tmp_path, custom_docs_dir=tmp_path / "custom")
        custom_dir = storage.get_custom_docs_dir()
        assert custom_dir == tmp_path / "custom"
        assert custom_dir.exists()

    def test_list_custom_docs(self, tmp_path):
        """ArtifactStorage should list markdown files in custom docs dir."""
        from redis_agent_kit.pipelines.artifact_storage import ArtifactStorage

        custom_dir = tmp_path / "custom"
        custom_dir.mkdir()
        (custom_dir / "doc1.md").write_text("# Doc 1")
        (custom_dir / "doc2.md").write_text("# Doc 2")
        (custom_dir / "not_md.txt").write_text("Not markdown")
        storage = ArtifactStorage(artifacts_dir=tmp_path, custom_docs_dir=custom_dir)
        docs = storage.list_custom_docs()
        assert len(docs) == 2
        assert all(d.suffix == ".md" for d in docs)

    def test_list_custom_docs_nonexistent_dir(self, tmp_path):
        """ArtifactStorage should return empty list when custom_docs_dir doesn't exist."""
        from redis_agent_kit.pipelines.artifact_storage import ArtifactStorage

        nonexistent = tmp_path / "nonexistent_custom"
        storage = ArtifactStorage.__new__(ArtifactStorage)
        storage.artifacts_dir = tmp_path
        storage.custom_docs_dir = nonexistent
        docs = storage.list_custom_docs()
        assert docs == []
