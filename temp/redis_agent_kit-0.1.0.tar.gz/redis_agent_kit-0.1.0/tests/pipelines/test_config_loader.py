"""TDD tests for pipeline configuration file loader - written BEFORE implementation."""

from pathlib import Path

import pytest


class TestConfigLoader:
    """Tests for loading pipeline configuration from YAML files."""

    def test_load_config_from_yaml(self, tmp_path):
        """Should load PipelineConfig from pipeline.yaml file."""
        from redis_agent_kit.pipelines.config_loader import load_config

        config_file = tmp_path / "pipeline.yaml"
        config_file.write_text("""
embedding_model: text-embedding-3-small
artifacts_dir: ./artifacts

defaults:
  chunk_size: 1000
  chunk_overlap: 200

sources:
  - name: docs
    path_pattern: "docs/**/*.md"
    chunk_size: 800
""")

        config = load_config(config_file)

        assert config.embedding_model == "text-embedding-3-small"
        assert config.artifacts_dir == Path("./artifacts")
        assert config.defaults.chunk_size == 1000
        assert config.defaults.chunk_overlap == 200
        assert len(config.sources) == 1
        assert config.sources[0].name == "docs"
        assert config.sources[0].path_pattern == "docs/**/*.md"
        assert config.sources[0].chunk_size == 800

    def test_load_config_with_multiple_sources(self, tmp_path):
        """Should load config with multiple source definitions."""
        from redis_agent_kit.pipelines.config_loader import load_config

        config_file = tmp_path / "pipeline.yaml"
        config_file.write_text("""
sources:
  - name: docs
    path_pattern: "docs/**/*.md"
    chunk_size: 800
    doc_type: documentation

  - name: runbooks
    path_pattern: "runbooks/**/*.md"
    chunk_size: 1200
    chunk_overlap: 300
    doc_type: runbook
""")

        config = load_config(config_file)

        assert len(config.sources) == 2
        assert config.sources[0].name == "docs"
        assert config.sources[0].doc_type == "documentation"
        assert config.sources[1].name == "runbooks"
        assert config.sources[1].chunk_size == 1200
        assert config.sources[1].chunk_overlap == 300

    def test_load_config_with_source_metadata(self, tmp_path):
        """Should load config with source-level metadata."""
        from redis_agent_kit.pipelines.config_loader import load_config

        config_file = tmp_path / "pipeline.yaml"
        config_file.write_text("""
sources:
  - name: runbooks
    path_pattern: "runbooks/**/*.md"
    metadata:
      category: operations
      priority: high
""")

        config = load_config(config_file)

        assert config.sources[0].metadata == {"category": "operations", "priority": "high"}

    def test_load_config_file_not_found(self, tmp_path):
        """Should raise FileNotFoundError for missing config file."""
        from redis_agent_kit.pipelines.config_loader import load_config

        with pytest.raises(FileNotFoundError):
            load_config(tmp_path / "nonexistent.yaml")

    def test_load_config_invalid_yaml(self, tmp_path):
        """Should raise ValueError for invalid YAML."""
        from redis_agent_kit.pipelines.config_loader import load_config

        config_file = tmp_path / "pipeline.yaml"
        config_file.write_text("invalid: yaml: content: [")

        with pytest.raises(ValueError, match="Invalid YAML"):
            load_config(config_file)

    def test_load_config_with_custom_docs_dir(self, tmp_path):
        """Should load config with custom_docs_dir."""
        from redis_agent_kit.pipelines.config_loader import load_config

        config_file = tmp_path / "pipeline.yaml"
        config_file.write_text("""
artifacts_dir: ./artifacts
custom_docs_dir: ./artifacts/custom
""")

        config = load_config(config_file)

        assert config.custom_docs_dir == Path("./artifacts/custom")

    def test_load_config_defaults_applied(self, tmp_path):
        """Should apply default values when not specified."""
        from redis_agent_kit.pipelines.config_loader import load_config

        config_file = tmp_path / "pipeline.yaml"
        config_file.write_text("""
sources:
  - name: docs
    path_pattern: "*.md"
""")

        config = load_config(config_file)

        # Should have default values
        assert config.defaults.chunk_size == 1000
        assert config.defaults.chunk_overlap == 200
        assert config.artifacts_dir == Path("artifacts")


class TestFindConfigFile:
    """Tests for finding pipeline.yaml in directory hierarchy."""

    def test_find_config_in_current_dir(self, tmp_path):
        """Should find pipeline.yaml in current directory."""
        from redis_agent_kit.pipelines.config_loader import find_config_file

        config_file = tmp_path / "pipeline.yaml"
        config_file.write_text("sources: []")

        found = find_config_file(tmp_path)

        assert found == config_file

    def test_find_config_in_parent_dir(self, tmp_path):
        """Should find pipeline.yaml in parent directory."""
        from redis_agent_kit.pipelines.config_loader import find_config_file

        config_file = tmp_path / "pipeline.yaml"
        config_file.write_text("sources: []")

        subdir = tmp_path / "subdir"
        subdir.mkdir()

        found = find_config_file(subdir)

        assert found == config_file

    def test_find_config_returns_none_if_not_found(self, tmp_path):
        """Should return None if no config file found."""
        from redis_agent_kit.pipelines.config_loader import find_config_file

        found = find_config_file(tmp_path)

        assert found is None
