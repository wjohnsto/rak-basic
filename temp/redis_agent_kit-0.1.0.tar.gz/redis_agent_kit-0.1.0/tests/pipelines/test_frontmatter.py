"""TDD tests for FrontmatterParser - written BEFORE implementation."""

import pytest


class TestFrontmatterParserParsing:
    """Tests for FrontmatterParser parsing YAML frontmatter."""

    def test_parse_document_with_frontmatter(self):
        """FrontmatterParser should extract frontmatter from markdown."""
        from redis_agent_kit.pipelines.frontmatter import FrontmatterParser

        parser = FrontmatterParser()
        content = "---\ntitle: My Document\npin: true\nchunk_size: 500\n---\n\n# Introduction\n\nThis is the document content.\n"
        frontmatter, body = parser.parse(content)
        assert frontmatter is not None
        assert frontmatter.title == "My Document"
        assert frontmatter.pin is True
        assert frontmatter.chunk_size == 500
        assert body.strip().startswith("# Introduction")

    def test_parse_document_without_frontmatter(self):
        """FrontmatterParser should handle documents without frontmatter."""
        from redis_agent_kit.pipelines.frontmatter import FrontmatterParser

        parser = FrontmatterParser()
        content = "# Just Content\n\nNo frontmatter here.\n"
        frontmatter, body = parser.parse(content)
        assert frontmatter is None
        assert body == content

    def test_parse_empty_frontmatter(self):
        """FrontmatterParser should handle empty frontmatter block."""
        from redis_agent_kit.pipelines.frontmatter import FrontmatterParser

        parser = FrontmatterParser()
        content = "---\n---\n\n# Content\n"
        frontmatter, body = parser.parse(content)
        assert frontmatter is not None  # Empty but valid frontmatter
        assert body.strip() == "# Content"

    def test_parse_frontmatter_with_all_fields(self):
        """FrontmatterParser should parse all supported fields."""
        from redis_agent_kit.pipelines.frontmatter import FrontmatterParser
        from redis_agent_kit.pipelines.models import DocumentType

        parser = FrontmatterParser()
        content = (
            "---\n"
            "title: Full Document\n"
            "pin: true\n"
            "chunk_size: 800\n"
            "chunk_overlap: 150\n"
            "min_chunk_size: 50\n"
            "max_chunks_per_doc: 25\n"
            "category: operations\n"
            "doc_type: runbook\n"
            "tags:\n"
            "  - memory\n"
            "  - troubleshooting\n"
            "metadata:\n"
            "  author: SRE Team\n"
            '  version: "2.0"\n'
            "---\n\n"
            "Content here.\n"
        )
        frontmatter, body = parser.parse(content)
        assert frontmatter is not None
        assert frontmatter.title == "Full Document"
        assert frontmatter.pin is True
        assert frontmatter.chunk_size == 800
        assert frontmatter.chunk_overlap == 150
        assert frontmatter.min_chunk_size == 50
        assert frontmatter.max_chunks_per_doc == 25
        assert frontmatter.category == "operations"
        assert frontmatter.doc_type == DocumentType.RUNBOOK
        assert frontmatter.tags == ["memory", "troubleshooting"]
        assert frontmatter.metadata == {"author": "SRE Team", "version": "2.0"}

    def test_parse_ignores_unknown_fields(self):
        """FrontmatterParser should ignore unknown fields."""
        from redis_agent_kit.pipelines.frontmatter import FrontmatterParser

        parser = FrontmatterParser()
        content = "---\ntitle: Test\nunknown_field: value\nanother_unknown: 123\n---\n\nContent.\n"
        frontmatter, body = parser.parse(content)
        assert frontmatter is not None
        assert frontmatter.title == "Test"

    def test_parse_invalid_yaml(self):
        """FrontmatterParser should handle invalid YAML gracefully."""
        from redis_agent_kit.pipelines.frontmatter import FrontmatterParser

        parser = FrontmatterParser()
        # Invalid YAML: unbalanced brackets
        content = "---\ntitle: [invalid yaml\n---\n\nContent.\n"
        frontmatter, body = parser.parse(content)
        assert frontmatter is None
        assert body == content

    def test_parse_invalid_data_types(self):
        """FrontmatterParser should handle invalid data types gracefully."""
        from redis_agent_kit.pipelines.frontmatter import FrontmatterParser

        parser = FrontmatterParser()
        # pin should be bool, not a list
        content = "---\npin:\n  - item1\n  - item2\n---\n\nContent.\n"
        frontmatter, body = parser.parse(content)
        assert frontmatter is None
        assert body == content

    def test_parse_with_code_block_in_content(self):
        """FrontmatterParser should not confuse code blocks with frontmatter."""
        from redis_agent_kit.pipelines.frontmatter import FrontmatterParser

        parser = FrontmatterParser()
        content = "---\ntitle: Code Example\n---\n\nHere is some code:\n\n```yaml\n---\nkey: value\n---\n```\n\nMore content.\n"
        frontmatter, body = parser.parse(content)
        assert frontmatter is not None
        assert frontmatter.title == "Code Example"
        assert "```yaml" in body
        assert "key: value" in body


class TestFrontmatterParserMerging:
    """Tests for FrontmatterParser config merging."""

    def test_merge_frontmatter_with_source_config(self):
        """Frontmatter should override source config values."""
        from redis_agent_kit.pipelines.frontmatter import FrontmatterParser
        from redis_agent_kit.pipelines.models import DocumentFrontmatter, SourceConfig

        parser = FrontmatterParser()
        source = SourceConfig(name="docs", path_pattern="*.md", chunk_size=1000, chunk_overlap=200)
        frontmatter = DocumentFrontmatter(chunk_size=500)
        merged = parser.merge_config(frontmatter, source)
        assert merged.chunk_size == 500  # From frontmatter
        assert merged.chunk_overlap == 200  # From source

    def test_merge_with_none_frontmatter(self):
        """Merge should return source config when frontmatter is None."""
        from redis_agent_kit.pipelines.frontmatter import FrontmatterParser
        from redis_agent_kit.pipelines.models import SourceConfig

        parser = FrontmatterParser()
        source = SourceConfig(name="docs", path_pattern="*.md", chunk_size=1000, chunk_overlap=200)
        merged = parser.merge_config(None, source)
        assert merged.chunk_size == 1000
        assert merged.chunk_overlap == 200

    def test_merge_all_frontmatter_overrides(self):
        """All frontmatter values should override source config."""
        from redis_agent_kit.pipelines.frontmatter import FrontmatterParser
        from redis_agent_kit.pipelines.models import DocumentFrontmatter, SourceConfig

        parser = FrontmatterParser()
        source = SourceConfig(
            name="docs",
            path_pattern="*.md",
            chunk_size=1000,
            chunk_overlap=200,
            min_chunk_size=100,
            max_chunks_per_doc=50,
        )
        frontmatter = DocumentFrontmatter(
            chunk_size=500, chunk_overlap=100, min_chunk_size=50, max_chunks_per_doc=25
        )
        merged = parser.merge_config(frontmatter, source)
        assert merged.chunk_size == 500
        assert merged.chunk_overlap == 100
        assert merged.min_chunk_size == 50
        assert merged.max_chunks_per_doc == 25

    def test_merge_partial_frontmatter_overrides(self):
        """Partial frontmatter should only override specified values."""
        from redis_agent_kit.pipelines.frontmatter import FrontmatterParser
        from redis_agent_kit.pipelines.models import DocumentFrontmatter, SourceConfig

        parser = FrontmatterParser()
        source = SourceConfig(
            name="docs",
            path_pattern="*.md",
            chunk_size=1000,
            chunk_overlap=200,
            min_chunk_size=100,
            max_chunks_per_doc=50,
        )
        # Only override min_chunk_size and max_chunks_per_doc
        frontmatter = DocumentFrontmatter(min_chunk_size=75, max_chunks_per_doc=30)
        merged = parser.merge_config(frontmatter, source)
        assert merged.chunk_size == 1000  # From source
        assert merged.chunk_overlap == 200  # From source
        assert merged.min_chunk_size == 75  # From frontmatter
        assert merged.max_chunks_per_doc == 30  # From frontmatter


class TestFrontmatterParserFromFile:
    """Tests for FrontmatterParser reading from files."""

    def test_parse_file(self, tmp_path):
        """FrontmatterParser should parse from file path."""
        from redis_agent_kit.pipelines.frontmatter import FrontmatterParser

        parser = FrontmatterParser()
        file_path = tmp_path / "test.md"
        file_path.write_text("---\ntitle: File Test\npin: true\n---\n\n# Content\n")
        frontmatter, body = parser.parse_file(file_path)
        assert frontmatter is not None
        assert frontmatter.title == "File Test"
        assert frontmatter.pin is True
        assert "# Content" in body

    def test_parse_file_not_found(self, tmp_path):
        """FrontmatterParser should raise for missing file."""
        from redis_agent_kit.pipelines.frontmatter import FrontmatterParser

        parser = FrontmatterParser()
        with pytest.raises(FileNotFoundError):
            parser.parse_file(tmp_path / "nonexistent.md")
