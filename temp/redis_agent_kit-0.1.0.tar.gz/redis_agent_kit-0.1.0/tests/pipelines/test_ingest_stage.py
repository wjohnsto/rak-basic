"""TDD tests for IngestStage - written BEFORE implementation."""

from unittest.mock import MagicMock

import pytest


class TestIngestStageBasic:
    """Tests for IngestStage basic functionality."""

    def test_ingest_from_batch(self, tmp_path):
        """IngestStage should ingest documents from a batch."""
        from redis_agent_kit.pipelines.artifact_storage import ArtifactStorage
        from redis_agent_kit.pipelines.ingest_stage import IngestStage
        from redis_agent_kit.pipelines.models import BatchManifest, Chunk, PreparedDocument

        # Set up storage with a prepared batch
        storage = ArtifactStorage(artifacts_dir=tmp_path / "artifacts")
        batch_dir, batch_id = storage.create_batch()

        # Create a prepared document
        chunks = [
            Chunk(chunk_id="doc1_0", doc_id="doc1", content="Test content", chunk_index=0),
        ]
        doc = PreparedDocument(doc_id="doc1", title="Test", source="test.md", chunks=chunks)
        storage.save_document(batch_id, doc)

        # Save batch manifest
        manifest = BatchManifest(
            batch_id=batch_id, batch_date="2025-01-14", documents_prepared=1, chunks_created=1
        )
        storage.save_batch_manifest(batch_id, manifest)

        # Mock vectorizer and vector store
        mock_vectorizer = MagicMock()
        mock_vectorizer.embed.return_value = [0.1] * 768
        mock_vector_store = MagicMock()

        stage = IngestStage(
            storage=storage, vectorizer=mock_vectorizer, vector_store=mock_vector_store
        )
        result = stage.ingest(batch_id)

        assert result is not None
        ingestion_manifest = storage.load_ingestion_manifest(batch_id)
        assert ingestion_manifest is not None
        assert ingestion_manifest.documents_ingested == 1
        assert ingestion_manifest.chunks_embedded == 1
        assert ingestion_manifest.status == "completed"

    def test_ingest_multiple_documents(self, tmp_path):
        """IngestStage should ingest multiple documents."""
        from redis_agent_kit.pipelines.artifact_storage import ArtifactStorage
        from redis_agent_kit.pipelines.ingest_stage import IngestStage
        from redis_agent_kit.pipelines.models import BatchManifest, Chunk, PreparedDocument

        storage = ArtifactStorage(artifacts_dir=tmp_path / "artifacts")
        batch_dir, batch_id = storage.create_batch()

        # Create multiple documents
        for i in range(3):
            chunks = [
                Chunk(chunk_id=f"doc{i}_0", doc_id=f"doc{i}", content=f"Content {i}", chunk_index=0)
            ]
            doc = PreparedDocument(
                doc_id=f"doc{i}", title=f"Doc {i}", source=f"doc{i}.md", chunks=chunks
            )
            storage.save_document(batch_id, doc)

        manifest = BatchManifest(
            batch_id=batch_id, batch_date="2025-01-14", documents_prepared=3, chunks_created=3
        )
        storage.save_batch_manifest(batch_id, manifest)

        mock_vectorizer = MagicMock()
        mock_vectorizer.embed.return_value = [0.1] * 768
        mock_vector_store = MagicMock()

        stage = IngestStage(
            storage=storage, vectorizer=mock_vectorizer, vector_store=mock_vector_store
        )
        stage.ingest(batch_id)

        ingestion_manifest = storage.load_ingestion_manifest(batch_id)
        assert ingestion_manifest.documents_ingested == 3
        assert ingestion_manifest.chunks_embedded == 3

    def test_ingest_nonexistent_batch(self, tmp_path):
        """IngestStage should raise error for non-existent batch."""
        from redis_agent_kit.pipelines.artifact_storage import ArtifactStorage
        from redis_agent_kit.pipelines.ingest_stage import IngestStage

        storage = ArtifactStorage(artifacts_dir=tmp_path / "artifacts")
        mock_vectorizer = MagicMock()
        mock_vector_store = MagicMock()

        stage = IngestStage(
            storage=storage, vectorizer=mock_vectorizer, vector_store=mock_vector_store
        )

        with pytest.raises(ValueError, match="Batch .* not found"):
            stage.ingest("nonexistent")

    def test_ingest_missing_manifest(self, tmp_path):
        """IngestStage should raise error when batch manifest is missing."""
        from redis_agent_kit.pipelines.artifact_storage import ArtifactStorage
        from redis_agent_kit.pipelines.ingest_stage import IngestStage

        storage = ArtifactStorage(artifacts_dir=tmp_path / "artifacts")
        # Create batch directory but no manifest
        batch_dir, batch_id = storage.create_batch()

        mock_vectorizer = MagicMock()
        mock_vector_store = MagicMock()

        stage = IngestStage(
            storage=storage, vectorizer=mock_vectorizer, vector_store=mock_vector_store
        )

        with pytest.raises(ValueError, match="Batch manifest .* not found"):
            stage.ingest(batch_id)

    def test_ingest_empty_batch(self, tmp_path):
        """IngestStage should handle empty batch."""
        from redis_agent_kit.pipelines.artifact_storage import ArtifactStorage
        from redis_agent_kit.pipelines.ingest_stage import IngestStage
        from redis_agent_kit.pipelines.models import BatchManifest

        storage = ArtifactStorage(artifacts_dir=tmp_path / "artifacts")
        batch_dir, batch_id = storage.create_batch()
        manifest = BatchManifest(
            batch_id=batch_id, batch_date="2025-01-14", documents_prepared=0, chunks_created=0
        )
        storage.save_batch_manifest(batch_id, manifest)

        mock_vectorizer = MagicMock()
        mock_vector_store = MagicMock()

        stage = IngestStage(
            storage=storage, vectorizer=mock_vectorizer, vector_store=mock_vector_store
        )
        stage.ingest(batch_id)

        ingestion_manifest = storage.load_ingestion_manifest(batch_id)
        assert ingestion_manifest.documents_ingested == 0
        assert ingestion_manifest.chunks_embedded == 0
        assert ingestion_manifest.status == "completed"


class TestIngestStageVectorStore:
    """Tests for IngestStage vector store interactions."""

    def test_ingest_stores_chunks_with_embeddings(self, tmp_path):
        """IngestStage should store chunks with embeddings in vector store."""
        from redis_agent_kit.pipelines.artifact_storage import ArtifactStorage
        from redis_agent_kit.pipelines.ingest_stage import IngestStage
        from redis_agent_kit.pipelines.models import BatchManifest, Chunk, PreparedDocument

        storage = ArtifactStorage(artifacts_dir=tmp_path / "artifacts")
        batch_dir, batch_id = storage.create_batch()

        chunks = [
            Chunk(chunk_id="doc1_0", doc_id="doc1", content="Test content", chunk_index=0),
            Chunk(chunk_id="doc1_1", doc_id="doc1", content="More content", chunk_index=1),
        ]
        doc = PreparedDocument(doc_id="doc1", title="Test", source="test.md", chunks=chunks)
        storage.save_document(batch_id, doc)

        manifest = BatchManifest(
            batch_id=batch_id, batch_date="2025-01-14", documents_prepared=1, chunks_created=2
        )
        storage.save_batch_manifest(batch_id, manifest)

        mock_vectorizer = MagicMock()
        mock_vectorizer.embed_sync.return_value = [0.1] * 768
        mock_vector_store = MagicMock()

        stage = IngestStage(
            storage=storage, vectorizer=mock_vectorizer, vector_store=mock_vector_store
        )
        stage.ingest(batch_id)

        # Verify vectorizer was called for each chunk
        assert mock_vectorizer.embed_sync.call_count == 2
        # Verify vector store was called to store chunks
        assert mock_vector_store.store_chunk_sync.call_count == 2
