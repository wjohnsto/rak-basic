"""TDD tests for pipeline models - written BEFORE implementation."""

import hashlib
from datetime import UTC, datetime

import pytest


class TestDocumentType:
    """Tests for DocumentType enum."""

    def test_document_type_values(self):
        """DocumentType should have expected values."""
        from redis_agent_kit.pipelines.models import DocumentType

        assert DocumentType.DOCUMENTATION == "documentation"
        assert DocumentType.BLOG_POST == "blog_post"
        assert DocumentType.RUNBOOK == "runbook"
        assert DocumentType.TUTORIAL == "tutorial"
        assert DocumentType.REFERENCE == "reference"
        assert DocumentType.API_DOC == "api_doc"
        assert DocumentType.OTHER == "other"

    def test_document_type_is_string_enum(self):
        """DocumentType values should be usable as strings."""
        from redis_agent_kit.pipelines.models import DocumentType

        # Use .value for string interpolation
        assert f"type:{DocumentType.DOCUMENTATION.value}" == "type:documentation"
        # Direct comparison works due to str inheritance
        assert DocumentType.DOCUMENTATION == "documentation"


class TestDocument:
    """Tests for Document model."""

    def test_document_creation_with_required_fields(self):
        """Document should be creatable with required fields."""
        from redis_agent_kit.pipelines.models import Document

        doc = Document(
            title="Test Doc",
            content="This is test content.",
            source="https://example.com/doc",
        )
        assert doc.title == "Test Doc"
        assert doc.content == "This is test content."
        assert doc.source == "https://example.com/doc"

    def test_document_auto_generates_doc_id_from_content_hash(self):
        """Document should auto-generate doc_id from content hash."""
        from redis_agent_kit.pipelines.models import Document

        content = "This is test content."
        doc = Document(
            title="Test Doc",
            content=content,
            source="https://example.com/doc",
        )
        expected_hash = hashlib.sha256(content.encode()).hexdigest()[:16]
        assert doc.doc_id == expected_hash

    def test_document_with_explicit_doc_id(self):
        """Document should accept explicit doc_id."""
        from redis_agent_kit.pipelines.models import Document

        doc = Document(
            doc_id="custom-id",
            title="Test Doc",
            content="Content",
            source="https://example.com",
        )
        assert doc.doc_id == "custom-id"

    def test_document_default_type_is_other(self):
        """Document should default to OTHER type."""
        from redis_agent_kit.pipelines.models import Document, DocumentType

        doc = Document(
            title="Test",
            content="Content",
            source="https://example.com",
        )
        assert doc.doc_type == DocumentType.OTHER

    def test_document_with_metadata(self):
        """Document should accept metadata dict."""
        from redis_agent_kit.pipelines.models import Document

        doc = Document(
            title="Test",
            content="Content",
            source="https://example.com",
            metadata={"author": "John", "version": "1.0"},
        )
        assert doc.metadata == {"author": "John", "version": "1.0"}

    def test_document_auto_sets_created_at(self):
        """Document should auto-set created_at if not provided."""
        from redis_agent_kit.pipelines.models import Document

        before = datetime.now(UTC)
        doc = Document(
            title="Test",
            content="Content",
            source="https://example.com",
        )
        after = datetime.now(UTC)
        assert before <= doc.created_at <= after

    def test_document_serialization(self):
        """Document should serialize to dict."""
        from redis_agent_kit.pipelines.models import Document

        doc = Document(
            title="Test",
            content="Content",
            source="https://example.com",
        )
        data = doc.model_dump()
        assert "doc_id" in data
        assert data["title"] == "Test"
        assert data["content"] == "Content"


class TestChunk:
    """Tests for Chunk model."""

    def test_chunk_creation(self):
        """Chunk should be creatable with required fields."""
        from redis_agent_kit.pipelines.models import Chunk

        chunk = Chunk(
            chunk_id="doc123_0",
            doc_id="doc123",
            content="Chunk content here.",
            chunk_index=0,
        )
        assert chunk.chunk_id == "doc123_0"
        assert chunk.doc_id == "doc123"
        assert chunk.content == "Chunk content here."
        assert chunk.chunk_index == 0

    def test_chunk_with_metadata(self):
        """Chunk should accept metadata."""
        from redis_agent_kit.pipelines.models import Chunk

        chunk = Chunk(
            chunk_id="doc123_0",
            doc_id="doc123",
            content="Content",
            chunk_index=0,
            metadata={"source_title": "Test Doc"},
        )
        assert chunk.metadata == {"source_title": "Test Doc"}

    def test_chunk_default_empty_metadata(self):
        """Chunk should default to empty metadata."""
        from redis_agent_kit.pipelines.models import Chunk

        chunk = Chunk(
            chunk_id="doc123_0",
            doc_id="doc123",
            content="Content",
            chunk_index=0,
        )
        assert chunk.metadata == {}


class TestProcessorConfig:
    """Tests for ProcessorConfig model."""

    def test_processor_config_defaults(self):
        """ProcessorConfig should have sensible defaults."""
        from redis_agent_kit.pipelines.models import ProcessorConfig

        config = ProcessorConfig()
        assert config.chunk_size == 1000
        assert config.chunk_overlap == 200
        assert config.min_chunk_size == 100
        assert config.max_chunks_per_doc == 50
        assert config.strip_front_matter is True

    def test_processor_config_custom_values(self):
        """ProcessorConfig should accept custom values."""
        from redis_agent_kit.pipelines.models import ProcessorConfig

        config = ProcessorConfig(
            chunk_size=500,
            chunk_overlap=100,
            min_chunk_size=50,
            max_chunks_per_doc=100,
            strip_front_matter=False,
        )
        assert config.chunk_size == 500
        assert config.chunk_overlap == 100
        assert config.min_chunk_size == 50
        assert config.max_chunks_per_doc == 100
        assert config.strip_front_matter is False

    def test_processor_config_validation_overlap_less_than_size(self):
        """ProcessorConfig should validate overlap < chunk_size."""
        from redis_agent_kit.pipelines.models import ProcessorConfig

        with pytest.raises(ValueError):
            ProcessorConfig(chunk_size=100, chunk_overlap=150)


class TestPipelineResult:
    """Tests for PipelineResult model."""

    def test_pipeline_result_creation(self):
        """PipelineResult should be creatable."""
        from redis_agent_kit.pipelines.models import PipelineResult

        result = PipelineResult(
            pipeline_id="pipe123",
            started_at=datetime.now(UTC),
        )
        assert result.pipeline_id == "pipe123"
        assert result.documents_processed == 0
        assert result.chunks_created == 0
        assert result.errors == []
        assert result.status == "running"

    def test_pipeline_result_completed(self):
        """PipelineResult should track completion."""
        from redis_agent_kit.pipelines.models import PipelineResult

        started = datetime.now(UTC)
        completed = datetime.now(UTC)
        result = PipelineResult(
            pipeline_id="pipe123",
            started_at=started,
            completed_at=completed,
            documents_processed=10,
            chunks_created=50,
            status="completed",
        )
        assert result.completed_at == completed
        assert result.documents_processed == 10
        assert result.chunks_created == 50
        assert result.status == "completed"

    def test_pipeline_result_with_errors(self):
        """PipelineResult should track errors."""
        from redis_agent_kit.pipelines.models import PipelineResult

        result = PipelineResult(
            pipeline_id="pipe123",
            started_at=datetime.now(UTC),
            errors=["Failed to process doc1", "Failed to process doc2"],
            status="failed",
        )
        assert len(result.errors) == 2
        assert result.status == "failed"


# =============================================================================
# Phase 6: Two-Stage Pipeline Models
# =============================================================================


class TestSourceConfig:
    """Tests for SourceConfig model - per-source pipeline configuration."""

    def test_source_config_creation(self):
        """SourceConfig should be creatable with required fields."""
        from redis_agent_kit.pipelines.models import SourceConfig

        config = SourceConfig(
            name="docs",
            path_pattern="docs/**/*.md",
        )
        assert config.name == "docs"
        assert config.path_pattern == "docs/**/*.md"

    def test_source_config_defaults(self):
        """SourceConfig should have sensible defaults."""
        from redis_agent_kit.pipelines.models import DocumentType, SourceConfig

        config = SourceConfig(name="docs", path_pattern="*.md")
        assert config.chunk_size == 1000
        assert config.chunk_overlap == 200
        assert config.min_chunk_size == 100
        assert config.max_chunks_per_doc == 50
        assert config.doc_type == DocumentType.OTHER
        assert config.metadata == {}

    def test_source_config_custom_values(self):
        """SourceConfig should accept custom values."""
        from redis_agent_kit.pipelines.models import DocumentType, SourceConfig

        config = SourceConfig(
            name="runbooks",
            path_pattern="runbooks/**/*.md",
            chunk_size=1200,
            chunk_overlap=300,
            min_chunk_size=200,
            max_chunks_per_doc=100,
            doc_type=DocumentType.RUNBOOK,
            metadata={"category": "operations"},
        )
        assert config.chunk_size == 1200
        assert config.chunk_overlap == 300
        assert config.min_chunk_size == 200
        assert config.max_chunks_per_doc == 100
        assert config.doc_type == DocumentType.RUNBOOK
        assert config.metadata == {"category": "operations"}

    def test_source_config_validation_overlap_less_than_size(self):
        """SourceConfig should validate overlap < chunk_size."""
        from redis_agent_kit.pipelines.models import SourceConfig

        with pytest.raises(ValueError):
            SourceConfig(
                name="docs",
                path_pattern="*.md",
                chunk_size=100,
                chunk_overlap=150,
            )

    def test_source_config_to_processor_config(self):
        """SourceConfig should convert to ProcessorConfig."""
        from redis_agent_kit.pipelines.models import SourceConfig

        source = SourceConfig(
            name="docs",
            path_pattern="*.md",
            chunk_size=500,
            chunk_overlap=100,
            min_chunk_size=50,
            max_chunks_per_doc=25,
        )
        proc_config = source.to_processor_config()
        assert proc_config.chunk_size == 500
        assert proc_config.chunk_overlap == 100
        assert proc_config.min_chunk_size == 50
        assert proc_config.max_chunks_per_doc == 25


class TestPipelineConfig:
    """Tests for PipelineConfig model - full pipeline configuration."""

    def test_pipeline_config_creation(self):
        """PipelineConfig should be creatable with sources."""
        from pathlib import Path

        from redis_agent_kit.pipelines.models import PipelineConfig, SourceConfig

        config = PipelineConfig(
            sources=[
                SourceConfig(name="docs", path_pattern="docs/**/*.md"),
            ],
        )
        assert len(config.sources) == 1
        assert config.sources[0].name == "docs"
        assert config.artifacts_dir == Path("artifacts")
        assert config.custom_docs_dir == Path("artifacts/custom")

    def test_pipeline_config_defaults(self):
        """PipelineConfig should have sensible defaults."""
        from pathlib import Path

        from redis_agent_kit.pipelines.models import PipelineConfig

        config = PipelineConfig(sources=[])
        assert config.default_chunk_size == 1000
        assert config.default_chunk_overlap == 200
        assert config.embedding_model == "text-embedding-3-small"
        assert config.artifacts_dir == Path("artifacts")
        assert config.custom_docs_dir == Path("artifacts/custom")

    def test_pipeline_config_custom_paths(self):
        """PipelineConfig should accept custom paths."""
        from pathlib import Path

        from redis_agent_kit.pipelines.models import PipelineConfig

        config = PipelineConfig(
            sources=[],
            artifacts_dir=Path("/data/artifacts"),
            custom_docs_dir=Path("/data/custom"),
        )
        assert config.artifacts_dir == Path("/data/artifacts")
        assert config.custom_docs_dir == Path("/data/custom")

    def test_pipeline_config_get_source_by_name(self):
        """PipelineConfig should find source by name."""
        from redis_agent_kit.pipelines.models import PipelineConfig, SourceConfig

        config = PipelineConfig(
            sources=[
                SourceConfig(name="docs", path_pattern="docs/**/*.md"),
                SourceConfig(name="runbooks", path_pattern="runbooks/**/*.md"),
            ],
        )
        source = config.get_source("docs")
        assert source is not None
        assert source.name == "docs"

        missing = config.get_source("nonexistent")
        assert missing is None


class TestDocumentFrontmatter:
    """Tests for DocumentFrontmatter model - YAML frontmatter options."""

    def test_frontmatter_defaults(self):
        """DocumentFrontmatter should have correct defaults."""
        from redis_agent_kit.pipelines.models import DocumentFrontmatter

        fm = DocumentFrontmatter()
        assert fm.title is None
        assert fm.pin is False
        assert fm.chunk_size is None
        assert fm.chunk_overlap is None
        assert fm.min_chunk_size is None
        assert fm.max_chunks_per_doc is None
        assert fm.category is None
        assert fm.doc_type is None
        assert fm.tags == []
        assert fm.metadata == {}

    def test_frontmatter_with_values(self):
        """DocumentFrontmatter should accept all options."""
        from redis_agent_kit.pipelines.models import DocumentFrontmatter, DocumentType

        fm = DocumentFrontmatter(
            title="My Document",
            pin=True,
            chunk_size=500,
            chunk_overlap=100,
            min_chunk_size=50,
            max_chunks_per_doc=25,
            category="operations",
            doc_type=DocumentType.RUNBOOK,
            tags=["memory", "troubleshooting"],
            metadata={"author": "SRE Team", "version": "2.0"},
        )
        assert fm.title == "My Document"
        assert fm.pin is True
        assert fm.chunk_size == 500
        assert fm.chunk_overlap == 100
        assert fm.min_chunk_size == 50
        assert fm.max_chunks_per_doc == 25
        assert fm.category == "operations"
        assert fm.doc_type == DocumentType.RUNBOOK
        assert fm.tags == ["memory", "troubleshooting"]
        assert fm.metadata == {"author": "SRE Team", "version": "2.0"}

    def test_frontmatter_from_dict(self):
        """DocumentFrontmatter should parse from dict (as from YAML)."""
        from redis_agent_kit.pipelines.models import DocumentFrontmatter

        data = {
            "title": "Test",
            "pin": True,
            "chunk_size": 600,
            "tags": ["tag1", "tag2"],
        }
        fm = DocumentFrontmatter.model_validate(data)
        assert fm.title == "Test"
        assert fm.pin is True
        assert fm.chunk_size == 600
        assert fm.tags == ["tag1", "tag2"]


class TestPreparedDocument:
    """Tests for PreparedDocument model - document with chunks ready for ingestion."""

    def test_prepared_document_creation(self):
        """PreparedDocument should store document with its chunks."""
        from redis_agent_kit.pipelines.models import (
            Chunk,
            PreparedDocument,
        )

        chunks = [
            Chunk(chunk_id="doc1_0", doc_id="doc1", content="Chunk 1", chunk_index=0),
            Chunk(chunk_id="doc1_1", doc_id="doc1", content="Chunk 2", chunk_index=1),
        ]
        prepared = PreparedDocument(
            doc_id="doc1",
            title="Test Doc",
            source="test.md",
            chunks=chunks,
        )
        assert prepared.doc_id == "doc1"
        assert prepared.title == "Test Doc"
        assert prepared.source == "test.md"
        assert len(prepared.chunks) == 2

    def test_prepared_document_with_frontmatter(self):
        """PreparedDocument should store frontmatter."""
        from redis_agent_kit.pipelines.models import (
            DocumentFrontmatter,
            PreparedDocument,
        )

        fm = DocumentFrontmatter(title="Custom Title", pin=True)
        prepared = PreparedDocument(
            doc_id="doc1",
            title="Test Doc",
            source="test.md",
            chunks=[],
            frontmatter=fm,
        )
        assert prepared.frontmatter is not None
        assert prepared.frontmatter.pin is True

    def test_prepared_document_with_metadata(self):
        """PreparedDocument should store metadata."""
        from redis_agent_kit.pipelines.models import PreparedDocument

        prepared = PreparedDocument(
            doc_id="doc1",
            title="Test Doc",
            source="test.md",
            chunks=[],
            metadata={"category": "ops"},
        )
        assert prepared.metadata == {"category": "ops"}


class TestBatchManifest:
    """Tests for BatchManifest model - prepare stage manifest."""

    def test_batch_manifest_creation(self):
        """BatchManifest should be creatable with required fields."""
        from redis_agent_kit.pipelines.models import BatchManifest

        manifest = BatchManifest(
            batch_id="01HQXYZ",
            batch_date="2025-01-14",
        )
        assert manifest.batch_id == "01HQXYZ"
        assert manifest.batch_date == "2025-01-14"

    def test_batch_manifest_defaults(self):
        """BatchManifest should have sensible defaults."""
        from redis_agent_kit.pipelines.models import BatchManifest

        manifest = BatchManifest(
            batch_id="01HQXYZ",
            batch_date="2025-01-14",
        )
        assert manifest.documents_prepared == 0
        assert manifest.chunks_created == 0
        assert manifest.status == "preparing"
        assert manifest.source_configs == []

    def test_batch_manifest_with_progress(self):
        """BatchManifest should track progress."""
        from redis_agent_kit.pipelines.models import BatchManifest, SourceConfig

        manifest = BatchManifest(
            batch_id="01HQXYZ",
            batch_date="2025-01-14",
            source_configs=[
                SourceConfig(name="docs", path_pattern="docs/**/*.md"),
            ],
            documents_prepared=10,
            chunks_created=50,
            status="ready",
        )
        assert manifest.documents_prepared == 10
        assert manifest.chunks_created == 50
        assert manifest.status == "ready"
        assert len(manifest.source_configs) == 1

    def test_batch_manifest_statuses(self):
        """BatchManifest should support all status values."""
        from redis_agent_kit.pipelines.models import BatchManifest

        for status in ["preparing", "ready", "ingesting", "ingested", "failed"]:
            manifest = BatchManifest(
                batch_id="01HQXYZ",
                batch_date="2025-01-14",
                status=status,
            )
            assert manifest.status == status


class TestIngestionManifest:
    """Tests for IngestionManifest model - ingest stage manifest."""

    def test_ingestion_manifest_creation(self):
        """IngestionManifest should be creatable with batch_id."""
        from redis_agent_kit.pipelines.models import IngestionManifest

        manifest = IngestionManifest(batch_id="01HQXYZ")
        assert manifest.batch_id == "01HQXYZ"

    def test_ingestion_manifest_defaults(self):
        """IngestionManifest should have sensible defaults."""
        from redis_agent_kit.pipelines.models import IngestionManifest

        manifest = IngestionManifest(batch_id="01HQXYZ")
        assert manifest.ingestion_started_at is None
        assert manifest.ingestion_completed_at is None
        assert manifest.documents_ingested == 0
        assert manifest.chunks_embedded == 0
        assert manifest.status == "pending"
        assert manifest.errors == []

    def test_ingestion_manifest_in_progress(self):
        """IngestionManifest should track in-progress state."""
        from redis_agent_kit.pipelines.models import IngestionManifest

        started = datetime.now(UTC)
        manifest = IngestionManifest(
            batch_id="01HQXYZ",
            ingestion_started_at=started,
            status="in_progress",
        )
        assert manifest.ingestion_started_at == started
        assert manifest.status == "in_progress"

    def test_ingestion_manifest_completed(self):
        """IngestionManifest should track completion."""
        from redis_agent_kit.pipelines.models import IngestionManifest

        started = datetime.now(UTC)
        completed = datetime.now(UTC)
        manifest = IngestionManifest(
            batch_id="01HQXYZ",
            ingestion_started_at=started,
            ingestion_completed_at=completed,
            documents_ingested=10,
            chunks_embedded=50,
            status="completed",
        )
        assert manifest.documents_ingested == 10
        assert manifest.chunks_embedded == 50
        assert manifest.status == "completed"

    def test_ingestion_manifest_with_errors(self):
        """IngestionManifest should track errors."""
        from redis_agent_kit.pipelines.models import IngestionManifest

        manifest = IngestionManifest(
            batch_id="01HQXYZ",
            status="failed",
            errors=["Embedding API error", "Redis connection lost"],
        )
        assert manifest.status == "failed"
        assert len(manifest.errors) == 2


class TestChunkingDefaults:
    """Tests for ChunkingDefaults model."""

    def test_chunking_defaults_creation(self):
        """ChunkingDefaults should be creatable with default values."""
        from redis_agent_kit.pipelines.models import ChunkingDefaults

        defaults = ChunkingDefaults()
        assert defaults.chunk_size == 1000
        assert defaults.chunk_overlap == 200
        assert defaults.min_chunk_size == 100
        assert defaults.max_chunks_per_doc == 50

    def test_chunking_defaults_custom_values(self):
        """ChunkingDefaults should accept custom values."""
        from redis_agent_kit.pipelines.models import ChunkingDefaults

        defaults = ChunkingDefaults(
            chunk_size=500,
            chunk_overlap=100,
            min_chunk_size=50,
            max_chunks_per_doc=25,
        )
        assert defaults.chunk_size == 500
        assert defaults.chunk_overlap == 100
        assert defaults.min_chunk_size == 50
        assert defaults.max_chunks_per_doc == 25
