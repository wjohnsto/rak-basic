"""Tests for A2A protocol adapter."""
