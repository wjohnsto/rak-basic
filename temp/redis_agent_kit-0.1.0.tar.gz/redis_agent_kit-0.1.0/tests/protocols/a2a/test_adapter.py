"""Tests for A2A protocol adapter."""

from redis_agent_kit.models import AgentCard, Message, Skill, TaskState, TaskStatus
from redis_agent_kit.protocols.a2a.adapter import A2AAdapter
from redis_agent_kit.protocols.a2a.models import (
    A2AMessage,
    A2ATask,
    A2ATaskState,
    TextPart,
)


class TestA2AAdapterStatusMapping:
    """Tests for A2A status mapping."""

    def test_status_to_a2a(self):
        """Map RAK TaskStatus to A2A TaskState."""
        adapter = A2AAdapter(
            agent_card=AgentCard(name="Test", description="Test", url="http://test")
        )
        assert adapter.map_status_to_a2a(TaskStatus.QUEUED) == A2ATaskState.SUBMITTED
        assert adapter.map_status_to_a2a(TaskStatus.IN_PROGRESS) == A2ATaskState.WORKING
        assert adapter.map_status_to_a2a(TaskStatus.AWAITING_INPUT) == A2ATaskState.INPUT_REQUIRED
        assert adapter.map_status_to_a2a(TaskStatus.DONE) == A2ATaskState.COMPLETED
        assert adapter.map_status_to_a2a(TaskStatus.FAILED) == A2ATaskState.FAILED
        assert adapter.map_status_to_a2a(TaskStatus.CANCELLED) == A2ATaskState.CANCELED

    def test_status_from_a2a(self):
        """Map A2A TaskState to RAK TaskStatus."""
        adapter = A2AAdapter(
            agent_card=AgentCard(name="Test", description="Test", url="http://test")
        )
        assert adapter.map_status_from_a2a(A2ATaskState.SUBMITTED) == TaskStatus.QUEUED
        assert adapter.map_status_from_a2a(A2ATaskState.WORKING) == TaskStatus.IN_PROGRESS
        assert adapter.map_status_from_a2a(A2ATaskState.INPUT_REQUIRED) == TaskStatus.AWAITING_INPUT
        assert adapter.map_status_from_a2a(A2ATaskState.COMPLETED) == TaskStatus.DONE
        assert adapter.map_status_from_a2a(A2ATaskState.FAILED) == TaskStatus.FAILED
        assert adapter.map_status_from_a2a(A2ATaskState.CANCELED) == TaskStatus.CANCELLED


class TestA2AAdapterTaskConversion:
    """Tests for task conversion."""

    def test_to_protocol_task(self):
        """Convert RAK TaskState to A2A Task."""
        adapter = A2AAdapter(
            agent_card=AgentCard(name="Test", description="Test", url="http://test")
        )
        rak_task = TaskState(
            task_id="task-123",
            session_id="thread-456",
            status=TaskStatus.IN_PROGRESS,
        )
        a2a_task = adapter.to_protocol_task(rak_task)
        assert isinstance(a2a_task, A2ATask)
        assert a2a_task.id == "task-123"
        assert a2a_task.context_id == "thread-456"
        assert a2a_task.status.state == A2ATaskState.WORKING

    def test_to_protocol_task_with_result(self):
        """Convert completed task with result to A2A Task with artifacts."""
        adapter = A2AAdapter(
            agent_card=AgentCard(name="Test", description="Test", url="http://test")
        )
        rak_task = TaskState(
            task_id="task-123",
            session_id="thread-456",
            status=TaskStatus.DONE,
            result={"response": "Hello!"},
        )
        a2a_task = adapter.to_protocol_task(rak_task)
        assert a2a_task.status.state == A2ATaskState.COMPLETED
        assert len(a2a_task.artifacts) == 1
        assert a2a_task.artifacts[0].parts[0].text == '{"response": "Hello!"}'

    def test_to_protocol_task_with_error(self):
        """Convert failed task with error message."""
        adapter = A2AAdapter(
            agent_card=AgentCard(name="Test", description="Test", url="http://test")
        )
        rak_task = TaskState(
            task_id="task-123",
            session_id="thread-456",
            status=TaskStatus.FAILED,
            error_message="Something went wrong",
        )
        a2a_task = adapter.to_protocol_task(rak_task)
        assert a2a_task.status.state == A2ATaskState.FAILED
        assert a2a_task.status.message == "Something went wrong"


class TestA2AAdapterMessageConversion:
    """Tests for message conversion."""

    def test_from_protocol_message(self):
        """Convert A2A Message to RAK Message."""
        adapter = A2AAdapter(
            agent_card=AgentCard(name="Test", description="Test", url="http://test")
        )
        a2a_msg = A2AMessage(
            role="user",
            parts=[TextPart(text="Hello, agent!")],
        )
        rak_msg = adapter.from_protocol_message(a2a_msg)
        assert isinstance(rak_msg, Message)
        assert rak_msg.role == "user"
        assert rak_msg.content == "Hello, agent!"

    def test_from_protocol_message_multiple_parts(self):
        """Convert A2A Message with multiple text parts."""
        adapter = A2AAdapter(
            agent_card=AgentCard(name="Test", description="Test", url="http://test")
        )
        a2a_msg = A2AMessage(
            role="user",
            parts=[
                TextPart(text="Part 1. "),
                TextPart(text="Part 2."),
            ],
        )
        rak_msg = adapter.from_protocol_message(a2a_msg)
        assert rak_msg.content == "Part 1. Part 2."

    def test_to_protocol_message(self):
        """Convert RAK Message to A2A Message."""
        adapter = A2AAdapter(
            agent_card=AgentCard(name="Test", description="Test", url="http://test")
        )
        rak_msg = Message(role="assistant", content="Hello!")
        a2a_msg = adapter.to_protocol_message(rak_msg)
        assert isinstance(a2a_msg, A2AMessage)
        assert a2a_msg.role == "agent"  # assistant -> agent
        assert len(a2a_msg.parts) == 1
        assert a2a_msg.parts[0].text == "Hello!"


class TestA2AAdapterDiscovery:
    """Tests for agent card discovery."""

    def test_get_discovery_document(self):
        """Get agent card as discovery document."""
        card = AgentCard(
            name="My Agent",
            description="A helpful assistant",
            url="https://agent.example.com",
            skills=[Skill(id="chat", name="Chat", description="General chat")],
            capabilities={"streaming": True},
        )
        adapter = A2AAdapter(agent_card=card)
        doc = adapter.get_discovery_document()
        assert doc["name"] == "My Agent"
        assert doc["description"] == "A helpful assistant"
        assert doc["url"] == "https://agent.example.com"
        assert len(doc["skills"]) == 1
        assert doc["capabilities"]["streaming"] is True
