"""Tests for A2A protocol models."""

from redis_agent_kit.protocols.a2a.models import (
    A2AArtifact,
    A2AMessage,
    A2APart,
    A2ATaskState,
    A2ATaskStatus,
    DataPart,
    FilePart,
    TextPart,
)


class TestA2ATaskState:
    """Tests for A2ATaskState enum."""

    def test_all_states_exist(self):
        """Verify all A2A task states are defined."""
        assert A2ATaskState.SUBMITTED == "submitted"
        assert A2ATaskState.WORKING == "working"
        assert A2ATaskState.INPUT_REQUIRED == "input-required"
        assert A2ATaskState.COMPLETED == "completed"
        assert A2ATaskState.FAILED == "failed"
        assert A2ATaskState.CANCELED == "canceled"


class TestTextPart:
    """Tests for TextPart model."""

    def test_create_text_part(self):
        """Create a text part."""
        part = TextPart(text="Hello, world!")
        assert part.type == "text"
        assert part.text == "Hello, world!"

    def test_text_part_metadata(self):
        """Text part can have metadata."""
        part = TextPart(text="Hello", metadata={"lang": "en"})
        assert part.metadata == {"lang": "en"}


class TestFilePart:
    """Tests for FilePart model."""

    def test_create_file_part_with_bytes(self):
        """Create a file part with inline bytes."""
        part = FilePart(
            name="document.pdf",
            media_type="application/pdf",
            bytes="base64encodedcontent",
        )
        assert part.type == "file"
        assert part.name == "document.pdf"
        assert part.media_type == "application/pdf"
        assert part.bytes == "base64encodedcontent"
        assert part.uri is None

    def test_create_file_part_with_uri(self):
        """Create a file part with URI reference."""
        part = FilePart(
            name="image.png",
            media_type="image/png",
            uri="https://example.com/image.png",
        )
        assert part.uri == "https://example.com/image.png"
        assert part.bytes is None


class TestDataPart:
    """Tests for DataPart model."""

    def test_create_data_part(self):
        """Create a data part with structured JSON."""
        part = DataPart(data={"key": "value", "count": 42})
        assert part.type == "data"
        assert part.data == {"key": "value", "count": 42}


class TestA2APart:
    """Tests for A2APart union type."""

    def test_parse_text_part(self):
        """Parse a text part from dict."""
        data = {"type": "text", "text": "Hello"}
        part = A2APart.model_validate(data)
        assert isinstance(part.root, TextPart)
        assert part.root.text == "Hello"

    def test_parse_file_part(self):
        """Parse a file part from dict."""
        data = {"type": "file", "name": "doc.pdf", "media_type": "application/pdf"}
        part = A2APart.model_validate(data)
        assert isinstance(part.root, FilePart)
        assert part.root.name == "doc.pdf"

    def test_parse_data_part(self):
        """Parse a data part from dict."""
        data = {"type": "data", "data": {"foo": "bar"}}
        part = A2APart.model_validate(data)
        assert isinstance(part.root, DataPart)
        assert part.root.data == {"foo": "bar"}


class TestA2AMessage:
    """Tests for A2AMessage model."""

    def test_create_user_message(self):
        """Create a user message with text."""
        msg = A2AMessage(
            role="user",
            parts=[TextPart(text="Hello, agent!")],
        )
        assert msg.role == "user"
        assert len(msg.parts) == 1
        assert msg.parts[0].text == "Hello, agent!"

    def test_create_agent_message(self):
        """Create an agent message."""
        msg = A2AMessage(
            role="agent",
            parts=[TextPart(text="Hello! How can I help?")],
        )
        assert msg.role == "agent"


class TestA2ATaskStatus:
    """Tests for A2ATaskStatus model."""

    def test_create_status(self):
        """Create a task status."""
        status = A2ATaskStatus(state=A2ATaskState.WORKING)
        assert status.state == A2ATaskState.WORKING
        assert status.message is None
        assert status.timestamp is not None

    def test_create_status_with_message(self):
        """Create a task status with message."""
        status = A2ATaskStatus(
            state=A2ATaskState.FAILED,
            message="Connection timeout",
        )
        assert status.message == "Connection timeout"


class TestA2AArtifact:
    """Tests for A2AArtifact model."""

    def test_create_artifact(self):
        """Create an artifact with parts."""
        artifact = A2AArtifact(
            parts=[TextPart(text="Result text")],
        )
        assert len(artifact.parts) == 1
        assert artifact.name is None
        assert artifact.index == 0

    def test_create_named_artifact(self):
        """Create a named artifact."""
        artifact = A2AArtifact(
            name="analysis_result",
            parts=[DataPart(data={"score": 0.95})],
            index=1,
        )
        assert artifact.name == "analysis_result"
        assert artifact.index == 1
