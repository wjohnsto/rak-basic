"""Tests for ACP protocol adapter."""

from redis_agent_kit.models import (
    AgentManifest,
    AgentMetadata,
    Capability,
    Message,
    TaskState,
    TaskStatus,
)
from redis_agent_kit.protocols.acp.adapter import ACPAdapter
from redis_agent_kit.protocols.acp.models import (
    ACPMessage,
    ACPRun,
    ACPRunState,
    ACPTextContent,
)


class TestACPAdapterStatusMapping:
    """Tests for ACP status mapping."""

    def test_status_to_acp(self):
        """Map RAK TaskStatus to ACP RunState."""
        adapter = ACPAdapter(agent_manifest=AgentManifest(name="test-agent", description="Test"))
        assert adapter.map_status_to_acp(TaskStatus.QUEUED) == ACPRunState.CREATED
        assert adapter.map_status_to_acp(TaskStatus.IN_PROGRESS) == ACPRunState.IN_PROGRESS
        assert adapter.map_status_to_acp(TaskStatus.AWAITING_INPUT) == ACPRunState.AWAITING
        assert adapter.map_status_to_acp(TaskStatus.DONE) == ACPRunState.COMPLETED
        assert adapter.map_status_to_acp(TaskStatus.FAILED) == ACPRunState.FAILED
        assert adapter.map_status_to_acp(TaskStatus.CANCELLED) == ACPRunState.CANCELLED

    def test_status_from_acp(self):
        """Map ACP RunState to RAK TaskStatus."""
        adapter = ACPAdapter(agent_manifest=AgentManifest(name="test-agent", description="Test"))
        assert adapter.map_status_from_acp(ACPRunState.CREATED) == TaskStatus.QUEUED
        assert adapter.map_status_from_acp(ACPRunState.IN_PROGRESS) == TaskStatus.IN_PROGRESS
        assert adapter.map_status_from_acp(ACPRunState.AWAITING) == TaskStatus.AWAITING_INPUT
        assert adapter.map_status_from_acp(ACPRunState.COMPLETED) == TaskStatus.DONE
        assert adapter.map_status_from_acp(ACPRunState.FAILED) == TaskStatus.FAILED
        assert adapter.map_status_from_acp(ACPRunState.CANCELLED) == TaskStatus.CANCELLED


class TestACPAdapterTaskConversion:
    """Tests for task conversion."""

    def test_to_protocol_task(self):
        """Convert RAK TaskState to ACP Run."""
        adapter = ACPAdapter(agent_manifest=AgentManifest(name="test-agent", description="Test"))
        rak_task = TaskState(
            task_id="task-123",
            session_id="thread-456",
            status=TaskStatus.IN_PROGRESS,
        )
        acp_run = adapter.to_protocol_task(rak_task)
        assert isinstance(acp_run, ACPRun)
        assert acp_run.id == "task-123"
        assert acp_run.session_id == "thread-456"
        assert acp_run.status.state == ACPRunState.IN_PROGRESS

    def test_to_protocol_task_with_result(self):
        """Convert completed task with result to ACP Run with output."""
        adapter = ACPAdapter(agent_manifest=AgentManifest(name="test-agent", description="Test"))
        rak_task = TaskState(
            task_id="task-123",
            session_id="thread-456",
            status=TaskStatus.DONE,
            result={"response": "Hello!"},
        )
        acp_run = adapter.to_protocol_task(rak_task)
        assert acp_run.status.state == ACPRunState.COMPLETED
        assert len(acp_run.output) == 1
        assert acp_run.output[0].parts[0].content == '{"response": "Hello!"}'


class TestACPAdapterMessageConversion:
    """Tests for message conversion."""

    def test_from_protocol_message(self):
        """Convert ACP Message to RAK Message."""
        adapter = ACPAdapter(agent_manifest=AgentManifest(name="test-agent", description="Test"))
        acp_msg = ACPMessage(
            role="user",
            parts=[ACPTextContent(content="Hello!")],
        )
        rak_msg = adapter.from_protocol_message(acp_msg)
        assert isinstance(rak_msg, Message)
        assert rak_msg.role == "user"
        assert rak_msg.content == "Hello!"

    def test_to_protocol_message(self):
        """Convert RAK Message to ACP Message."""
        adapter = ACPAdapter(agent_manifest=AgentManifest(name="test-agent", description="Test"))
        rak_msg = Message(role="assistant", content="Hello!")
        acp_msg = adapter.to_protocol_message(rak_msg)
        assert isinstance(acp_msg, ACPMessage)
        assert acp_msg.role == "agent"  # assistant -> agent
        assert len(acp_msg.parts) == 1
        assert acp_msg.parts[0].content == "Hello!"


class TestACPAdapterDiscovery:
    """Tests for agent manifest discovery."""

    def test_get_discovery_document(self):
        """Get agent manifest as discovery document."""
        manifest = AgentManifest(
            name="my-agent",
            description="A helpful assistant",
            input_content_types=["text/plain"],
            output_content_types=["text/plain"],
            metadata=AgentMetadata(
                capabilities=[Capability(name="Chat", description="General chat")],
            ),
        )
        adapter = ACPAdapter(agent_manifest=manifest)
        doc = adapter.get_discovery_document()
        assert doc["name"] == "my-agent"
        assert doc["description"] == "A helpful assistant"
        assert doc["input_content_types"] == ["text/plain"]
        assert len(doc["metadata"]["capabilities"]) == 1
