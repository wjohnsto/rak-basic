"""Tests for ACP protocol models."""

from redis_agent_kit.protocols.acp.models import (
    ACPMessage,
    ACPRun,
    ACPRunState,
    ACPRunStatus,
    ACPTextContent,
)


class TestACPRunState:
    """Tests for ACPRunState enum."""

    def test_all_states_exist(self):
        """Verify all ACP run states are defined."""
        assert ACPRunState.CREATED == "created"
        assert ACPRunState.IN_PROGRESS == "in_progress"
        assert ACPRunState.AWAITING == "awaiting"
        assert ACPRunState.COMPLETED == "completed"
        assert ACPRunState.FAILED == "failed"
        assert ACPRunState.CANCELING == "canceling"
        assert ACPRunState.CANCELLED == "cancelled"
        assert ACPRunState.EXPIRED == "expired"


class TestACPTextContent:
    """Tests for ACPTextContent model."""

    def test_create_text_content(self):
        """Create a text content."""
        content = ACPTextContent(content="Hello, world!")
        assert content.type == "text"
        assert content.content == "Hello, world!"

    def test_text_content_with_metadata(self):
        """Text content can have metadata."""
        content = ACPTextContent(content="Hello", metadata={"lang": "en"})
        assert content.metadata == {"lang": "en"}


class TestACPMessage:
    """Tests for ACPMessage model."""

    def test_create_user_message(self):
        """Create a user message."""
        msg = ACPMessage(
            role="user",
            parts=[ACPTextContent(content="Hello!")],
        )
        assert msg.role == "user"
        assert len(msg.parts) == 1
        assert msg.parts[0].content == "Hello!"

    def test_create_agent_message(self):
        """Create an agent message."""
        msg = ACPMessage(
            role="agent",
            parts=[ACPTextContent(content="Hi there!")],
        )
        assert msg.role == "agent"


class TestACPRunStatus:
    """Tests for ACPRunStatus model."""

    def test_create_status(self):
        """Create a run status."""
        status = ACPRunStatus(state=ACPRunState.IN_PROGRESS)
        assert status.state == ACPRunState.IN_PROGRESS
        assert status.message is None
        assert status.timestamp is not None

    def test_create_status_with_message(self):
        """Create a run status with message."""
        status = ACPRunStatus(
            state=ACPRunState.FAILED,
            message="Connection timeout",
        )
        assert status.message == "Connection timeout"


class TestACPRun:
    """Tests for ACPRun model."""

    def test_create_run(self):
        """Create a run."""
        run = ACPRun(
            id="run-123",
            agent_name="my-agent",
            status=ACPRunStatus(state=ACPRunState.CREATED),
        )
        assert run.id == "run-123"
        assert run.agent_name == "my-agent"
        assert run.status.state == ACPRunState.CREATED
        assert run.session_id is None
        assert run.output == []

    def test_create_run_with_session(self):
        """Create a run with session."""
        run = ACPRun(
            id="run-123",
            agent_name="my-agent",
            status=ACPRunStatus(state=ACPRunState.IN_PROGRESS),
            session_id="session-456",
        )
        assert run.session_id == "session-456"

    def test_create_run_with_output(self):
        """Create a run with output."""
        run = ACPRun(
            id="run-123",
            agent_name="my-agent",
            status=ACPRunStatus(state=ACPRunState.COMPLETED),
            output=[ACPMessage(role="agent", parts=[ACPTextContent(content="Done!")])],
        )
        assert len(run.output) == 1
        assert run.output[0].parts[0].content == "Done!"
