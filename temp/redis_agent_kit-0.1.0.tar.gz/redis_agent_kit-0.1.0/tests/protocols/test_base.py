"""Tests for protocol adapter base class."""

from typing import Any

import pytest

from redis_agent_kit.models import Message, TaskState, TaskStatus
from redis_agent_kit.protocols.base import ProtocolAdapter


class ConcreteAdapter(ProtocolAdapter):
    """Concrete implementation for testing."""

    def to_protocol_task(self, task: TaskState) -> dict[str, Any]:
        """Convert RAK TaskState to protocol-specific task."""
        return {"id": task.task_id, "status": task.status.value}

    def from_protocol_message(self, message: dict[str, Any]) -> Message:
        """Convert protocol-specific message to RAK Message."""
        return Message(role=message.get("role", "user"), content=message.get("text", ""))

    def to_protocol_message(self, message: Message) -> dict[str, Any]:
        """Convert RAK Message to protocol-specific message."""
        return {"role": message.role, "text": message.content}

    def get_discovery_document(self) -> dict[str, Any]:
        """Return the protocol's discovery document."""
        return {"name": "test-agent", "version": "1.0"}


class TestProtocolAdapter:
    """Tests for ProtocolAdapter abstract base class."""

    def test_cannot_instantiate_abstract_class(self):
        """ProtocolAdapter cannot be instantiated directly."""
        with pytest.raises(TypeError, match="abstract"):
            ProtocolAdapter()  # type: ignore

    def test_concrete_adapter_can_be_instantiated(self):
        """Concrete implementations can be instantiated."""
        adapter = ConcreteAdapter()
        assert adapter is not None

    def test_to_protocol_task(self):
        """to_protocol_task converts RAK TaskState to protocol format."""
        adapter = ConcreteAdapter()
        task = TaskState(
            task_id="task-123",
            thread_id="thread-456",
            status=TaskStatus.IN_PROGRESS,
        )
        result = adapter.to_protocol_task(task)
        assert result == {"id": "task-123", "status": "in_progress"}

    def test_from_protocol_message(self):
        """from_protocol_message converts protocol message to RAK Message."""
        adapter = ConcreteAdapter()
        protocol_msg = {"role": "user", "text": "Hello!"}
        result = adapter.from_protocol_message(protocol_msg)
        assert isinstance(result, Message)
        assert result.role == "user"
        assert result.content == "Hello!"

    def test_to_protocol_message(self):
        """to_protocol_message converts RAK Message to protocol format."""
        adapter = ConcreteAdapter()
        msg = Message(role="assistant", content="Hi there!")
        result = adapter.to_protocol_message(msg)
        assert result == {"role": "assistant", "text": "Hi there!"}

    def test_get_discovery_document(self):
        """get_discovery_document returns protocol discovery info."""
        adapter = ConcreteAdapter()
        result = adapter.get_discovery_document()
        assert result == {"name": "test-agent", "version": "1.0"}


class TestProtocolAdapterStatusMapping:
    """Tests for status mapping helper methods."""

    def test_map_status_to_protocol_default(self):
        """map_status_to_protocol uses default mapping."""
        adapter = ConcreteAdapter()
        assert adapter.map_status_to_protocol(TaskStatus.QUEUED) == "queued"
        assert adapter.map_status_to_protocol(TaskStatus.IN_PROGRESS) == "in_progress"
        assert adapter.map_status_to_protocol(TaskStatus.DONE) == "done"

    def test_map_status_to_protocol_custom(self):
        """map_status_to_protocol uses custom mapping when provided."""
        adapter = ConcreteAdapter()
        custom_map = {
            TaskStatus.QUEUED: "submitted",
            TaskStatus.IN_PROGRESS: "working",
            TaskStatus.DONE: "completed",
        }
        assert adapter.map_status_to_protocol(TaskStatus.QUEUED, custom_map) == "submitted"
        assert adapter.map_status_to_protocol(TaskStatus.IN_PROGRESS, custom_map) == "working"
        assert adapter.map_status_to_protocol(TaskStatus.DONE, custom_map) == "completed"

    def test_map_status_from_protocol_default(self):
        """map_status_from_protocol uses default mapping."""
        adapter = ConcreteAdapter()
        assert adapter.map_status_from_protocol("queued") == TaskStatus.QUEUED
        assert adapter.map_status_from_protocol("in_progress") == TaskStatus.IN_PROGRESS
        assert adapter.map_status_from_protocol("done") == TaskStatus.DONE

    def test_map_status_from_protocol_custom(self):
        """map_status_from_protocol uses custom mapping when provided."""
        adapter = ConcreteAdapter()
        custom_map = {
            "submitted": TaskStatus.QUEUED,
            "working": TaskStatus.IN_PROGRESS,
            "completed": TaskStatus.DONE,
        }
        assert adapter.map_status_from_protocol("submitted", custom_map) == TaskStatus.QUEUED
        assert adapter.map_status_from_protocol("working", custom_map) == TaskStatus.IN_PROGRESS
        assert adapter.map_status_from_protocol("completed", custom_map) == TaskStatus.DONE

    def test_map_status_from_protocol_unknown(self):
        """map_status_from_protocol raises for unknown status."""
        adapter = ConcreteAdapter()
        with pytest.raises(ValueError, match="Unknown protocol status"):
            adapter.map_status_from_protocol("unknown_status")
