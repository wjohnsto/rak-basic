"""Tests for Agent class."""

from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from redis_agent_kit.agent import Agent, AgentConfig, Message
from redis_agent_kit.tools import ToolCapability, ToolDefinition, ToolProvider


class TestAgentConfig:
    """Tests for AgentConfig."""

    def test_agent_config_defaults(self):
        """AgentConfig should have sensible defaults."""

        config = AgentConfig()
        assert config.model == "gpt-4o-mini"
        assert config.temperature == 0.7
        assert config.max_tokens is None
        assert config.system_prompt is None

    def test_agent_config_custom(self):
        """AgentConfig should accept custom values."""

        config = AgentConfig(
            model="claude-3-sonnet",
            temperature=0.5,
            max_tokens=1000,
            system_prompt="You are a helpful assistant.",
        )
        assert config.model == "claude-3-sonnet"
        assert config.temperature == 0.5
        assert config.max_tokens == 1000


class TestAgent:
    """Tests for Agent class."""

    @pytest.mark.asyncio
    async def test_agent_creation(self, redis_client):
        """Agent should be created with a Redis client."""

        agent = Agent(redis_client=redis_client)
        assert agent.knowledge is not None
        assert agent.tools is not None

    @pytest.mark.asyncio
    async def test_agent_from_url(self, redis_url):
        """Agent should be created from a URL."""

        agent = Agent(redis_url=redis_url)
        assert agent.knowledge is not None

    @pytest.mark.asyncio
    async def test_agent_chat_simple(self, redis_client):
        """Agent chat should call LLM and return response."""

        agent = Agent(redis_client=redis_client)

        # Mock LiteLLM response
        mock_response = MagicMock()
        mock_response.choices = [MagicMock()]
        mock_response.choices[0].message.content = "Hello! How can I help?"
        mock_response.choices[0].message.tool_calls = None
        mock_response.choices[0].finish_reason = "stop"

        with patch("litellm.acompletion", new_callable=AsyncMock) as mock_llm:
            mock_llm.return_value = mock_response

            response = await agent.chat("Hello")

        assert response == "Hello! How can I help?"
        mock_llm.assert_called_once()

    @pytest.mark.asyncio
    async def test_agent_chat_with_system_prompt(self, redis_client):
        """Agent chat should include system prompt."""

        config = AgentConfig(system_prompt="You are a Redis expert.")
        agent = Agent(redis_client=redis_client, config=config)

        mock_response = MagicMock()
        mock_response.choices = [MagicMock()]
        mock_response.choices[0].message.content = "Redis is great!"
        mock_response.choices[0].message.tool_calls = None
        mock_response.choices[0].finish_reason = "stop"

        with patch("litellm.acompletion", new_callable=AsyncMock) as mock_llm:
            mock_llm.return_value = mock_response

            await agent.chat("Tell me about Redis")

        # Check that system prompt was included
        call_args = mock_llm.call_args
        messages = call_args.kwargs["messages"]
        assert messages[0]["role"] == "system"
        assert messages[0]["content"] == "You are a Redis expert."

    @pytest.mark.asyncio
    async def test_agent_chat_with_tools(self, redis_client):
        """Agent chat should handle tool calls."""

        class TestProvider(ToolProvider):
            @property
            def provider_name(self) -> str:
                return "test"

            def create_tool_schemas(self) -> list[ToolDefinition]:
                return [
                    ToolDefinition(
                        name="get_time",
                        description="Get current time",
                        parameters={"type": "object", "properties": {}},
                        capability=ToolCapability.UTILITIES,
                    )
                ]

            async def get_time(self):
                return {"time": "12:00 PM"}

        agent = Agent(redis_client=redis_client)
        agent.tools.add_provider(TestProvider())

        # First response with tool call
        mock_tool_call = MagicMock()
        mock_tool_call.id = "call_123"
        mock_tool_call.function.name = "get_time"
        mock_tool_call.function.arguments = "{}"

        mock_response1 = MagicMock()
        mock_response1.choices = [MagicMock()]
        mock_response1.choices[0].message.content = None
        mock_response1.choices[0].message.tool_calls = [mock_tool_call]
        mock_response1.choices[0].finish_reason = "tool_calls"

        # Second response after tool execution
        mock_response2 = MagicMock()
        mock_response2.choices = [MagicMock()]
        mock_response2.choices[0].message.content = "The time is 12:00 PM"
        mock_response2.choices[0].message.tool_calls = None
        mock_response2.choices[0].finish_reason = "stop"

        with patch("litellm.acompletion", new_callable=AsyncMock) as mock_llm:
            mock_llm.side_effect = [mock_response1, mock_response2]

            response = await agent.chat("What time is it?")

        assert response == "The time is 12:00 PM"
        assert mock_llm.call_count == 2

    @pytest.mark.asyncio
    async def test_agent_history(self, redis_client):
        """Agent should maintain conversation history."""

        agent = Agent(redis_client=redis_client)

        mock_response = MagicMock()
        mock_response.choices = [MagicMock()]
        mock_response.choices[0].message.content = "Response"
        mock_response.choices[0].message.tool_calls = None
        mock_response.choices[0].finish_reason = "stop"

        with patch("litellm.acompletion", new_callable=AsyncMock) as mock_llm:
            mock_llm.return_value = mock_response

            await agent.chat("Message 1")
            await agent.chat("Message 2")

        assert len(agent._history) == 4  # 2 user + 2 assistant messages

    @pytest.mark.asyncio
    async def test_agent_clear_history(self, redis_client):
        """Agent should clear conversation history."""

        agent = Agent(redis_client=redis_client)

        mock_response = MagicMock()
        mock_response.choices = [MagicMock()]
        mock_response.choices[0].message.content = "Response"
        mock_response.choices[0].message.tool_calls = None
        mock_response.choices[0].finish_reason = "stop"

        with patch("litellm.acompletion", new_callable=AsyncMock) as mock_llm:
            mock_llm.return_value = mock_response

            await agent.chat("Message")
            agent.clear_history()

        assert len(agent._history) == 0

    @pytest.mark.asyncio
    async def test_agent_model_property(self, redis_client):
        """Agent model property should return config model."""

        config = AgentConfig(model="claude-3-opus")
        agent = Agent(redis_client=redis_client, config=config)
        assert agent.model == "claude-3-opus"

    @pytest.mark.asyncio
    async def test_agent_config_property(self, redis_client):
        """Agent config property should return the config."""

        config = AgentConfig(model="gpt-4", temperature=0.5)
        agent = Agent(redis_client=redis_client, config=config)
        assert agent.config == config
        assert agent.config.temperature == 0.5

    @pytest.mark.asyncio
    async def test_agent_add_provider(self, redis_client):
        """Agent add_provider should add to tools manager."""

        class TestProvider(ToolProvider):
            @property
            def provider_name(self) -> str:
                return "test_add"

            def create_tool_schemas(self) -> list[ToolDefinition]:
                return [
                    ToolDefinition(
                        name="test_tool",
                        description="Test tool",
                        parameters={"type": "object", "properties": {}},
                        capability=ToolCapability.UTILITIES,
                    )
                ]

            async def test_tool(self):
                return {}

        agent = Agent(redis_client=redis_client)
        provider = TestProvider()
        agent.add_provider(provider)

        assert "test_add" in agent.tools._providers

    @pytest.mark.asyncio
    async def test_agent_chat_with_max_tokens(self, redis_client):
        """Agent chat should pass max_tokens to LLM."""

        config = AgentConfig(max_tokens=500)
        agent = Agent(redis_client=redis_client, config=config)

        mock_response = MagicMock()
        mock_response.choices = [MagicMock()]
        mock_response.choices[0].message.content = "Response"
        mock_response.choices[0].message.tool_calls = None
        mock_response.choices[0].finish_reason = "stop"

        with patch("litellm.acompletion", new_callable=AsyncMock) as mock_llm:
            mock_llm.return_value = mock_response
            await agent.chat("Hello")

        call_args = mock_llm.call_args
        assert call_args.kwargs["max_tokens"] == 500

    @pytest.mark.asyncio
    async def test_agent_tool_call_json_decode_error(self, redis_client):
        """Agent should handle invalid JSON in tool arguments."""

        class TestProvider(ToolProvider):
            @property
            def provider_name(self) -> str:
                return "test"

            def create_tool_schemas(self) -> list[ToolDefinition]:
                return [
                    ToolDefinition(
                        name="test_tool",
                        description="Test tool",
                        parameters={"type": "object", "properties": {}},
                        capability=ToolCapability.UTILITIES,
                    )
                ]

            async def test_tool(self):
                return {"result": "ok"}

        agent = Agent(redis_client=redis_client)
        agent.tools.add_provider(TestProvider())

        # Tool call with invalid JSON arguments
        mock_tool_call = MagicMock()
        mock_tool_call.id = "call_123"
        mock_tool_call.function.name = "test_tool"
        mock_tool_call.function.arguments = "invalid json {"

        mock_response1 = MagicMock()
        mock_response1.choices = [MagicMock()]
        mock_response1.choices[0].message.content = None
        mock_response1.choices[0].message.tool_calls = [mock_tool_call]
        mock_response1.choices[0].finish_reason = "tool_calls"

        mock_response2 = MagicMock()
        mock_response2.choices = [MagicMock()]
        mock_response2.choices[0].message.content = "Done"
        mock_response2.choices[0].message.tool_calls = None
        mock_response2.choices[0].finish_reason = "stop"

        with patch("litellm.acompletion", new_callable=AsyncMock) as mock_llm:
            mock_llm.side_effect = [mock_response1, mock_response2]
            response = await agent.chat("Test")

        assert response == "Done"

    @pytest.mark.asyncio
    async def test_agent_tool_execution_error(self, redis_client):
        """Agent should handle tool execution errors."""

        class FailingProvider(ToolProvider):
            @property
            def provider_name(self) -> str:
                return "failing"

            def create_tool_schemas(self) -> list[ToolDefinition]:
                return [
                    ToolDefinition(
                        name="failing_tool",
                        description="A tool that fails",
                        parameters={"type": "object", "properties": {}},
                        capability=ToolCapability.UTILITIES,
                    )
                ]

            async def failing_tool(self):
                raise ValueError("Tool failed!")

        agent = Agent(redis_client=redis_client)
        agent.tools.add_provider(FailingProvider())

        mock_tool_call = MagicMock()
        mock_tool_call.id = "call_456"
        mock_tool_call.function.name = "failing_tool"
        mock_tool_call.function.arguments = "{}"

        mock_response1 = MagicMock()
        mock_response1.choices = [MagicMock()]
        mock_response1.choices[0].message.content = None
        mock_response1.choices[0].message.tool_calls = [mock_tool_call]
        mock_response1.choices[0].finish_reason = "tool_calls"

        mock_response2 = MagicMock()
        mock_response2.choices = [MagicMock()]
        mock_response2.choices[0].message.content = "I see there was an error"
        mock_response2.choices[0].message.tool_calls = None
        mock_response2.choices[0].finish_reason = "stop"

        with patch("litellm.acompletion", new_callable=AsyncMock) as mock_llm:
            mock_llm.side_effect = [mock_response1, mock_response2]
            response = await agent.chat("Test")

        assert response == "I see there was an error"


class TestMessage:
    """Tests for Message dataclass."""

    def test_message_to_dict_with_tool_calls(self):
        """Message to_dict should include tool_calls when present."""

        msg = Message(
            role="assistant",
            content="Using tool",
            tool_calls=[{"id": "call_1", "function": {"name": "test"}}],
        )
        d = msg.to_dict()
        assert d["role"] == "assistant"
        assert d["content"] == "Using tool"
        assert d["tool_calls"] == [{"id": "call_1", "function": {"name": "test"}}]

    def test_message_to_dict_with_tool_call_id(self):
        """Message to_dict should include tool_call_id when present."""

        msg = Message(
            role="tool",
            content='{"result": "ok"}',
            tool_call_id="call_1",
        )
        d = msg.to_dict()
        assert d["role"] == "tool"
        assert d["content"] == '{"result": "ok"}'
        assert d["tool_call_id"] == "call_1"
