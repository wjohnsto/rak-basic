"""Tests for attachment storage backends."""

import base64
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from redis_agent_kit import (
    Attachment,
    AttachmentType,
    InlineAttachmentStore,
    RedisAttachmentStore,
    get_attachment_data,
)


class TestInlineAttachmentStore:
    """Tests for InlineAttachmentStore."""

    async def test_store_creates_attachment_with_base64(self):
        """Store should create attachment with base64-encoded data."""
        store = InlineAttachmentStore()
        data = b"Hello, World!"

        attachment = await store.store(data, "text/plain", filename="test.txt")

        assert attachment.type == AttachmentType.FILE
        assert attachment.mime_type == "text/plain"
        assert attachment.filename == "test.txt"
        assert attachment.size_bytes == len(data)
        assert attachment.data == base64.b64encode(data).decode("utf-8")
        assert attachment.url is None

    async def test_store_detects_image_type(self):
        """Store should detect image type from MIME."""
        store = InlineAttachmentStore()

        attachment = await store.store(b"fake png", "image/png")

        assert attachment.type == AttachmentType.IMAGE

    async def test_store_detects_audio_type(self):
        """Store should detect audio type from MIME."""
        store = InlineAttachmentStore()

        attachment = await store.store(b"fake wav", "audio/wav")

        assert attachment.type == AttachmentType.AUDIO

    async def test_store_detects_video_type(self):
        """Store should detect video type from MIME."""
        store = InlineAttachmentStore()

        attachment = await store.store(b"fake mp4", "video/mp4")

        assert attachment.type == AttachmentType.VIDEO

    async def test_retrieve_raises_not_implemented(self):
        """Retrieve should raise for inline store."""
        store = InlineAttachmentStore()

        with pytest.raises(NotImplementedError):
            await store.retrieve("inline")

    async def test_delete_returns_false(self):
        """Delete should return False for inline store."""
        store = InlineAttachmentStore()

        result = await store.delete("inline")

        assert result is False


class TestRedisAttachmentStore:
    """Tests for RedisAttachmentStore."""

    async def test_store_and_retrieve(self, redis_url, redis_client):
        """Store and retrieve should round-trip data."""
        store = RedisAttachmentStore(redis_client=redis_client)
        data = b"Test image data"

        attachment = await store.store(data, "image/png", filename="test.png")

        assert attachment.type == AttachmentType.IMAGE
        assert attachment.url.startswith("redis://attachments:")
        assert attachment.size_bytes == len(data)

        retrieved = await store.retrieve(attachment.url)
        assert retrieved == data

    async def test_store_with_metadata(self, redis_url, redis_client):
        """Store should preserve metadata."""
        store = RedisAttachmentStore(redis_client=redis_client)

        attachment = await store.store(b"data", "application/json", metadata={"source": "test"})

        assert attachment.metadata == {"source": "test"}

    async def test_retrieve_not_found_raises(self, redis_url, redis_client):
        """Retrieve should raise KeyError for missing attachment."""
        store = RedisAttachmentStore(redis_client=redis_client)

        with pytest.raises(KeyError):
            await store.retrieve("redis://attachments:nonexistent")

    async def test_delete(self, redis_url, redis_client):
        """Delete should remove attachment."""
        store = RedisAttachmentStore(redis_client=redis_client)
        data = b"to delete"

        attachment = await store.store(data, "text/plain")
        result = await store.delete(attachment.url)

        assert result is True

        with pytest.raises(KeyError):
            await store.retrieve(attachment.url)

    async def test_delete_not_found(self, redis_url, redis_client):
        """Delete should return False for missing attachment."""
        store = RedisAttachmentStore(redis_client=redis_client)

        result = await store.delete("redis://attachments:nonexistent")

        assert result is False

    async def test_custom_prefix(self, redis_url, redis_client):
        """Store should use custom prefix."""
        store = RedisAttachmentStore(redis_client=redis_client, prefix="custom")

        attachment = await store.store(b"data", "text/plain")

        assert attachment.url.startswith("redis://custom:")

    async def test_get_client_requires_client_or_url(self):
        """Store should raise when no client or URL is configured."""
        store = RedisAttachmentStore(redis_client=None, redis_url=None)

        with pytest.raises(ValueError, match="Either redis_client or redis_url"):
            await store._get_client()

    async def test_get_client_creates_client_from_url(self):
        """Store should lazily create client from redis_url."""
        fake_client = MagicMock()
        with patch("redis.asyncio.from_url", return_value=fake_client) as mock_from_url:
            store = RedisAttachmentStore(redis_client=None, redis_url="redis://localhost:6379")
            client = await store._get_client()

        assert client is fake_client
        assert store._owns_client is True
        mock_from_url.assert_called_once_with("redis://localhost:6379")

    async def test_store_without_ttl_uses_set(self):
        """Store should use SET when ttl_seconds is None."""
        redis_client = MagicMock()
        redis_client.set = AsyncMock()
        redis_client.setex = AsyncMock()

        store = RedisAttachmentStore(redis_client=redis_client, ttl_seconds=None)
        attachment = await store.store(b"data", "text/plain")

        assert attachment.url.startswith("redis://attachments:")
        redis_client.set.assert_called_once()
        redis_client.setex.assert_not_called()


class TestGetAttachmentData:
    """Tests for get_attachment_data helper."""

    def test_get_inline_data(self):
        """Should decode base64 inline data."""
        data = b"Hello"
        attachment = Attachment(
            type=AttachmentType.FILE,
            mime_type="text/plain",
            data=base64.b64encode(data).decode("utf-8"),
        )

        result = get_attachment_data(attachment)

        assert result == data

    def test_raises_for_url_attachment(self):
        """Should raise for URL-based attachments."""
        attachment = Attachment(
            type=AttachmentType.IMAGE,
            mime_type="image/png",
            url="redis://attachments:123",
        )

        with pytest.raises(ValueError, match="no inline data"):
            get_attachment_data(attachment)
