"""Tests for TaskEmitter."""

import asyncio

from redis_agent_kit.emitter import TaskEmitter
from redis_agent_kit.task_manager import TaskManager


class TestTaskEmitterAsync:
    """Tests for async emit methods."""

    async def test_emit_async(self, redis_client):
        """Emit an update asynchronously."""
        manager = TaskManager(redis_client)
        task = await manager.create_task(session_id="t1", message="Hi")
        emitter = TaskEmitter(manager, task.task_id)

        await emitter.emit_async("Processing...")

        updated = await manager.get_task(task.task_id)
        assert len(updated.updates) == 1
        assert updated.updates[0].message == "Processing..."

    async def test_emit_async_with_type(self, redis_client):
        """Emit an update with a specific type."""
        manager = TaskManager(redis_client)
        task = await manager.create_task(session_id="t1", message="Hi")
        emitter = TaskEmitter(manager, task.task_id)

        await emitter.emit_async("Calling search", update_type="tool_call")

        updated = await manager.get_task(task.task_id)
        assert updated.updates[0].update_type == "tool_call"

    async def test_emit_async_with_metadata(self, redis_client):
        """Emit an update with metadata."""
        manager = TaskManager(redis_client)
        task = await manager.create_task(session_id="t1", message="Hi")
        emitter = TaskEmitter(manager, task.task_id)

        await emitter.emit_async(
            "Found results",
            metadata={"count": 5, "source": "knowledge_base"},
        )

        updated = await manager.get_task(task.task_id)
        assert updated.updates[0].metadata == {"count": 5, "source": "knowledge_base"}

    async def test_emit_async_multiple(self, redis_client):
        """Emit multiple updates in sequence."""
        manager = TaskManager(redis_client)
        task = await manager.create_task(session_id="t1", message="Hi")
        emitter = TaskEmitter(manager, task.task_id)

        await emitter.emit_async("Step 1")
        await emitter.emit_async("Step 2")
        await emitter.emit_async("Step 3")

        updated = await manager.get_task(task.task_id)
        assert len(updated.updates) == 3
        messages = [u.message for u in updated.updates]
        assert messages == ["Step 1", "Step 2", "Step 3"]


class TestTaskEmitterSync:
    """Tests for emit_nowait method (fire-and-forget)."""

    async def test_emit_nowait(self, redis_client):
        """Emit an update without waiting (schedules async task)."""
        manager = TaskManager(redis_client)
        task = await manager.create_task(session_id="t1", message="Hi")
        emitter = TaskEmitter(manager, task.task_id)

        # emit_nowait schedules the update without blocking
        emitter.emit_nowait("Processing...")

        # Give time for the background task to complete
        await asyncio.sleep(0.1)

        updated = await manager.get_task(task.task_id)
        assert len(updated.updates) == 1
        assert updated.updates[0].message == "Processing..."

    async def test_emit_nowait_with_await_between(self, redis_client):
        """Emit multiple nowait updates with awaits between to avoid race."""
        manager = TaskManager(redis_client)
        task = await manager.create_task(session_id="t1", message="Hi")
        emitter = TaskEmitter(manager, task.task_id)

        emitter.emit_nowait("A")
        await asyncio.sleep(0.05)  # Let first update complete
        emitter.emit_nowait("B")
        await asyncio.sleep(0.05)  # Let second update complete
        emitter.emit_nowait("C")
        await asyncio.sleep(0.05)  # Let third update complete

        updated = await manager.get_task(task.task_id)
        assert len(updated.updates) == 3
        # Note: for rapid-fire updates, use await emit() instead


class TestTaskEmitterContext:
    """Tests for emitter context and properties."""

    async def test_emitter_has_task_id(self, redis_client):
        """Emitter should expose its task_id."""
        manager = TaskManager(redis_client)
        task = await manager.create_task(session_id="t1", message="Hi")
        emitter = TaskEmitter(manager, task.task_id)

        assert emitter.task_id == task.task_id

    async def test_emitter_has_manager(self, redis_client):
        """Emitter should expose its task manager."""
        manager = TaskManager(redis_client)
        task = await manager.create_task(session_id="t1", message="Hi")
        emitter = TaskEmitter(manager, task.task_id)

        assert emitter.task_manager is manager
