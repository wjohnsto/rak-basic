"""Integration tests for Redis Agent Kit."""

from redis_agent_kit.core import AgentKit, create_task_with_session
from redis_agent_kit.emitter import TaskEmitter
from redis_agent_kit.memory import NoOpMemory
from redis_agent_kit.models import TaskStatus
from redis_agent_kit.task_manager import TaskManager


class TestCreateTaskWithSession:
    """Tests for the create_task_with_session helper."""

    async def test_create_task_with_new_session(self, redis_url, redis_client):
        """Create a task along with a new session."""
        task_manager = TaskManager(redis_client)
        memory = NoOpMemory()

        task, session_id = await create_task_with_session(
            task_manager=task_manager,
            memory=memory,
            message="Hello, agent!",
        )

        assert task.task_id is not None
        assert session_id is not None
        assert task.session_id == session_id

    async def test_create_task_with_context(self, redis_url, redis_client):
        """Create a task with context."""
        task_manager = TaskManager(redis_client)
        memory = NoOpMemory()

        task, session_id = await create_task_with_session(
            task_manager=task_manager,
            memory=memory,
            message="Query",
            context={"user_id": "u1", "instance_id": "redis-1"},
        )

        assert session_id is not None
        assert task.metadata.get("context") == {"user_id": "u1", "instance_id": "redis-1"}

    async def test_create_task_with_existing_session(self, redis_url, redis_client):
        """Create a task with an existing session ID."""
        task_manager = TaskManager(redis_client)
        memory = NoOpMemory()

        task, session_id = await create_task_with_session(
            task_manager=task_manager,
            memory=memory,
            message="What is Redis?",
            session_id="existing-session-123",
        )

        assert session_id == "existing-session-123"
        assert task.session_id == "existing-session-123"


class TestAgentKit:
    """Tests for the AgentKit convenience class."""

    async def test_create_agentkit(self, redis_url, redis_client):
        """Create an AgentKit instance."""
        kit = AgentKit(redis_url, redis_client=redis_client)

        assert kit.task_manager is not None
        assert kit.memory is not None

    async def test_agentkit_create_task(self, redis_url, redis_client):
        """Create a task using AgentKit."""
        kit = AgentKit(redis_url, redis_client=redis_client)

        task, session_id = await kit.create_task(
            message="Hello!",
            context={"user_id": "123"},
        )

        assert task.task_id is not None
        assert session_id is not None

    async def test_agentkit_get_emitter(self, redis_url, redis_client):
        """Get an emitter for a task."""
        kit = AgentKit(redis_url, redis_client=redis_client)
        task, _ = await kit.create_task(message="Hi")

        emitter = kit.get_emitter(task.task_id)

        assert isinstance(emitter, TaskEmitter)
        assert emitter.task_id == task.task_id


class TestEndToEndWorkflow:
    """End-to-end workflow tests simulating agent execution."""

    async def test_full_agent_workflow(self, redis_url, redis_client):
        """Simulate a complete agent workflow."""
        kit = AgentKit(redis_url, redis_client=redis_client)

        # 1. Create task with session
        task, session_id = await kit.create_task(
            message="What is the memory usage?",
            context={"instance_id": "redis-prod-1"},
        )

        # 2. Mark task in progress
        await kit.task_manager.update_status(task.task_id, TaskStatus.IN_PROGRESS)

        # 3. Get emitter and emit updates (simulating agent work)
        emitter = kit.get_emitter(task.task_id)
        await emitter.emit_async("Connecting to instance...")
        await emitter.emit_async("Running INFO MEMORY command", update_type="tool_call")
        await emitter.emit_async("Memory usage is 85%", update_type="reflection")

        # 4. Add assistant response to memory
        bound_memory = kit.memory.with_session(session_id)
        await bound_memory.add_message(
            role="assistant",
            content="The current memory usage is 85%.",
        )

        # 5. Set result and mark done
        result = {"answer": "Memory usage is 85%", "data": {"used": 85, "max": 100}}
        await kit.task_manager.set_result(task.task_id, result)
        await kit.task_manager.update_status(task.task_id, TaskStatus.DONE)

        # Verify final state
        final_task = await kit.task_manager.get_task(task.task_id)
        assert final_task.status == TaskStatus.DONE
        assert len(final_task.updates) == 3
        assert final_task.result == result

    async def test_failed_task_workflow(self, redis_url, redis_client):
        """Simulate a task that fails."""
        kit = AgentKit(redis_url, redis_client=redis_client)

        task, _ = await kit.create_task(message="Do something risky")

        await kit.task_manager.update_status(task.task_id, TaskStatus.IN_PROGRESS)

        emitter = kit.get_emitter(task.task_id)
        await emitter.emit_async("Starting risky operation...")
        await emitter.emit_async("Operation failed!", update_type="error")

        await kit.task_manager.set_error(task.task_id, "Connection refused")
        await kit.task_manager.update_status(task.task_id, TaskStatus.FAILED)

        final = await kit.task_manager.get_task(task.task_id)
        assert final.status == TaskStatus.FAILED
        assert final.error_message == "Connection refused"
