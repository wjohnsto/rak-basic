"""Tests for TaskManager."""

from redis_agent_kit.models import (
    TaskStatus,
)
from redis_agent_kit.task_manager import TaskManager


class TestTaskManagerCreate:
    """Tests for task creation."""

    async def test_create_task(self, redis_client):
        """Create a task with basic parameters."""
        manager = TaskManager(redis_client)
        task = await manager.create_task(
            session_id="thread123",
            message="Hello, agent!",
        )

        assert task.task_id is not None
        assert len(task.task_id) == 26  # ULID length
        assert task.session_id == "thread123"
        assert task.status == TaskStatus.QUEUED
        assert task.updates == []
        assert task.result is None

    async def test_create_task_with_context(self, redis_client):
        """Create a task with context metadata."""
        manager = TaskManager(redis_client)
        task = await manager.create_task(
            session_id="thread123",
            message="Hello!",
            context={"user_id": "user456", "instance_id": "redis-1"},
        )

        assert task.metadata.get("context") == {
            "user_id": "user456",
            "instance_id": "redis-1",
        }

    async def test_create_task_stores_message(self, redis_client):
        """The initial message should be stored in metadata."""
        manager = TaskManager(redis_client)
        task = await manager.create_task(
            session_id="thread123",
            message="What is Redis?",
        )

        assert task.metadata.get("message") == "What is Redis?"


class TestTaskManagerGet:
    """Tests for task retrieval."""

    async def test_get_task(self, redis_client):
        """Get an existing task."""
        manager = TaskManager(redis_client)
        created = await manager.create_task(session_id="t1", message="Hi")

        retrieved = await manager.get_task(created.task_id)

        assert retrieved is not None
        assert retrieved.task_id == created.task_id
        assert retrieved.session_id == "t1"

    async def test_get_nonexistent_task(self, redis_client):
        """Get a task that doesn't exist."""
        manager = TaskManager(redis_client)

        result = await manager.get_task("nonexistent")

        assert result is None


class TestTaskManagerStatus:
    """Tests for status updates."""

    async def test_update_status(self, redis_client):
        """Update task status."""
        manager = TaskManager(redis_client)
        task = await manager.create_task(session_id="t1", message="Hi")

        await manager.update_status(task.task_id, TaskStatus.IN_PROGRESS)

        updated = await manager.get_task(task.task_id)
        assert updated.status == TaskStatus.IN_PROGRESS

    async def test_update_status_updates_timestamp(self, redis_client):
        """Updating status should update updated_at."""
        manager = TaskManager(redis_client)
        task = await manager.create_task(session_id="t1", message="Hi")
        original_updated_at = task.updated_at

        await manager.update_status(task.task_id, TaskStatus.IN_PROGRESS)

        updated = await manager.get_task(task.task_id)
        assert updated.updated_at >= original_updated_at


class TestTaskManagerUpdates:
    """Tests for progress updates."""

    async def test_add_update(self, redis_client):
        """Add a progress update to a task."""
        manager = TaskManager(redis_client)
        task = await manager.create_task(session_id="t1", message="Hi")

        await manager.add_update(task.task_id, "Processing...")

        updated = await manager.get_task(task.task_id)
        assert len(updated.updates) == 1
        assert updated.updates[0].message == "Processing..."
        assert updated.updates[0].update_type == "info"

    async def test_add_update_with_type(self, redis_client):
        """Add an update with a specific type."""
        manager = TaskManager(redis_client)
        task = await manager.create_task(session_id="t1", message="Hi")

        await manager.add_update(
            task.task_id,
            "Called search_knowledge",
            update_type="tool_call",
        )

        updated = await manager.get_task(task.task_id)
        assert updated.updates[0].update_type == "tool_call"

    async def test_add_multiple_updates(self, redis_client):
        """Add multiple updates in order."""
        manager = TaskManager(redis_client)
        task = await manager.create_task(session_id="t1", message="Hi")

        await manager.add_update(task.task_id, "Step 1")
        await manager.add_update(task.task_id, "Step 2")
        await manager.add_update(task.task_id, "Step 3")

        updated = await manager.get_task(task.task_id)
        assert len(updated.updates) == 3
        assert [u.message for u in updated.updates] == ["Step 1", "Step 2", "Step 3"]


class TestTaskManagerResult:
    """Tests for setting results and errors."""

    async def test_set_result(self, redis_client):
        """Set the task result."""
        manager = TaskManager(redis_client)
        task = await manager.create_task(session_id="t1", message="Hi")

        result_data = {"answer": "Redis is an in-memory database."}
        await manager.set_result(task.task_id, result_data)

        updated = await manager.get_task(task.task_id)
        assert updated.result == result_data

    async def test_set_error(self, redis_client):
        """Set an error message on the task."""
        manager = TaskManager(redis_client)
        task = await manager.create_task(session_id="t1", message="Hi")

        await manager.set_error(task.task_id, "Connection timeout")

        updated = await manager.get_task(task.task_id)
        assert updated.error_message == "Connection timeout"


class TestTaskManagerList:
    """Tests for listing tasks."""

    async def test_list_tasks_empty(self, redis_client):
        """List tasks when none exist."""
        manager = TaskManager(redis_client)

        tasks = await manager.list_tasks()

        assert tasks == []

    async def test_list_all_tasks(self, redis_client):
        """List all tasks."""
        manager = TaskManager(redis_client)
        await manager.create_task(session_id="t1", message="Task 1")
        await manager.create_task(session_id="t2", message="Task 2")

        tasks = await manager.list_tasks()

        assert len(tasks) == 2

    async def test_list_tasks_by_thread(self, redis_client):
        """List tasks filtered by thread_id."""
        manager = TaskManager(redis_client)
        await manager.create_task(session_id="thread-a", message="A1")
        await manager.create_task(session_id="thread-a", message="A2")
        await manager.create_task(session_id="thread-b", message="B1")

        tasks = await manager.list_tasks(session_id="thread-a")

        assert len(tasks) == 2
        assert all(t.session_id == "thread-a" for t in tasks)

    async def test_list_tasks_by_status(self, redis_client):
        """List tasks filtered by status."""
        manager = TaskManager(redis_client)
        task1 = await manager.create_task(session_id="t1", message="T1")
        task2 = await manager.create_task(session_id="t1", message="T2")
        await manager.update_status(task1.task_id, TaskStatus.IN_PROGRESS)

        tasks = await manager.list_tasks(status=TaskStatus.QUEUED)

        assert len(tasks) == 1
        assert tasks[0].task_id == task2.task_id

    async def test_list_tasks_by_thread_and_status(self, redis_client):
        """List tasks filtered by both thread_id and status."""
        manager = TaskManager(redis_client)
        # Create tasks in same thread with different statuses
        task1 = await manager.create_task(session_id="thread-a", message="A1")
        await manager.create_task(session_id="thread-a", message="A2")
        await manager.update_status(task1.task_id, TaskStatus.IN_PROGRESS)
        # task2 remains QUEUED

        # Filter by thread AND status - should only get task1
        tasks = await manager.list_tasks(session_id="thread-a", status=TaskStatus.IN_PROGRESS)

        assert len(tasks) == 1
        assert tasks[0].task_id == task1.task_id


class TestTaskManagerDelete:
    """Tests for task deletion."""

    async def test_delete_task(self, redis_client):
        """Delete a task."""
        manager = TaskManager(redis_client)
        task = await manager.create_task(session_id="t1", message="Hi")

        await manager.delete_task(task.task_id)

        result = await manager.get_task(task.task_id)
        assert result is None

    async def test_delete_task_removes_from_indices(self, redis_client):
        """Deleting a task removes it from all indices."""
        manager = TaskManager(redis_client)
        task = await manager.create_task(session_id="t1", message="Hi")

        await manager.delete_task(task.task_id)

        # Should not appear in listings
        all_tasks = await manager.list_tasks()
        assert len(all_tasks) == 0

        thread_tasks = await manager.list_tasks(session_id="t1")
        assert len(thread_tasks) == 0


class TestTaskManagerUpdate:
    """Tests for the unified update() method."""

    async def test_update_status_only(self, redis_client):
        """update() can change just the status."""
        manager = TaskManager(redis_client)
        task = await manager.create_task("thread123", "msg")

        await manager.update(task.task_id, status="in_progress")

        updated = await manager.get_task(task.task_id)
        assert updated.status == TaskStatus.IN_PROGRESS

    async def test_update_status_with_message(self, redis_client):
        """update() can change status and add message in one call."""
        manager = TaskManager(redis_client)
        task = await manager.create_task("thread123", "msg")

        await manager.update(task.task_id, status="in_progress", message="Starting work...")

        updated = await manager.get_task(task.task_id)
        assert updated.status == TaskStatus.IN_PROGRESS
        assert len(updated.updates) == 1
        assert updated.updates[0].message == "Starting work..."

    async def test_update_message_only(self, redis_client):
        """update() can add just a message without changing status."""
        manager = TaskManager(redis_client)
        task = await manager.create_task("thread123", "msg")

        await manager.update(task.task_id, message="Progress update")

        updated = await manager.get_task(task.task_id)
        assert updated.status == TaskStatus.QUEUED  # Unchanged
        assert len(updated.updates) == 1
        assert updated.updates[0].message == "Progress update"

    async def test_update_done_with_result(self, redis_client):
        """update() can complete task with status and result."""
        manager = TaskManager(redis_client)
        task = await manager.create_task("thread123", "msg")

        await manager.update(task.task_id, status="done", result={"answer": "42"})

        updated = await manager.get_task(task.task_id)
        assert updated.status == TaskStatus.DONE
        assert updated.result == {"answer": "42"}

    async def test_update_failed_with_error(self, redis_client):
        """update() can fail task with status and error."""
        manager = TaskManager(redis_client)
        task = await manager.create_task("thread123", "msg")

        await manager.update(task.task_id, status="failed", error="Something went wrong")

        updated = await manager.get_task(task.task_id)
        assert updated.status == TaskStatus.FAILED
        assert updated.error_message == "Something went wrong"

    async def test_update_with_enum_status(self, redis_client):
        """update() accepts TaskStatus enum."""
        manager = TaskManager(redis_client)
        task = await manager.create_task("thread123", "msg")

        await manager.update(task.task_id, status=TaskStatus.IN_PROGRESS)

        updated = await manager.get_task(task.task_id)
        assert updated.status == TaskStatus.IN_PROGRESS

    async def test_update_with_update_type(self, redis_client):
        """update() can specify update_type for messages."""
        manager = TaskManager(redis_client)
        task = await manager.create_task("thread123", "msg")

        await manager.update(task.task_id, message="Calling API", update_type="tool_call")

        updated = await manager.get_task(task.task_id)
        assert updated.updates[0].update_type == "tool_call"

    async def test_update_with_metadata(self, redis_client):
        """update() can include metadata in messages."""
        manager = TaskManager(redis_client)
        task = await manager.create_task("thread123", "msg")

        await manager.update(
            task.task_id,
            message="Step complete",
            metadata={"step": 1, "duration_ms": 100},
        )

        updated = await manager.get_task(task.task_id)
        assert updated.updates[0].metadata == {"step": 1, "duration_ms": 100}

    async def test_update_nonexistent_task(self, redis_client):
        """update() silently returns for non-existent task."""
        manager = TaskManager(redis_client)
        # Should not raise
        await manager.update("nonexistent", status="in_progress")


class TestTaskManagerNonexistentTask:
    """Tests for operations on non-existent tasks."""

    async def test_update_status_nonexistent_task(self, redis_client):
        """update_status should silently return for non-existent task."""
        manager = TaskManager(redis_client)
        # Should not raise
        await manager.update_status("nonexistent", TaskStatus.IN_PROGRESS)

    async def test_add_update_nonexistent_task(self, redis_client):
        """add_update should silently return for non-existent task."""
        manager = TaskManager(redis_client)
        # Should not raise
        await manager.add_update("nonexistent", "Some update")

    async def test_set_result_nonexistent_task(self, redis_client):
        """set_result should silently return for non-existent task."""
        manager = TaskManager(redis_client)
        # Should not raise
        await manager.set_result("nonexistent", {"answer": "42"})

    async def test_set_error_nonexistent_task(self, redis_client):
        """set_error should silently return for non-existent task."""
        manager = TaskManager(redis_client)
        # Should not raise
        await manager.set_error("nonexistent", "Some error")

    async def test_delete_nonexistent_task(self, redis_client):
        """delete_task should not raise for non-existent task."""
        manager = TaskManager(redis_client)
        # Should not raise - just silently does nothing
        await manager.delete_task("nonexistent")


class TestTaskManagerInput:
    """Tests for task input request/response functionality."""

    async def test_request_input_simple(self, redis_client):
        """request_input should pause task and store prompt."""
        manager = TaskManager(redis_client)
        task = await manager.create_task(session_id="t1", message="Hello")

        await manager.request_input(task.task_id, prompt="What database?")

        updated = await manager.get_task(task.task_id)
        assert updated.status == TaskStatus.AWAITING_INPUT
        assert updated.input_request is not None
        assert updated.input_request.prompt == "What database?"
        assert updated.input_request.json_schema == {
            "type": "object",
            "properties": {},
            "required": [],
        }

    async def test_request_input_with_json_schema(self, redis_client):
        """request_input should store JSON Schema."""
        manager = TaskManager(redis_client)
        task = await manager.create_task(session_id="t1", message="Hello")

        schema = {
            "type": "object",
            "properties": {
                "database": {
                    "type": "string",
                    "title": "Database",
                    "enum": ["PostgreSQL", "MySQL", "Redis"],
                },
                "confirm": {
                    "type": "boolean",
                    "title": "Confirm",
                    "default": False,
                },
            },
            "required": ["database"],
        }
        await manager.request_input(
            task.task_id,
            prompt="Please configure the connection",
            json_schema=schema,
        )

        updated = await manager.get_task(task.task_id)
        assert updated.status == TaskStatus.AWAITING_INPUT
        assert updated.input_request.json_schema == schema
        assert "database" in updated.input_request.json_schema["properties"]
        assert "confirm" in updated.input_request.json_schema["properties"]

    async def test_request_input_updates_status_index(self, redis_client):
        """request_input should update the status index."""
        manager = TaskManager(redis_client)
        task = await manager.create_task(session_id="t1", message="Hello")

        # Initially queued
        queued = await manager.list_tasks(status=TaskStatus.QUEUED)
        assert any(t.task_id == task.task_id for t in queued)

        await manager.request_input(task.task_id, prompt="Need input")

        # Now awaiting input
        awaiting = await manager.list_tasks(status=TaskStatus.AWAITING_INPUT)
        assert any(t.task_id == task.task_id for t in awaiting)

        # Not in queued anymore
        queued = await manager.list_tasks(status=TaskStatus.QUEUED)
        assert not any(t.task_id == task.task_id for t in queued)

    async def test_submit_input_success(self, redis_client):
        """submit_input should store response and re-queue task."""
        manager = TaskManager(redis_client)
        task = await manager.create_task(session_id="t1", message="Hello")
        await manager.request_input(task.task_id, prompt="What database?")

        result = await manager.submit_input(task.task_id, {"response": "Redis"})

        assert result is True
        updated = await manager.get_task(task.task_id)
        assert updated.status == TaskStatus.QUEUED
        assert updated.input_response == {"response": "Redis"}

    async def test_submit_input_structured(self, redis_client):
        """submit_input should accept structured responses."""
        manager = TaskManager(redis_client)
        task = await manager.create_task(session_id="t1", message="Hello")
        schema = {
            "type": "object",
            "properties": {
                "database": {"type": "string"},
                "port": {"type": "integer"},
            },
        }
        await manager.request_input(task.task_id, prompt="Configure", json_schema=schema)

        result = await manager.submit_input(task.task_id, {"database": "Redis", "port": 6379})

        assert result is True
        updated = await manager.get_task(task.task_id)
        assert updated.input_response == {"database": "Redis", "port": 6379}

    async def test_submit_input_wrong_status(self, redis_client):
        """submit_input should fail if task not awaiting input."""
        manager = TaskManager(redis_client)
        task = await manager.create_task(session_id="t1", message="Hello")
        # Task is in QUEUED status, not AWAITING_INPUT

        result = await manager.submit_input(task.task_id, {"response": "test"})

        assert result is False

    async def test_submit_input_nonexistent_task(self, redis_client):
        """submit_input should fail for non-existent task."""
        manager = TaskManager(redis_client)

        result = await manager.submit_input("nonexistent", {"response": "test"})

        assert result is False

    async def test_get_input_request(self, redis_client):
        """get_input_request should return the pending request."""
        manager = TaskManager(redis_client)
        task = await manager.create_task(session_id="t1", message="Hello")
        await manager.request_input(task.task_id, prompt="Choose one")

        request = await manager.get_input_request(task.task_id)

        assert request is not None
        assert request.prompt == "Choose one"

    async def test_get_input_request_not_awaiting(self, redis_client):
        """get_input_request should return None if not awaiting."""
        manager = TaskManager(redis_client)
        task = await manager.create_task(session_id="t1", message="Hello")

        request = await manager.get_input_request(task.task_id)

        assert request is None

    async def test_clear_input(self, redis_client):
        """clear_input should remove request and response."""
        manager = TaskManager(redis_client)
        task = await manager.create_task(session_id="t1", message="Hello")
        await manager.request_input(task.task_id, prompt="Input")
        await manager.submit_input(task.task_id, {"response": "done"})

        await manager.clear_input(task.task_id)

        updated = await manager.get_task(task.task_id)
        assert updated.input_request is None
        assert updated.input_response is None

    async def test_request_input_nonexistent_task(self, redis_client):
        """request_input should not raise for non-existent task."""
        manager = TaskManager(redis_client)
        # Should not raise - just silently does nothing
        await manager.request_input("nonexistent", prompt="Test")

    async def test_get_input_request_nonexistent_task(self, redis_client):
        """get_input_request should return None for non-existent task."""
        manager = TaskManager(redis_client)
        result = await manager.get_input_request("nonexistent")
        assert result is None

    async def test_clear_input_nonexistent_task(self, redis_client):
        """clear_input should not raise for non-existent task."""
        manager = TaskManager(redis_client)
        # Should not raise - just silently does nothing
        await manager.clear_input("nonexistent")
