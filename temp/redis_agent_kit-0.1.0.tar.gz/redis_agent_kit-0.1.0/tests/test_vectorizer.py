"""Tests for Vectorizer using RedisVL vectorizers."""

from unittest.mock import AsyncMock, MagicMock, patch

import pytest


class TestVectorizer:
    """Tests for Vectorizer class."""

    def test_vectorizer_creation_with_default_model(self):
        """Vectorizer should be creatable with default model."""
        from redis_agent_kit.vectorizer import Vectorizer

        with patch("redis_agent_kit.vectorizer.OpenAITextVectorizer") as mock_cls:
            mock_cls.return_value = MagicMock()
            vectorizer = Vectorizer()
            mock_cls.assert_called_once_with(
                model="text-embedding-3-small", api_config=None, cache=None
            )
            assert vectorizer._vectorizer is not None

    def test_vectorizer_creation_with_custom_model(self):
        """Vectorizer should accept custom model."""
        from redis_agent_kit.vectorizer import Vectorizer

        with patch("redis_agent_kit.vectorizer.OpenAITextVectorizer") as mock_cls:
            mock_cls.return_value = MagicMock()
            vectorizer = Vectorizer(model="text-embedding-ada-002")
            mock_cls.assert_called_once_with(
                model="text-embedding-ada-002", api_config=None, cache=None
            )
            assert vectorizer._vectorizer is not None

    def test_vectorizer_with_custom_vectorizer(self):
        """Vectorizer should accept a custom RedisVL vectorizer."""
        from redis_agent_kit.vectorizer import Vectorizer

        mock_vectorizer = MagicMock()
        vectorizer = Vectorizer(vectorizer=mock_vectorizer)
        assert vectorizer._vectorizer is mock_vectorizer

    @pytest.mark.asyncio
    async def test_embed_single_text(self):
        """Vectorizer should embed a single text."""
        from redis_agent_kit.vectorizer import Vectorizer

        mock_vectorizer = MagicMock()
        mock_vectorizer.aembed = AsyncMock(return_value=[0.1, 0.2, 0.3])
        vectorizer = Vectorizer(vectorizer=mock_vectorizer)

        embedding = await vectorizer.embed("Hello world")

        assert embedding == [0.1, 0.2, 0.3]
        mock_vectorizer.aembed.assert_called_once_with("Hello world")

    @pytest.mark.asyncio
    async def test_embed_many_texts(self):
        """Vectorizer should embed multiple texts."""
        from redis_agent_kit.vectorizer import Vectorizer

        mock_vectorizer = MagicMock()
        mock_vectorizer.aembed_many = AsyncMock(return_value=[[0.1, 0.2, 0.3], [0.4, 0.5, 0.6]])
        vectorizer = Vectorizer(vectorizer=mock_vectorizer)

        embeddings = await vectorizer.embed_many(["Hello", "World"])

        assert len(embeddings) == 2
        assert embeddings[0] == [0.1, 0.2, 0.3]
        assert embeddings[1] == [0.4, 0.5, 0.6]
        mock_vectorizer.aembed_many.assert_called_once_with(["Hello", "World"])

    @pytest.mark.asyncio
    async def test_embed_empty_list(self):
        """Vectorizer should handle empty list."""
        from redis_agent_kit.vectorizer import Vectorizer

        mock_vectorizer = MagicMock()
        vectorizer = Vectorizer(vectorizer=mock_vectorizer)
        embeddings = await vectorizer.embed_many([])
        assert embeddings == []

    def test_embed_sync_single_text(self):
        """Vectorizer embed_sync should embed a single text synchronously."""
        from redis_agent_kit.vectorizer import Vectorizer

        mock_vectorizer = MagicMock()
        mock_vectorizer.embed = MagicMock(return_value=[0.1, 0.2, 0.3])
        vectorizer = Vectorizer(vectorizer=mock_vectorizer)

        embedding = vectorizer.embed_sync("Hello world")

        assert embedding == [0.1, 0.2, 0.3]
        mock_vectorizer.embed.assert_called_once_with("Hello world")

    def test_embed_many_sync(self):
        """Vectorizer embed_many_sync should embed multiple texts synchronously."""
        from redis_agent_kit.vectorizer import Vectorizer

        mock_vectorizer = MagicMock()
        mock_vectorizer.embed_many = MagicMock(return_value=[[0.1, 0.2, 0.3], [0.4, 0.5, 0.6]])
        vectorizer = Vectorizer(vectorizer=mock_vectorizer)

        embeddings = vectorizer.embed_many_sync(["Hello", "World"])

        assert len(embeddings) == 2
        assert embeddings[0] == [0.1, 0.2, 0.3]
        assert embeddings[1] == [0.4, 0.5, 0.6]


class TestLiteLLMVectorizerAdapter:
    """Tests for LiteLLM adapter for RedisVL."""

    def test_adapter_creation(self):
        """Adapter should be creatable with default settings."""
        from redis_agent_kit.vectorizer import LiteLLMVectorizerAdapter

        adapter = LiteLLMVectorizerAdapter()
        assert adapter.model == "text-embedding-3-small"
        assert adapter.dimensions is None
        assert adapter.batch_size == 100

    def test_adapter_with_custom_settings(self):
        """Adapter should accept custom settings."""
        from redis_agent_kit.vectorizer import LiteLLMVectorizerAdapter

        adapter = LiteLLMVectorizerAdapter(model="custom-model", dimensions=512, batch_size=50)
        assert adapter.model == "custom-model"
        assert adapter.dimensions == 512
        assert adapter.batch_size == 50

    def test_adapter_embed_sync(self):
        """Adapter should embed synchronously via LiteLLM."""
        from redis_agent_kit.vectorizer import LiteLLMVectorizerAdapter

        adapter = LiteLLMVectorizerAdapter()

        mock_response = MagicMock()
        mock_response.data = [{"embedding": [0.1, 0.2, 0.3]}]

        with patch("litellm.embedding", return_value=mock_response) as mock_embed:
            embedding = adapter.embed("Hello world")

            assert embedding == [0.1, 0.2, 0.3]
            mock_embed.assert_called_once()
            call_args = mock_embed.call_args
            assert call_args.kwargs["input"] == ["Hello world"]

    @pytest.mark.asyncio
    async def test_adapter_aembed(self):
        """Adapter should embed asynchronously via LiteLLM."""
        from redis_agent_kit.vectorizer import LiteLLMVectorizerAdapter

        adapter = LiteLLMVectorizerAdapter()

        mock_response = MagicMock()
        mock_response.data = [{"embedding": [0.1, 0.2, 0.3]}]

        with patch("litellm.aembedding", return_value=mock_response) as mock_embed:
            embedding = await adapter.aembed("Hello world")

            assert embedding == [0.1, 0.2, 0.3]
            mock_embed.assert_called_once()

    @pytest.mark.asyncio
    async def test_adapter_aembed_many_batches(self):
        """Adapter should batch large inputs."""
        from redis_agent_kit.vectorizer import LiteLLMVectorizerAdapter

        adapter = LiteLLMVectorizerAdapter(batch_size=2)

        mock_response = MagicMock()
        mock_response.data = [{"embedding": [0.1]}, {"embedding": [0.2]}]

        with patch("litellm.aembedding", return_value=mock_response) as mock_embed:
            texts = ["a", "b", "c", "d"]
            embeddings = await adapter.aembed_many(texts)

            # Should have made 2 calls (4 texts / batch_size 2)
            assert mock_embed.call_count == 2
            assert len(embeddings) == 4

    @pytest.mark.asyncio
    async def test_adapter_passes_dimensions(self):
        """Adapter should pass dimensions to LiteLLM."""
        from redis_agent_kit.vectorizer import LiteLLMVectorizerAdapter

        adapter = LiteLLMVectorizerAdapter(dimensions=256)

        mock_response = MagicMock()
        mock_response.data = [{"embedding": [0.1] * 256}]

        with patch("litellm.aembedding", return_value=mock_response) as mock_embed:
            await adapter.aembed("test")
            call_args = mock_embed.call_args
            assert call_args.kwargs["dimensions"] == 256


class TestVectorizerFromLiteLLM:
    """Tests for Vectorizer.from_litellm factory method."""

    def test_from_litellm_creates_vectorizer(self):
        """from_litellm should create a Vectorizer with LiteLLM adapter."""
        from redis_agent_kit.vectorizer import Vectorizer

        with patch("redis_agent_kit.vectorizer.CustomTextVectorizer") as mock_custom:
            mock_custom.return_value = MagicMock()
            vectorizer = Vectorizer.from_litellm(model="cohere/embed-english-v3.0")
            mock_custom.assert_called_once()
            assert vectorizer._vectorizer is not None

    @pytest.mark.asyncio
    async def test_from_litellm_embed(self):
        """Vectorizer from_litellm should embed via LiteLLM."""
        from redis_agent_kit.vectorizer import Vectorizer

        mock_response = MagicMock()
        mock_response.data = [{"embedding": [0.1, 0.2, 0.3]}]

        with patch("litellm.aembedding", return_value=mock_response):
            vectorizer = Vectorizer.from_litellm()
            embedding = await vectorizer.embed("test")
            assert len(embedding) == 3


class TestVectorizerDims:
    """Tests for Vectorizer dims property."""

    def test_dims_returns_value_when_present(self):
        """dims should return value from underlying vectorizer."""
        from redis_agent_kit.vectorizer import Vectorizer

        mock_vectorizer = MagicMock()
        mock_vectorizer.dims = 1536
        vectorizer = Vectorizer(vectorizer=mock_vectorizer)
        assert vectorizer.dims == 1536

    def test_dims_returns_none_when_not_present(self):
        """dims should return None when underlying vectorizer has no dims."""
        from redis_agent_kit.vectorizer import Vectorizer

        mock_vectorizer = MagicMock(spec=[])  # No dims attribute
        vectorizer = Vectorizer(vectorizer=mock_vectorizer)
        assert vectorizer.dims is None

    def test_embed_many_sync_empty_list(self):
        """embed_many_sync should return empty list for empty input."""
        from redis_agent_kit.vectorizer import Vectorizer

        mock_vectorizer = MagicMock()
        vectorizer = Vectorizer(vectorizer=mock_vectorizer)
        result = vectorizer.embed_many_sync([])
        assert result == []


class TestLiteLLMAdapterEdgeCases:
    """Edge case tests for LiteLLMVectorizerAdapter."""

    def test_embed_many_sync_empty_list(self):
        """embed_many should return empty list for empty input."""
        from redis_agent_kit.vectorizer import LiteLLMVectorizerAdapter

        adapter = LiteLLMVectorizerAdapter()
        result = adapter.embed_many([])
        assert result == []

    @pytest.mark.asyncio
    async def test_aembed_many_empty_list(self):
        """aembed_many should return empty list for empty input."""
        from redis_agent_kit.vectorizer import LiteLLMVectorizerAdapter

        adapter = LiteLLMVectorizerAdapter()
        result = await adapter.aembed_many([])
        assert result == []

    def test_embed_many_sync_with_dimensions(self):
        """embed_many should pass dimensions to LiteLLM."""
        from redis_agent_kit.vectorizer import LiteLLMVectorizerAdapter

        adapter = LiteLLMVectorizerAdapter(dimensions=512)

        mock_response = MagicMock()
        mock_response.data = [{"embedding": [0.1] * 512}]

        with patch("litellm.embedding", return_value=mock_response) as mock_embed:
            adapter.embed_many(["test"])
            call_args = mock_embed.call_args
            assert call_args.kwargs["dimensions"] == 512
